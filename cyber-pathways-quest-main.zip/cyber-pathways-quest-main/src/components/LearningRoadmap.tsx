// Learning Roadmap Component - Visual Progress Map for Career Tracks
import React, { useState } from 'react';
import { useGame } from '../contexts/GameContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Trophy, Lock, CheckCircle, Target, Users, Shield, Code } from 'lucide-react';
import { cn } from '@/lib/utils';

const LearningRoadmap: React.FC = () => {
  const { userProgress, learningPaths, selectCareerTrack, getPathProgress } = useGame();
  const [selectedTrack, setSelectedTrack] = useState<'analyst' | 'pentester' | 'engineer'>('analyst');

  const careerTracks = {
    analyst: {
      name: 'SOC Analyst',
      icon: Shield,
      color: 'text-blue-500',
      description: 'Defend organizations from cyber threats',
      paths: learningPaths.filter(p => p.careerTrack === 'analyst')
    },
    pentester: {
      name: 'Penetration Tester',
      icon: Target,
      color: 'text-red-500',
      description: 'Ethical hacking and vulnerability assessment',
      paths: learningPaths.filter(p => p.careerTrack === 'pentester')
    },
    engineer: {
      name: 'Security Engineer',
      icon: Code,
      color: 'text-green-500',
      description: 'Build secure systems and applications',
      paths: learningPaths.filter(p => p.careerTrack === 'engineer')
    }
  };

  const handlePathClick = (pathId: string) => {
    const path = learningPaths.find(p => p.id === pathId);
    if (!path?.locked) {
      // Navigate to first room in path (implementation depends on routing)
      console.log(`Navigate to path: ${pathId}`);
    }
  };

  const handleSelectTrack = (track: 'analyst' | 'pentester' | 'engineer') => {
    setSelectedTrack(track);
    selectCareerTrack(track);
  };

  const PathNode: React.FC<{ path: any; isConnected?: boolean }> = ({ path, isConnected = false }) => {
    const progressPercent = getPathProgress(path.id);
    const isCompleted = path.completed;
    const isLocked = path.locked;

    return (
      <div className="relative">
        {isConnected && (
          <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 h-8 w-0.5 bg-border" />
        )}
        
        <Card 
          className={cn(
            "w-64 cursor-pointer transition-all duration-300 hover:scale-105",
            isLocked && "opacity-50 cursor-not-allowed",
            isCompleted && "border-green-500 bg-green-50 dark:bg-green-950",
            !isLocked && !isCompleted && "hover:shadow-lg hover:border-primary"
          )}
          onClick={() => !isLocked && handlePathClick(path.id)}
        >
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {isCompleted ? (
                  <CheckCircle className="h-5 w-5 text-green-500" />
                ) : isLocked ? (
                  <Lock className="h-5 w-5 text-muted-foreground" />
                ) : (
                  <Trophy className="h-5 w-5 text-primary" />
                )}
                <Badge variant={path.difficulty === 'easy' ? 'secondary' : path.difficulty === 'medium' ? 'default' : 'destructive'}>
                  {path.difficulty}
                </Badge>
              </div>
              <div className="text-sm text-muted-foreground">
                {path.xpRequired} XP req
              </div>
            </div>
            
            <CardTitle className="text-lg">{path.title}</CardTitle>
            <CardDescription className="text-sm">
              {path.description}
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Progress</span>
                  <span>{progressPercent}%</span>
                </div>
                <Progress value={progressPercent} className="h-2" />
              </div>
              
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Users className="h-4 w-4" />
                <span>{path.rooms.length} missions</span>
              </div>
              
              {isLocked && (
                <div className="text-sm text-amber-600 dark:text-amber-400">
                  <Lock className="h-4 w-4 inline mr-1" />
                  Complete prerequisites to unlock
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold">Learning Roadmap</h2>
        <p className="text-muted-foreground">
          Choose your cybersecurity career path and progress through gamified missions
        </p>
      </div>

      {/* Career Track Selection */}
      <Tabs value={selectedTrack} onValueChange={(value) => handleSelectTrack(value as any)} className="w-full">
        <TabsList className="grid grid-cols-3 w-full max-w-md mx-auto">
          {Object.entries(careerTracks).map(([key, track]) => {
            const Icon = track.icon;
            return (
              <TabsTrigger key={key} value={key} className="flex items-center gap-2">
                <Icon className={cn("h-4 w-4", track.color)} />
                <span className="hidden sm:inline">{track.name}</span>
              </TabsTrigger>
            );
          })}
        </TabsList>

        {Object.entries(careerTracks).map(([key, track]) => {
          const Icon = track.icon;
          return (
            <TabsContent key={key} value={key} className="space-y-6">
              {/* Track Header */}
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Icon className={cn("h-8 w-8", track.color)} />
                    <div>
                      <CardTitle className="text-2xl">{track.name}</CardTitle>
                      <CardDescription>{track.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
              </Card>

              {/* Learning Path Visualization */}
              <div className="flex flex-col items-center space-y-8">
                {track.paths.map((path, index) => (
                  <PathNode 
                    key={path.id} 
                    path={path} 
                    isConnected={index > 0}
                  />
                ))}
              </div>
            </TabsContent>
          );
        })}
      </Tabs>

      {/* User Progress Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Your Progress</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-primary">{userProgress.xp}</div>
              <div className="text-sm text-muted-foreground">Total XP</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-500">{userProgress.completedRooms.length}</div>
              <div className="text-sm text-muted-foreground">Rooms Completed</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-500">{userProgress.badges.length}</div>
              <div className="text-sm text-muted-foreground">Badges Earned</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default LearningRoadmap;