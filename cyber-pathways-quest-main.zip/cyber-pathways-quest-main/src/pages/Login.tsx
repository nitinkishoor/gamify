// Login Page Component
import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Shield, Mail, Github, Chrome, Zap, Target, Users } from 'lucide-react';
import { cn } from '@/lib/utils';

const Login: React.FC = () => {
  const { login, loginWithGoogle, loginWithGitHub, isLoading } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginMethod, setLoginMethod] = useState<'email' | 'oauth'>('oauth');

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await login(email, password);
    } catch (error) {
      console.error('Login failed:', error);
    }
  };

  const features = [
    { icon: Shield, text: 'GUI-based Kali Linux environments' },
    { icon: Target, text: 'Real-world CTF challenges' },
    { icon: Users, text: 'Competitive leaderboards' },
    { icon: Zap, text: 'AI-powered learning assistance' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Shield className="h-10 w-10 text-primary" />
              <div className="text-4xl font-bold">
                <span className="text-primary">Gamify</span>
              </div>
            </div>
            <h1 className="text-3xl font-bold mb-2">
              India's First Gamified Cybersecurity Platform
            </h1>
            <p className="text-xl text-muted-foreground">
              Master cybersecurity through interactive challenges and AI-guided learning
            </p>
            <div className="flex justify-center gap-2 mt-4">
              <Badge variant="secondary">TryHackMe Style</Badge>
              <Badge variant="outline">Browser-based Labs</Badge>
              <Badge variant="default">AI Assistant</Badge>
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Login Form */}
            <Card className="mx-auto w-full max-w-md">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl">Welcome Back</CardTitle>
                <CardDescription>
                  Sign in to continue your cybersecurity journey
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* OAuth Buttons */}
                <div className="space-y-3">
                  <Button
                    variant="outline"
                    className="w-full hover:bg-blue-50 hover:border-blue-300"
                    onClick={loginWithGoogle}
                    disabled={isLoading}
                  >
                    <Chrome className="mr-2 h-4 w-4" />
                    Continue with Google
                  </Button>
                  
                  <Button
                    variant="outline"
                    className="w-full hover:bg-gray-50 hover:border-gray-300"
                    onClick={loginWithGitHub}
                    disabled={isLoading}
                  >
                    <Github className="mr-2 h-4 w-4" />
                    Continue with GitHub
                  </Button>
                </div>

                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-background px-2 text-muted-foreground">
                      Or continue with email
                    </span>
                  </div>
                </div>

                {/* Email Login Form */}
                <form onSubmit={handleEmailLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="agent@cybersec.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <Input
                      id="password"
                      type="password"
                      placeholder="Enter your password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full bg-primary hover:bg-primary/90"
                    disabled={isLoading}
                  >
                    <Mail className="mr-2 h-4 w-4" />
                    Sign In
                  </Button>
                </form>

                <div className="text-center text-sm text-muted-foreground">
                  New to Gamify? Start your journey by signing in above!
                </div>
              </CardContent>
            </Card>

            {/* Features Showcase */}
            <div className="space-y-8">
              <div>
                <h2 className="text-2xl font-bold mb-4">Why Choose Gamify?</h2>
                <div className="grid gap-4">
                  {features.map((feature, index) => {
                    const Icon = feature.icon;
                    return (
                      <div key={index} className="flex items-center gap-3 p-4 rounded-lg bg-card border">
                        <Icon className="h-6 w-6 text-primary flex-shrink-0" />
                        <span className="font-medium">{feature.text}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Demo Preview */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Platform Preview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-gray-900 rounded-lg p-4 text-green-400 font-mono text-sm">
                    <div className="mb-2">gamify@kali:~$ whoami</div>
                    <div className="mb-2">ethical-hacker</div>
                    <div className="mb-2">gamify@kali:~$ ls -la /bank/vault/</div>
                    <div className="mb-2">total 8</div>
                    <div className="mb-2">drwxr-xr-x 2 root root 4096 secret.txt</div>
                    <div className="mb-2">-rw------- 1 root root   42 passkey.dat</div>
                    <div className="text-yellow-400">Mission: Find the hidden vault passkey!</div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;