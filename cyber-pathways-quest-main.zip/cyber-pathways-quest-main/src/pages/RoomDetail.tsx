// Room Detail Page - Individual CTF Challenge Interface
import React, { useState, useEffect } from 'react';
import { useGame } from '../contexts/GameContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Monitor, 
  Terminal, 
  Play, 
  Flag, 
  MessageCircle, 
  CheckCircle, 
  Clock, 
  Folder, 
  FileText,
  Network,
  Eye,
  EyeOff,
  Minimize,
  Maximize,
  X,
  Search,
  Zap,
  Trophy,
  Target
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from '@/components/ui/use-toast';

interface RoomDetailProps {
  roomId: string;
  onNavigate: (page: string) => void;
}

const RoomDetail: React.FC<RoomDetailProps> = ({ roomId, onNavigate }) => {
  const { rooms, userProgress, submitFlag } = useGame();
  const [desktopLaunched, setDesktopLaunched] = useState(false);
  const [currentTask, setCurrentTask] = useState(0);
  const [flag, setFlag] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [aiMessage, setAiMessage] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [showHiddenFiles, setShowHiddenFiles] = useState(false);
  const [openWindows, setOpenWindows] = useState<string[]>([]);
  const [windowPositions, setWindowPositions] = useState<{[key: string]: {x: number, y: number}}>({});

  const room = rooms.find(r => r.id === roomId);
  const isCompleted = userProgress.completedRooms.includes(roomId);

  if (!room) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-4">Room Not Found</h2>
        <Button onClick={() => onNavigate('rooms')}>Back to Rooms</Button>
      </div>
    );
  }

  // Room-specific data
  const roomData = {
    'bank-attack': {
      story: "Mission Brief: SecureBank Corp has hired you to perform a penetration test on their vault system. Your objective is to infiltrate their secure file system and locate the hidden vault passkey. Use the Kali Linux desktop environment to navigate through their security layers and extract the secret passkey.",
      tasks: [
        "Launch the Kali Linux desktop environment",
        "Navigate to the bank file system using the file manager", 
        "Locate and access the restricted vault directory",
        "Find the hidden passkey file and extract the flag",
        "Submit the flag: GAMIFY{secure_vault_master_2024}"
      ],
      finalFlag: "GAMIFY{secure_vault_master_2024}",
      fileSystem: {
        '/home/user': ['Documents', 'Downloads', '.hidden_vault'],
        '/home/user/Documents': ['readme.txt', 'bank_policies.pdf'],
        '/home/user/.hidden_vault': ['vault_access.log', 'passkey.txt'],
        '/home/user/.hidden_vault/passkey.txt': 'GAMIFY{secure_vault_master_2024}'
      }
    },
    'soc-analyst-intro': {
      story: "Emergency Alert: Our security systems have detected a potential breach. As the SOC Analyst on duty, you must quickly analyze the security logs, identify the threat, and implement containment measures. Use the Kali Linux tools to investigate network traffic and secure our systems.",
      tasks: [
        "Launch the SOC analyst workstation",
        "Analyze authentication logs for suspicious activity",
        "Use network monitoring tools to identify threat patterns",
        "Trace the attacker's IP address and methods",
        "Implement security measures and submit the incident flag",
        "Flag: GAMIFY{threat_contained_systems_secured}"
      ],
      finalFlag: "GAMIFY{threat_contained_systems_secured}",
      logs: [
        "Failed login attempt from 192.168.1.100 - admin user",
        "Multiple authentication failures detected",
        "Suspicious network traffic to external IP 185.220.101.42",
        "Privilege escalation attempt blocked",
        "Threat contained - Flag: GAMIFY{threat_contained_systems_secured}"
      ]
    }
  };

  const currentRoomData = roomData[roomId as keyof typeof roomData];

  // If room data doesn't exist, return early with error message
  if (!currentRoomData) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-4">Room Configuration Missing</h2>
        <p className="text-muted-foreground mb-4">
          This room doesn't have configuration data yet.
        </p>
        <Button onClick={() => onNavigate('rooms')}>Back to Rooms</Button>
      </div>
    );
  }

  const handleLaunchDesktop = () => {
    setDesktopLaunched(true);
    if (currentTask === 0 && currentRoomData) {
      setCurrentTask(1);
      toast({
        title: "Mission Started!",
        description: "Desktop environment launched. Proceed with your mission.",
      });
    }
  };

  const handleSubmitFlag = async () => {
    setIsSubmitting(true);
    try {
      const success = await submitFlag(roomId, flag);
      if (success) {
        toast({
          title: "Mission Completed!",
          description: `You've earned ${room.xp} XP and unlocked the ${room.badge} badge!`,
        });
        setCurrentTask(currentRoomData.tasks.length);
      } else {
        toast({
          title: "Incorrect Flag",
          description: "That's not the right flag. Keep investigating!",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Submission Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive"
      });
    }
    setIsSubmitting(false);
  };

  const handleAIAssistance = () => {
    if (!currentRoomData) return;
    
    // AI responses based on current task and room
    const aiResponses = {
      'bank-attack': {
        1: "Start by clicking the file manager icon in the taskbar. Look for folders that might contain sensitive bank data.",
        2: "Navigate to the home directory (/home/user). Check for hidden folders - they might contain vault information.",
        3: "Use Ctrl+H to show hidden files. Look for folders starting with a dot (.) that might contain vault data.",
        4: "Check the .hidden_vault folder. Look for text files that might contain the passkey.",
        5: "Open the passkey.txt file to find your flag. The format should be GAMIFY{...}."
      },
      'soc-analyst-intro': {
        1: "Launch the terminal and use commands like 'cat /var/log/auth.log' to check authentication logs.",
        2: "Look for failed login attempts and unusual authentication patterns in the logs.",
        3: "Use Wireshark or netstat commands to monitor network connections and identify suspicious traffic.",
        4: "Search for IP addresses that appear frequently in failed attempts - this could be your attacker.",
        5: "Once you identify the threat, the system will provide the incident response flag."
      }
    };

    const response = aiResponses[roomId as keyof typeof aiResponses]?.[currentTask as keyof typeof aiResponses[keyof typeof aiResponses]] || 
                    "I'm here to help! What specific challenge are you facing?";
    
    setAiResponse(response);
    toast({
      title: "AI Assistant",
      description: "Hint provided! Check the AI chat for guidance.",
    });
  };

  const openWindow = (windowType: string) => {
    if (!openWindows.includes(windowType)) {
      setOpenWindows([...openWindows, windowType]);
      setWindowPositions({
        ...windowPositions,
        [windowType]: { x: Math.random() * 200 + 50, y: Math.random() * 100 + 50 }
      });
    }
  };

  const closeWindow = (windowType: string) => {
    setOpenWindows(openWindows.filter(w => w !== windowType));
  };

  const taskProgress = currentRoomData ? Math.round((currentTask / currentRoomData.tasks.length) * 100) : 0;

  const DesktopWindow: React.FC<{ type: string; title: string; children: React.ReactNode }> = ({ type, title, children }) => {
    const position = windowPositions[type] || { x: 50, y: 50 };
    
    return (
      <div 
        className="absolute bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg shadow-lg min-w-96 min-h-64"
        style={{ left: position.x, top: position.y, zIndex: 10 }}
      >
        <div className="flex items-center justify-between p-2 bg-gray-100 dark:bg-gray-700 rounded-t-lg">
          <span className="text-sm font-medium">{title}</span>
          <div className="flex gap-1">
            <button className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded">
              <Minimize className="h-3 w-3" />
            </button>
            <button className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded">
              <Maximize className="h-3 w-3" />
            </button>
            <button 
              className="p-1 hover:bg-red-500 hover:text-white rounded"
              onClick={() => closeWindow(type)}
            >
              <X className="h-3 w-3" />
            </button>
          </div>
        </div>
        <div className="p-4 max-h-96 overflow-auto">
          {children}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Room Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <Button variant="outline" onClick={() => onNavigate('rooms')}>
              ← Back to Rooms
            </Button>
            <Badge variant={room.difficulty === 'easy' ? 'secondary' : room.difficulty === 'medium' ? 'default' : 'destructive'}>
              {room.difficulty}
            </Badge>
            {room.type === 'gui' ? <Monitor className="h-5 w-5" /> : <Terminal className="h-5 w-5" />}
          </div>
          <h1 className="text-3xl font-bold">{room.title}</h1>
          <p className="text-muted-foreground">{room.description}</p>
        </div>
        
        <div className="text-right">
          <div className="flex items-center gap-2 mb-2">
            <Zap className="h-5 w-5 text-yellow-500" />
            <span className="font-medium">{room.xp} XP</span>
          </div>
          {isCompleted && (
            <div className="flex items-center gap-2 text-green-600">
              <CheckCircle className="h-5 w-5" />
              <span>Completed</span>
            </div>
          )}
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Mission Briefing and Tasks */}
        <div className="lg:col-span-1 space-y-6">
          {/* Mission Story */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5 text-red-500" />
                Mission Briefing
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm leading-relaxed">{currentRoomData.story}</p>
            </CardContent>
          </Card>

          {/* Task Progress */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="h-5 w-5 text-yellow-500" />
                Mission Tasks
              </CardTitle>
              <CardDescription>
                Progress: {taskProgress}% Complete
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Progress value={taskProgress} className="h-2" />
              
              <div className="space-y-2">
                {currentRoomData.tasks.map((task, index) => (
                  <div
                    key={index}
                    className={cn(
                      "flex items-center gap-2 p-2 rounded text-sm",
                      index < currentTask ? "bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200" :
                      index === currentTask ? "bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200" :
                      "text-muted-foreground"
                    )}
                  >
                    {index < currentTask ? (
                      <CheckCircle className="h-4 w-4 text-green-600" />
                    ) : index === currentTask ? (
                      <Clock className="h-4 w-4 text-blue-600" />
                    ) : (
                      <div className="h-4 w-4 border border-muted-foreground rounded-full" />
                    )}
                    <span>{task}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Flag Submission */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Flag className="h-5 w-5 text-green-500" />
                Submit Flag
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Input
                  placeholder="GAMIFY{your_flag_here}"
                  value={flag}
                  onChange={(e) => setFlag(e.target.value)}
                  className="font-mono"
                />
                <Button 
                  onClick={handleSubmitFlag} 
                  disabled={isSubmitting || !flag}
                  className="bg-green-600 hover:bg-green-700"
                >
                  Submit
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* AI Assistant */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageCircle className="h-5 w-5 text-blue-500" />
                Mission Support
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button onClick={handleAIAssistance} variant="outline" className="w-full">
                Get Hint for Current Task
              </Button>
              
              {aiResponse && (
                <div className="p-3 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded">
                  <p className="text-sm">{aiResponse}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Desktop Environment */}
        <div className="lg:col-span-2">
          <Card className="h-96 lg:h-[600px]">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Monitor className="h-5 w-5" />
                  Kali Linux Desktop Environment
                </CardTitle>
                {!desktopLaunched && (
                  <Button onClick={handleLaunchDesktop} className="bg-green-600 hover:bg-green-700">
                    <Play className="mr-2 h-4 w-4" />
                    Launch Mission
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent className="h-full p-0">
              {desktopLaunched ? (
                <div className="relative h-full bg-gradient-to-br from-blue-900 to-purple-900 overflow-hidden">
                  {/* Desktop Background */}
                  <div className="absolute inset-0 bg-black/20"></div>
                  
                  {/* Taskbar */}
                  <div className="absolute bottom-0 left-0 right-0 h-12 bg-gray-800 border-t border-gray-600 flex items-center px-4 justify-between">
                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-white hover:bg-gray-700"
                        onClick={() => openWindow('files')}
                      >
                        <Folder className="h-4 w-4 mr-1" />
                        Files
                      </Button>
                      
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-white hover:bg-gray-700"
                        onClick={() => openWindow('terminal')}
                      >
                        <Terminal className="h-4 w-4 mr-1" />
                        Terminal
                      </Button>
                      
                      {roomId === 'soc-analyst-intro' && (
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-white hover:bg-gray-700"
                          onClick={() => openWindow('wireshark')}
                        >
                          <Network className="h-4 w-4 mr-1" />
                          Wireshark
                        </Button>
                      )}
                    </div>
                    
                    <div className="text-white text-sm">
                      {new Date().toLocaleTimeString()}
                    </div>
                  </div>

                  {/* Desktop Icons */}
                  <div className="absolute top-4 left-4 space-y-4">
                    <div 
                      className="flex flex-col items-center p-2 rounded hover:bg-white/10 cursor-pointer"
                      onClick={() => openWindow('files')}
                    >
                      <Folder className="h-8 w-8 text-white" />
                      <span className="text-white text-xs mt-1">File Manager</span>
                    </div>
                    
                    <div 
                      className="flex flex-col items-center p-2 rounded hover:bg-white/10 cursor-pointer"
                      onClick={() => openWindow('terminal')}
                    >
                      <Terminal className="h-8 w-8 text-white" />
                      <span className="text-white text-xs mt-1">Terminal</span>
                    </div>
                  </div>

                  {/* Windows */}
                  {openWindows.includes('files') && (
                    <DesktopWindow type="files" title="File Manager">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 mb-4">
                          <Button size="sm" variant="outline" onClick={() => setShowHiddenFiles(!showHiddenFiles)}>
                            {showHiddenFiles ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                            {showHiddenFiles ? 'Hide Hidden' : 'Show Hidden'}
                          </Button>
                        </div>
                        
                        <div className="grid gap-2">
                          <div className="flex items-center gap-2 p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded cursor-pointer">
                            <Folder className="h-4 w-4" />
                            <span>Documents</span>
                          </div>
                          
                          <div className="flex items-center gap-2 p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded cursor-pointer">
                            <Folder className="h-4 w-4" />
                            <span>Downloads</span>
                          </div>
                          
                          {showHiddenFiles && roomId === 'bank-attack' && (
                            <div 
                              className="flex items-center gap-2 p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded cursor-pointer"
                              onClick={() => {
                                setCurrentTask(Math.max(currentTask, 3));
                                openWindow('vault');
                              }}
                            >
                              <Folder className="h-4 w-4 text-yellow-600" />
                              <span>.hidden_vault</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </DesktopWindow>
                  )}

                  {openWindows.includes('vault') && (
                    <DesktopWindow type="vault" title="Vault Directory">
                      <div className="space-y-2">
                        <div 
                          className="flex items-center gap-2 p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded cursor-pointer"
                          onClick={() => {
                            setCurrentTask(Math.max(currentTask, 4));
                            openWindow('passkey');
                          }}
                        >
                          <FileText className="h-4 w-4 text-green-600" />
                          <span>passkey.txt</span>
                        </div>
                        <div className="flex items-center gap-2 p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded">
                          <FileText className="h-4 w-4" />
                          <span>vault_access.log</span>
                        </div>
                      </div>
                    </DesktopWindow>
                  )}

                  {openWindows.includes('passkey') && (
                    <DesktopWindow type="passkey" title="passkey.txt">
                      <div className="bg-black text-green-400 p-4 font-mono text-sm rounded">
                        <p>SecureBank Vault Passkey</p>
                        <p>Classification: TOP SECRET</p>
                        <p>---------------------------</p>
                        <p className="text-yellow-400">Access Code: GAMIFY{`{secure_vault_master_2024}`}</p>
                        <p>---------------------------</p>
                        <p>Use this code to complete your mission!</p>
                      </div>
                    </DesktopWindow>
                  )}

                  {openWindows.includes('terminal') && (
                    <DesktopWindow type="terminal" title="Terminal">
                      <div className="bg-black text-green-400 p-4 font-mono text-sm rounded">
                        <p>kali@gamify:~$ whoami</p>
                        <p>ethical-hacker</p>
                        <p>kali@gamify:~$ ls -la</p>
                        <p>total 12</p>
                        <p>drwxr-xr-x 3 user user 4096 .</p>
                        <p>drwxr-xr-x 3 root root 4096 ..</p>
                        <p>drwxr-xr-x 2 user user 4096 Documents</p>
                        <p>drwxr-xr-x 2 user user 4096 Downloads</p>
                        {roomId === 'bank-attack' && (
                          <p>drwx------ 2 user user 4096 .hidden_vault</p>
                        )}
                        <p className="text-yellow-400">kali@gamify:~$ _</p>
                      </div>
                    </DesktopWindow>
                  )}

                  {openWindows.includes('wireshark') && roomId === 'soc-analyst-intro' && (
                    <DesktopWindow type="wireshark" title="Wireshark - Network Analysis">
                      <div className="space-y-2">
                        <div className="bg-gray-100 dark:bg-gray-700 p-3 rounded text-sm font-mono">
                          <div className="text-red-600">192.168.1.100 → 192.168.1.1 HTTP Failed Auth</div>
                          <div className="text-red-600">192.168.1.100 → 192.168.1.1 SSH Brute Force</div>
                          <div className="text-orange-500">185.220.101.42 → 192.168.1.50 Suspicious Traffic</div>
                          <div className="text-green-600">Threat Analysis Complete</div>
                          <div 
                            className="text-blue-600 cursor-pointer hover:underline"
                            onClick={() => {
                              setCurrentTask(Math.max(currentTask, 5));
                              toast({
                                title: "Threat Identified!",
                                description: "Flag found in network analysis: GAMIFY{threat_contained_systems_secured}",
                              });
                            }}
                          >
                            Flag: GAMIFY{`{threat_contained_systems_secured}`}
                          </div>
                        </div>
                      </div>
                    </DesktopWindow>
                  )}
                </div>
              ) : (
                <div className="h-full flex items-center justify-center bg-gray-900 text-white">
                  <div className="text-center space-y-4">
                    <Monitor className="h-16 w-16 mx-auto text-gray-400" />
                    <h3 className="text-xl font-medium">Desktop Environment Ready</h3>
                    <p className="text-gray-400">Click "Launch Mission" to start your challenge</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default RoomDetail;