// Rooms Page Component - Browse and Access CTF Challenges
import React, { useState } from 'react';
import { useGame } from '../contexts/GameContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Monitor, Terminal, Shield, Target, Code, Search, Zap, Lock, CheckCircle, Clock, Users } from 'lucide-react';
import { cn } from '@/lib/utils';

interface RoomsProps {
  onNavigate: (page: string, roomId?: string) => void;
}

const Rooms: React.FC<RoomsProps> = ({ onNavigate }) => {
  const { rooms, userProgress } = useGame();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = [
    { id: 'all', label: 'All Rooms', icon: Shield },
    { id: 'fundamentals', label: 'Fundamentals', icon: Code },
    { id: 'offensive', label: 'Offensive Security', icon: Target },
    { id: 'defensive', label: 'Defensive Security', icon: Shield }
  ];

  const filteredRooms = rooms.filter(room => {
    const matchesSearch = room.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         room.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || room.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getRoomStats = (roomId: string) => {
    const isCompleted = userProgress.completedRooms.includes(roomId);
    const mockCompletions = Math.floor(Math.random() * 1000) + 100; // Mock data
    return { isCompleted, completions: mockCompletions };
  };

  const handleRoomClick = (roomId: string) => {
    onNavigate('room-detail', roomId);
  };

  const RoomCard: React.FC<{ room: any }> = ({ room }) => {
    const { isCompleted, completions } = getRoomStats(room.id);
    const TypeIcon = room.type === 'gui' ? Monitor : Terminal;

    return (
      <Card 
        className={cn(
          "cursor-pointer transition-all duration-300 hover:scale-105 hover:shadow-lg",
          room.locked && "opacity-50 cursor-not-allowed",
          isCompleted && "border-green-500 bg-green-50 dark:bg-green-950",
          room.premium && !isCompleted && "border-amber-500 bg-amber-50 dark:bg-amber-950"
        )}
        onClick={() => !room.locked && handleRoomClick(room.id)}
      >
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <TypeIcon className="h-5 w-5 text-primary" />
              {isCompleted && <CheckCircle className="h-5 w-5 text-green-500" />}
              {room.locked && <Lock className="h-5 w-5 text-muted-foreground" />}
            </div>
            
            <div className="flex items-center gap-2">
              <Badge variant={room.difficulty === 'easy' ? 'secondary' : room.difficulty === 'medium' ? 'default' : 'destructive'}>
                {room.difficulty}
              </Badge>
              {room.premium && (
                <Badge variant="outline" className="border-amber-500 text-amber-600">
                  Premium
                </Badge>
              )}
            </div>
          </div>
          
          <CardTitle className="text-lg">{room.title}</CardTitle>
          <CardDescription className="text-sm">
            {room.description}
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1">
                <Zap className="h-4 w-4 text-yellow-500" />
                <span>{room.xp} XP</span>
              </div>
              <div className="flex items-center gap-1">
                <Users className="h-4 w-4 text-blue-500" />
                <span>{completions}</span>
              </div>
            </div>
            
            <div className="text-muted-foreground">
              {room.type === 'gui' ? 'GUI Desktop' : 'Terminal'}
            </div>
          </div>
          
          {room.locked ? (
            <div className="text-sm text-amber-600 dark:text-amber-400">
              <Lock className="h-4 w-4 inline mr-1" />
              Complete prerequisites to unlock
            </div>
          ) : (
            <Button 
              className={cn(
                "w-full",
                isCompleted 
                  ? "bg-green-600 hover:bg-green-700" 
                  : "bg-primary hover:bg-primary/90"
              )}
              onClick={(e) => {
                e.stopPropagation();
                handleRoomClick(room.id);
              }}
            >
              {isCompleted ? 'View Solution' : 'Start Mission'}
            </Button>
          )}
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold">Mission Rooms</h1>
        <p className="text-muted-foreground">
          Choose your cybersecurity challenge and start hacking!
        </p>
      </div>

      {/* Search and Filters */}
      <div className="space-y-4">
        <div className="relative max-w-md mx-auto">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search rooms..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        
        <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="w-full">
          <TabsList className="grid grid-cols-4 w-full max-w-2xl mx-auto">
            {categories.map((category) => {
              const Icon = category.icon;
              return (
                <TabsTrigger key={category.id} value={category.id} className="flex items-center gap-2">
                  <Icon className="h-4 w-4" />
                  <span className="hidden sm:inline">{category.label}</span>
                </TabsTrigger>
              );
            })}
          </TabsList>
        </Tabs>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-primary">{rooms.length}</div>
            <div className="text-sm text-muted-foreground">Total Rooms</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-500">{userProgress.completedRooms.length}</div>
            <div className="text-sm text-muted-foreground">Completed</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-500">
              {Math.round((userProgress.completedRooms.length / rooms.length) * 100)}%
            </div>
            <div className="text-sm text-muted-foreground">Progress</div>
          </CardContent>
        </Card>
      </div>

      {/* Rooms Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredRooms.map((room) => (
          <RoomCard key={room.id} room={room} />
        ))}
      </div>

      {filteredRooms.length === 0 && (
        <div className="text-center py-12">
          <Shield className="h-16 w-16 mx-auto mb-4 text-muted-foreground opacity-50" />
          <h3 className="text-lg font-medium mb-2">No rooms found</h3>
          <p className="text-muted-foreground">Try adjusting your search or category filter</p>
        </div>
      )}
    </div>
  );
};

export default Rooms;