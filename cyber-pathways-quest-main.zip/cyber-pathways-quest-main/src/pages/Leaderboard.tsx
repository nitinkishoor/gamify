// Leaderboard Page Component
import React, { useState } from 'react';
import { useGame } from '../contexts/GameContext';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Trophy, Medal, Crown, Zap, Target, TrendingUp, Users, Star } from 'lucide-react';
import { cn } from '@/lib/utils';

const Leaderboard: React.FC = () => {
  const { userProgress } = useGame();
  const { user } = useAuth();

  // Mock leaderboard data - in a real app, this would come from a backend
  const mockLeaderboard = [
    { id: 'user1', name: 'CyberNinja', email: 'ninja@sec.com', xp: 2500, level: 6, completedRooms: 8, badges: 12, streak: 15, avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=ninja' },
    { id: 'user2', name: 'HackMaster', email: 'hack@pro.com', xp: 2200, level: 5, completedRooms: 7, badges: 10, streak: 12, avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=hack' },
    { id: 'user3', name: 'SecurityQueen', email: 'queen@sec.com', xp: 2100, level: 5, completedRooms: 6, badges: 11, streak: 8, avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=queen' },
    { id: 'user4', name: 'PenTestPro', email: 'pen@test.com', xp: 1900, level: 4, completedRooms: 6, badges: 9, streak: 10, avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=pen' },
    { id: 'user5', name: 'SOCAnalyst', email: 'soc@def.com', xp: 1750, level: 4, completedRooms: 5, badges: 8, streak: 7, avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=soc' },
    { id: 'user6', name: 'EthicalHacker', email: 'ethical@hack.com', xp: 1600, level: 4, completedRooms: 5, badges: 7, streak: 6, avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=ethical' },
    { id: 'user7', name: 'CryptoGuard', email: 'crypto@guard.com', xp: 1400, level: 3, completedRooms: 4, badges: 6, streak: 5, avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=crypto' },
    { id: 'user8', name: 'SecurityNewbie', email: 'newbie@learn.com', xp: 1200, level: 3, completedRooms: 4, badges: 5, streak: 4, avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=newbie' },
  ];

  // Add current user to leaderboard
  const currentUserEntry = {
    id: user?.id || 'current',
    name: user?.name || 'You',
    email: user?.email || '',
    xp: userProgress.xp,
    level: userProgress.level,
    completedRooms: userProgress.completedRooms.length,
    badges: userProgress.badges.length,
    streak: userProgress.currentStreak,
    avatar: user?.avatar || 'https://api.dicebear.com/7.x/avataaars/svg?seed=current'
  };

  const fullLeaderboard = [...mockLeaderboard, currentUserEntry]
    .sort((a, b) => b.xp - a.xp)
    .map((user, index) => ({ ...user, rank: index + 1 }));

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Crown className="h-6 w-6 text-yellow-500" />;
      case 2: return <Medal className="h-6 w-6 text-gray-400" />;
      case 3: return <Medal className="h-6 w-6 text-amber-600" />;
      default: return <div className="w-6 h-6 flex items-center justify-center text-sm font-bold">{rank}</div>;
    }
  };

  const getRankColor = (rank: number) => {
    switch (rank) {
      case 1: return 'border-yellow-500 bg-yellow-50 dark:bg-yellow-950';
      case 2: return 'border-gray-400 bg-gray-50 dark:bg-gray-950';
      case 3: return 'border-amber-600 bg-amber-50 dark:bg-amber-950';
      default: return '';
    }
  };

  const currentUserRank = fullLeaderboard.find(u => u.id === currentUserEntry.id)?.rank || 0;

  const LeaderboardCard: React.FC<{ user: any; isCurrentUser?: boolean }> = ({ user, isCurrentUser = false }) => (
    <Card className={cn(
      "transition-all duration-200 hover:shadow-md",
      getRankColor(user.rank),
      isCurrentUser && "ring-2 ring-primary"
    )}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              {getRankIcon(user.rank)}
            </div>
            
            <Avatar className="h-12 w-12">
              <AvatarImage src={user.avatar} alt={user.name} />
              <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
            </Avatar>
            
            <div>
              <div className="font-semibold flex items-center gap-2">
                {user.name}
                {isCurrentUser && <Badge variant="secondary">You</Badge>}
              </div>
              <div className="text-sm text-muted-foreground">Level {user.level}</div>
            </div>
          </div>
          
          <div className="text-right">
            <div className="font-bold text-lg flex items-center gap-1">
              <Zap className="h-4 w-4 text-yellow-500" />
              {user.xp}
            </div>
            <div className="text-sm text-muted-foreground">
              {user.completedRooms} rooms • {user.badges} badges
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  const stats = [
    { 
      label: 'Your Rank', 
      value: `#${currentUserRank}`, 
      icon: Trophy, 
      color: 'text-yellow-500',
      description: `out of ${fullLeaderboard.length} players`
    },
    { 
      label: 'Total XP', 
      value: userProgress.xp, 
      icon: Zap, 
      color: 'text-blue-500',
      description: 'experience points earned'
    },
    { 
      label: 'Rooms Completed', 
      value: userProgress.completedRooms.length, 
      icon: Target, 
      color: 'text-green-500',
      description: 'challenges solved'
    },
    { 
      label: 'Current Streak', 
      value: userProgress.currentStreak, 
      icon: TrendingUp, 
      color: 'text-purple-500',
      description: 'consecutive days active'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold">Leaderboard</h1>
        <p className="text-muted-foreground">
          Compete with fellow cybersecurity enthusiasts
        </p>
      </div>

      {/* User Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label}>
              <CardContent className="p-4 text-center">
                <Icon className={`h-8 w-8 mx-auto mb-2 ${stat.color}`} />
                <div className="text-2xl font-bold">{stat.value}</div>
                <div className="text-sm font-medium">{stat.label}</div>
                <div className="text-xs text-muted-foreground mt-1">{stat.description}</div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Leaderboard Tabs */}
      <Tabs defaultValue="overall" className="w-full">
        <TabsList className="grid w-full grid-cols-3 max-w-md mx-auto">
          <TabsTrigger value="overall">Overall</TabsTrigger>
          <TabsTrigger value="weekly">Weekly</TabsTrigger>
          <TabsTrigger value="monthly">Monthly</TabsTrigger>
        </TabsList>

        <TabsContent value="overall" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="h-5 w-5 text-yellow-500" />
                Global Rankings
              </CardTitle>
              <CardDescription>
                Top performers across all challenges
              </CardDescription>
            </CardHeader>
          </Card>

          {/* Top 3 Podium */}
          <div className="grid md:grid-cols-3 gap-4 mb-6">
            {fullLeaderboard.slice(0, 3).map((user, index) => {
              const isCurrentUser = user.id === currentUserEntry.id;
              return (
                <Card key={user.id} className={cn(
                  "text-center",
                  getRankColor(user.rank),
                  isCurrentUser && "ring-2 ring-primary"
                )}>
                  <CardContent className="p-6">
                    <div className="flex justify-center mb-4">
                      {getRankIcon(user.rank)}
                    </div>
                    
                    <Avatar className="h-16 w-16 mx-auto mb-4">
                      <AvatarImage src={user.avatar} alt={user.name} />
                      <AvatarFallback className="text-lg">{user.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    
                    <div className="space-y-2">
                      <div className="font-bold text-lg flex items-center justify-center gap-2">
                        {user.name}
                        {isCurrentUser && <Badge variant="secondary">You</Badge>}
                      </div>
                      <div className="text-2xl font-bold text-primary">{user.xp} XP</div>
                      <div className="text-sm text-muted-foreground">
                        Level {user.level} • {user.completedRooms} rooms
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Full Rankings */}
          <div className="space-y-3">
            {fullLeaderboard.slice(3).map((user) => (
              <LeaderboardCard 
                key={user.id} 
                user={user} 
                isCurrentUser={user.id === currentUserEntry.id}
              />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="weekly" className="space-y-4">
          <Card>
            <CardContent className="p-8 text-center">
              <TrendingUp className="h-16 w-16 mx-auto mb-4 text-muted-foreground opacity-50" />
              <h3 className="text-lg font-medium mb-2">Weekly Rankings</h3>
              <p className="text-muted-foreground">Coming soon! Weekly leaderboards will track your progress over the past 7 days.</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="monthly" className="space-y-4">
          <Card>
            <CardContent className="p-8 text-center">
              <Star className="h-16 w-16 mx-auto mb-4 text-muted-foreground opacity-50" />
              <h3 className="text-lg font-medium mb-2">Monthly Rankings</h3>
              <p className="text-muted-foreground">Coming soon! Monthly leaderboards will showcase the top performers each month.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Leaderboard;