// Profile Page Component
import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useGame } from '../contexts/GameContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  User, 
  Trophy, 
  Target, 
  Calendar, 
  Zap, 
  Shield, 
  Award, 
  TrendingUp, 
  Clock,
  CheckCircle,
  Star,
  BookOpen
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface ProfileProps {
  onNavigate: (page: string) => void;
}

const Profile: React.FC<ProfileProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const { userProgress, rooms, learningPaths } = useGame();

  const nextLevelXP = userProgress.level * 500;
  const currentLevelProgress = ((userProgress.xp % 500) / 500) * 100;
  const completedRooms = rooms.filter(room => userProgress.completedRooms.includes(room.id));
  const completedPaths = learningPaths.filter(path => path.completed);

  const profileStats = [
    { label: 'Total XP', value: userProgress.xp, icon: Zap, color: 'text-yellow-500' },
    { label: 'Level', value: userProgress.level, icon: Star, color: 'text-blue-500' },
    { label: 'Rooms Completed', value: userProgress.completedRooms.length, icon: Target, color: 'text-green-500' },
    { label: 'Badges Earned', value: userProgress.badges.length, icon: Trophy, color: 'text-purple-500' },
    { label: 'Current Streak', value: userProgress.currentStreak, icon: TrendingUp, color: 'text-red-500' },
    { label: 'Paths Completed', value: completedPaths.length, icon: BookOpen, color: 'text-indigo-500' }
  ];

  const recentActivity = [
    { type: 'room', title: 'Completed Bank Attack Mission', time: '2 hours ago', xp: 250 },
    { type: 'badge', title: 'Earned "Bank Infiltrator" badge', time: '2 hours ago' },
    { type: 'room', title: 'Completed SOC Analyst Defense', time: '1 day ago', xp: 300 },
    { type: 'level', title: 'Reached Level 3', time: '2 days ago' },
    { type: 'badge', title: 'Earned "SOC Defender" badge', time: '2 days ago' }
  ];

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'room': return <Target className="h-4 w-4 text-green-500" />;
      case 'badge': return <Award className="h-4 w-4 text-yellow-500" />;
      case 'level': return <Star className="h-4 w-4 text-blue-500" />;
      default: return <CheckCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Profile Header */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row items-center gap-6">
            <Avatar className="h-24 w-24">
              <AvatarImage src={user?.avatar} alt={user?.name} />
              <AvatarFallback className="text-2xl">
                {user?.name?.charAt(0)?.toUpperCase() || 'U'}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1 text-center md:text-left">
              <h1 className="text-3xl font-bold mb-2">{user?.name}</h1>
              <p className="text-muted-foreground mb-4">{user?.email}</p>
              
              <div className="flex flex-wrap justify-center md:justify-start gap-2 mb-4">
                <Badge variant="secondary" className="text-sm">
                  Level {userProgress.level} Agent
                </Badge>
                {userProgress.selectedCareerTrack && (
                  <Badge variant="outline" className="text-sm">
                    {userProgress.selectedCareerTrack} Track
                  </Badge>
                )}
                <Badge variant="outline" className="text-sm">
                  Member since {new Date().toLocaleDateString()}
                </Badge>
              </div>
              
              {/* Level Progress */}
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Progress to Level {userProgress.level + 1}</span>
                  <span>{nextLevelXP - userProgress.xp} XP needed</span>
                </div>
                <Progress value={currentLevelProgress} className="h-2" />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Profile Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {profileStats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label}>
              <CardContent className="p-4 text-center">
                <Icon className={`h-6 w-6 mx-auto mb-2 ${stat.color}`} />
                <div className="text-xl font-bold">{stat.value}</div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Profile Content Tabs */}
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="badges">Badges</TabsTrigger>
          <TabsTrigger value="activity">Activity</TabsTrigger>
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Completed Rooms */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-green-500" />
                  Completed Rooms
                </CardTitle>
                <CardDescription>
                  Your cybersecurity challenge victories
                </CardDescription>
              </CardHeader>
              <CardContent>
                {completedRooms.length > 0 ? (
                  <div className="space-y-3">
                    {completedRooms.map((room) => (
                      <div key={room.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <div className="font-medium">{room.title}</div>
                          <div className="text-sm text-muted-foreground">{room.difficulty}</div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary">{room.xp} XP</Badge>
                          <CheckCircle className="h-4 w-4 text-green-500" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <Shield className="h-12 w-12 mx-auto mb-3 opacity-50" />
                    <p>No rooms completed yet. Start your journey!</p>
                    <Button onClick={() => onNavigate('rooms')} className="mt-4">
                      Browse Rooms
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Learning Path Progress */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5 text-blue-500" />
                  Learning Paths
                </CardTitle>
                <CardDescription>
                  Your progress through cybersecurity career tracks
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {learningPaths.slice(0, 3).map((path) => (
                    <div key={path.id} className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm font-medium">{path.title}</span>
                        <span className="text-sm text-muted-foreground">{path.progressPercent}%</span>
                      </div>
                      <Progress value={path.progressPercent} className="h-2" />
                    </div>
                  ))}
                  <Button 
                    onClick={() => onNavigate('roadmap')} 
                    variant="outline" 
                    className="w-full mt-4"
                  >
                    View Full Roadmap
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="badges" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="h-5 w-5 text-yellow-500" />
                Badge Collection
              </CardTitle>
              <CardDescription>
                Achievements unlocked through your cybersecurity journey
              </CardDescription>
            </CardHeader>
            <CardContent>
              {userProgress.badges.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {userProgress.badges.map((badge) => (
                    <div key={badge.id} className="p-4 border rounded-lg text-center space-y-2">
                      <div className="text-3xl">{badge.icon}</div>
                      <div className="font-medium">{badge.name}</div>
                      <div className="text-sm text-muted-foreground">{badge.description}</div>
                      {badge.dateEarned && (
                        <div className="text-xs text-muted-foreground">
                          Earned: {new Date(badge.dateEarned).toLocaleDateString()}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Trophy className="h-16 w-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                  <h3 className="text-lg font-medium mb-2">No badges yet</h3>
                  <p className="text-muted-foreground">Complete rooms and challenges to earn your first badge!</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="activity" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-blue-500" />
                Recent Activity
              </CardTitle>
              <CardDescription>
                Your latest accomplishments and progress
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-center gap-3 p-3 border rounded-lg">
                    {getActivityIcon(activity.type)}
                    <div className="flex-1">
                      <div className="font-medium">{activity.title}</div>
                      <div className="text-sm text-muted-foreground">{activity.time}</div>
                    </div>
                    {activity.xp && (
                      <Badge variant="secondary">+{activity.xp} XP</Badge>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="achievements" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="h-5 w-5 text-purple-500" />
                Achievements & Milestones
              </CardTitle>
              <CardDescription>
                Special accomplishments and progress milestones
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                <div className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">First Steps</span>
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  </div>
                  <p className="text-sm text-muted-foreground">Complete your first room</p>
                </div>
                
                <div className="p-4 border rounded-lg opacity-50">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">Speed Demon</span>
                    <div className="h-5 w-5 border border-muted rounded-full" />
                  </div>
                  <p className="text-sm text-muted-foreground">Complete 5 rooms in one day</p>
                </div>
                
                <div className="p-4 border rounded-lg opacity-50">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">Master Hacker</span>
                    <div className="h-5 w-5 border border-muted rounded-full" />
                  </div>
                  <p className="text-sm text-muted-foreground">Complete all available rooms</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Profile;