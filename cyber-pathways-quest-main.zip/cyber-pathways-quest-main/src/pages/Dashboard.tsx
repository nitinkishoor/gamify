// Dashboard Page Component
import React from 'react';
import { useGame } from '../contexts/GameContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Trophy, Zap, Target, Calendar, TrendingUp, Shield, Users, Star } from 'lucide-react';

interface DashboardProps {
  onNavigate: (page: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  const { userProgress, learningPaths, rooms } = useGame();

  const nextLevelXP = userProgress.level * 500;
  const currentLevelProgress = ((userProgress.xp % 500) / 500) * 100;

  const featuredRooms = rooms.filter(room => ['bank-attack', 'soc-analyst-intro'].includes(room.id));
  const completedPaths = learningPaths.filter(path => path.completed).length;
  const totalPaths = learningPaths.length;

  const quickStats = [
    { label: 'Total XP', value: userProgress.xp, icon: Zap, color: 'text-yellow-500' },
    { label: 'Rooms Completed', value: userProgress.completedRooms.length, icon: Target, color: 'text-green-500' },
    { label: 'Badges Earned', value: userProgress.badges.length, icon: Trophy, color: 'text-blue-500' },
    { label: 'Current Streak', value: userProgress.currentStreak, icon: TrendingUp, color: 'text-purple-500' }
  ];

  const recentAchievements = userProgress.badges.slice(-3).reverse();

  return (
    <div className="space-y-8">
      {/* Welcome Header */}
      <div className="text-center space-y-2">
        <h1 className="text-4xl font-bold">Mission Control</h1>
        <p className="text-xl text-muted-foreground">
          Welcome back, Agent! Ready for your next cybersecurity challenge?
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {quickStats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label}>
              <CardContent className="p-6">
                <div className="flex items-center space-x-3">
                  <Icon className={`h-8 w-8 ${stat.color}`} />
                  <div>
                    <div className="text-2xl font-bold">{stat.value}</div>
                    <div className="text-sm text-muted-foreground">{stat.label}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Level Progress */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Star className="h-5 w-5 text-yellow-500" />
                Level {userProgress.level} Agent
              </CardTitle>
              <CardDescription>
                {nextLevelXP - userProgress.xp} XP needed for next level
              </CardDescription>
            </div>
            <Badge variant="secondary" className="text-lg px-4 py-2">
              Level {userProgress.level}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Progress to Level {userProgress.level + 1}</span>
              <span>{Math.round(currentLevelProgress)}%</span>
            </div>
            <Progress value={currentLevelProgress} className="h-3" />
          </div>
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Featured Missions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              Featured Missions
            </CardTitle>
            <CardDescription>
              High-impact challenges to boost your skills
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {featuredRooms.map((room) => (
              <div key={room.id} className="p-4 border rounded-lg space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold">{room.title}</h3>
                  <Badge variant={room.difficulty === 'easy' ? 'secondary' : room.difficulty === 'medium' ? 'default' : 'destructive'}>
                    {room.difficulty}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">{room.description}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm">
                    <Zap className="h-4 w-4 text-yellow-500" />
                    <span>{room.xp} XP</span>
                  </div>
                  <Button 
                    size="sm" 
                    onClick={() => onNavigate('rooms')}
                    className="bg-primary hover:bg-primary/90"
                  >
                    Start Mission
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Learning Progress */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-500" />
              Learning Progress
            </CardTitle>
            <CardDescription>
              Your cybersecurity career advancement
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-center p-6 bg-primary/5 rounded-lg">
              <div className="text-3xl font-bold text-primary mb-2">
                {completedPaths}/{totalPaths}
              </div>
              <div className="text-sm text-muted-foreground">
                Learning Paths Completed
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span>Overall Progress</span>
                <span>{Math.round((completedPaths / totalPaths) * 100)}%</span>
              </div>
              <Progress value={(completedPaths / totalPaths) * 100} className="h-2" />
            </div>

            <Button 
              onClick={() => onNavigate('roadmap')} 
              className="w-full"
              variant="outline"
            >
              View Learning Roadmap
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Recent Achievements & Actions */}
      <div className="grid lg:grid-cols-2 gap-8">
        {/* Recent Achievements */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="h-5 w-5 text-yellow-500" />
              Recent Achievements
            </CardTitle>
          </CardHeader>
          <CardContent>
            {recentAchievements.length > 0 ? (
              <div className="space-y-3">
                {recentAchievements.map((badge) => (
                  <div key={badge.id} className="flex items-center gap-3 p-3 bg-card border rounded-lg">
                    <div className="text-2xl">{badge.icon}</div>
                    <div>
                      <div className="font-medium">{badge.name}</div>
                      <div className="text-sm text-muted-foreground">
                        {badge.dateEarned && new Date(badge.dateEarned).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Trophy className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>Complete your first room to earn badges!</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5 text-red-500" />
              Quick Actions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button 
              onClick={() => onNavigate('rooms')} 
              className="w-full justify-start"
              variant="outline"
            >
              <Shield className="mr-2 h-4 w-4" />
              Browse All Rooms
            </Button>
            
            <Button 
              onClick={() => onNavigate('roadmap')} 
              className="w-full justify-start"
              variant="outline"
            >
              <TrendingUp className="mr-2 h-4 w-4" />
              View Learning Roadmap
            </Button>
            
            <Button 
              onClick={() => onNavigate('leaderboard')} 
              className="w-full justify-start"
              variant="outline"
            >
              <Users className="mr-2 h-4 w-4" />
              Check Leaderboard
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;