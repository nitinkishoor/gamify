// Main Index Component - Gamify CTF Platform with Learning Paths
import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import ProtectedRoute from '../components/ProtectedRoute';
import Navbar from '../components/Navbar';
import Login from './Login';
import Dashboard from './Dashboard';
import LearningRoadmap from '../components/LearningRoadmap';
import Rooms from './Rooms';
import RoomDetail from './RoomDetail';
import Leaderboard from './Leaderboard';
import Profile from './Profile';

const Index = () => {
  const { user } = useAuth();
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [selectedRoomId, setSelectedRoomId] = useState<string>('');

  const handleNavigate = (page: string, roomId?: string) => {
    setCurrentPage(page);
    if (roomId) {
      setSelectedRoomId(roomId);
    }
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard onNavigate={handleNavigate} />;
      case 'roadmap':
        return <LearningRoadmap />;
      case 'rooms':
        return <Rooms onNavigate={handleNavigate} />;
      case 'room-detail':
        return <RoomDetail roomId={selectedRoomId} onNavigate={handleNavigate} />;
      case 'leaderboard':
        return <Leaderboard />;
      case 'profile':
        return <Profile onNavigate={handleNavigate} />;
      default:
        return <Dashboard onNavigate={handleNavigate} />;
    }
  };

  return (
    <ProtectedRoute fallback={<Login />}>
      <div className="min-h-screen bg-background">
        <Navbar currentPage={currentPage} onNavigate={handleNavigate} />
        <main className="container mx-auto px-4 py-8">
          {renderPage()}
        </main>
      </div>
    </ProtectedRoute>
  );
};

export default Index;
