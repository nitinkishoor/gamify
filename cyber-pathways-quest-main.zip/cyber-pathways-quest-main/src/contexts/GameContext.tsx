// Game Context for managing user progress, XP, badges, room completions, and learning paths
import React, { createContext, useContext, useState, useEffect } from 'react';

interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlocked: boolean;
  dateEarned?: string;
}

interface LearningPath {
  id: string;
  title: string;
  description: string;
  difficulty: 'easy' | 'medium' | 'hard';
  careerTrack: 'analyst' | 'pentester' | 'engineer';
  prerequisites: string[];
  xpRequired: number;
  rooms: string[];
  badge: string;
  progressPercent: number;
  completed: boolean;
  locked: boolean;
  position: { x: number; y: number };
}

interface Room {
  id: string;
  title: string;
  description: string;
  difficulty: 'easy' | 'medium' | 'hard';
  xp: number;
  badge: string;
  type: 'gui' | 'terminal';
  category: 'offensive' | 'defensive' | 'fundamentals';
  locked: boolean;
  premium: boolean;
}

interface UserProgress {
  xp: number;
  level: number;
  completedRooms: string[];
  badges: Badge[];
  currentStreak: number;
  lastActivityDate: string;
  learningPaths: { [pathId: string]: { progressPercent: number; completed: boolean } };
  selectedCareerTrack: 'analyst' | 'pentester' | 'engineer' | null;
}

interface GameContextType {
  userProgress: UserProgress;
  learningPaths: LearningPath[];
  rooms: Room[];
  updateProgress: (progress: Partial<UserProgress>) => void;
  completeRoom: (roomId: string) => void;
  unlockBadge: (badgeId: string) => void;
  submitFlag: (roomId: string, flag: string) => Promise<boolean>;
  updateLearningPath: (pathId: string, progressPercent: number) => void;
  selectCareerTrack: (track: 'analyst' | 'pentester' | 'engineer') => void;
  getAvailableRooms: () => Room[];
  getPathProgress: (pathId: string) => number;
}

const GameContext = createContext<GameContextType | undefined>(undefined);

// Learning Paths Data - Progressive Career Tracks
const LEARNING_PATHS: LearningPath[] = [
  // Analyst Track
  {
    id: 'pre-security',
    title: 'Pre Security',
    description: 'Foundation knowledge for cybersecurity',
    difficulty: 'easy',
    careerTrack: 'analyst',
    prerequisites: [],
    xpRequired: 0,
    rooms: ['linux-fundamentals', 'network-basics'],
    badge: 'Security Foundation',
    progressPercent: 0,
    completed: false,
    locked: false,
    position: { x: 100, y: 100 }
  },
  {
    id: 'cyber-foundations',
    title: 'Cyber Security Foundations',
    description: 'Core defensive security principles',
    difficulty: 'medium',
    careerTrack: 'analyst',
    prerequisites: ['pre-security'],
    xpRequired: 500,
    rooms: ['soc-analyst-intro', 'incident-response'],
    badge: 'SOC Defender',
    progressPercent: 0,
    completed: false,
    locked: true,
    position: { x: 100, y: 200 }
  },
  {
    id: 'cyber-101',
    title: 'Cyber Security 101',
    description: 'Advanced defensive techniques',
    difficulty: 'hard',
    careerTrack: 'analyst',
    prerequisites: ['cyber-foundations'],
    xpRequired: 1000,
    rooms: ['advanced-soc', 'threat-hunting'],
    badge: 'Security Expert',
    progressPercent: 0,
    completed: false,
    locked: true,
    position: { x: 100, y: 300 }
  },
  
  // Pentester Track
  {
    id: 'offensive-basics',
    title: 'Offensive Security Basics',
    description: 'Introduction to ethical hacking',
    difficulty: 'easy',
    careerTrack: 'pentester',
    prerequisites: ['pre-security'],
    xpRequired: 300,
    rooms: ['bank-attack', 'web-exploitation'],
    badge: 'Junior Pentester',
    progressPercent: 0,
    completed: false,
    locked: true,
    position: { x: 300, y: 150 }
  },
  {
    id: 'advanced-attacks',
    title: 'Advanced Attack Techniques',
    description: 'Complex penetration testing methods',
    difficulty: 'hard',
    careerTrack: 'pentester',
    prerequisites: ['offensive-basics'],
    xpRequired: 1500,
    rooms: ['advanced-exploitation', 'privilege-escalation'],
    badge: 'Senior Pentester',
    progressPercent: 0,
    completed: false,
    locked: true,
    position: { x: 300, y: 250 }
  },
  
  // Engineer Track
  {
    id: 'security-engineering',
    title: 'Security Engineering',
    description: 'Build secure systems and applications',
    difficulty: 'medium',
    careerTrack: 'engineer',
    prerequisites: ['pre-security'],
    xpRequired: 400,
    rooms: ['secure-coding', 'system-hardening'],
    badge: 'Security Engineer',
    progressPercent: 0,
    completed: false,
    locked: true,
    position: { x: 500, y: 150 }
  },
  {
    id: 'devops-security',
    title: 'DevOps Security',
    description: 'Integrate security into CI/CD pipelines',
    difficulty: 'hard',
    careerTrack: 'engineer',
    prerequisites: ['security-engineering'],
    xpRequired: 2000,
    rooms: ['container-security', 'cloud-security'],
    badge: 'DevSecOps Expert',
    progressPercent: 0,
    completed: false,
    locked: true,
    position: { x: 500, y: 250 }
  }
];

// Rooms Data
const ROOMS: Room[] = [
  {
    id: 'linux-fundamentals',
    title: 'Linux Fundamentals',
    description: 'Master basic Linux commands and navigation',
    difficulty: 'easy',
    xp: 100,
    badge: 'Linux Explorer',
    type: 'terminal',
    category: 'fundamentals',
    locked: false,
    premium: false
  },
  {
    id: 'network-basics',
    title: 'Network Basics',
    description: 'Understand networking fundamentals',
    difficulty: 'easy',
    xp: 150,
    badge: 'Network Navigator',
    type: 'terminal',
    category: 'fundamentals',
    locked: false,
    premium: false
  },
  {
    id: 'bank-attack',
    title: 'Bank Attack Mission',
    description: 'Penetrate SecureBank Corp security systems',
    difficulty: 'medium',
    xp: 250,
    badge: 'Bank Infiltrator',
    type: 'gui',
    category: 'offensive',
    locked: false,
    premium: false
  },
  {
    id: 'soc-analyst-intro',
    title: 'SOC Analyst Defense',
    description: 'Detect and respond to cyber attacks',
    difficulty: 'medium',
    xp: 300,
    badge: 'SOC Defender',
    type: 'gui',
    category: 'defensive',
    locked: false,
    premium: false
  },
  {
    id: 'incident-response',
    title: 'Incident Response',
    description: 'Handle security incidents professionally',
    difficulty: 'medium',
    xp: 200,
    badge: 'Incident Handler',
    type: 'terminal',
    category: 'defensive',
    locked: true,
    premium: true
  },
  {
    id: 'web-exploitation',
    title: 'Web Application Exploitation',
    description: 'Find and exploit web vulnerabilities',
    difficulty: 'hard',
    xp: 400,
    badge: 'Web Hacker',
    type: 'gui',
    category: 'offensive',
    locked: true,
    premium: true
  }
];

// Default user progress
const DEFAULT_PROGRESS: UserProgress = {
  xp: 0,
  level: 1,
  completedRooms: [],
  badges: [],
  currentStreak: 0,
  lastActivityDate: new Date().toISOString().split('T')[0],
  learningPaths: {},
  selectedCareerTrack: null
};

export const GameProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [userProgress, setUserProgress] = useState<UserProgress>(DEFAULT_PROGRESS);
  const [learningPaths, setLearningPaths] = useState<LearningPath[]>(LEARNING_PATHS);

  // Load progress from localStorage
  useEffect(() => {
    const savedProgress = localStorage.getItem('gamify-progress');
    if (savedProgress) {
      setUserProgress(JSON.parse(savedProgress));
    }
  }, []);

  // Save progress to localStorage
  useEffect(() => {
    localStorage.setItem('gamify-progress', JSON.stringify(userProgress));
  }, [userProgress]);

  // Update learning paths based on user progress
  useEffect(() => {
    setLearningPaths(prev => prev.map(path => {
      const isUnlocked = path.prerequisites.every(prereq => 
        userProgress.learningPaths[prereq]?.completed
      ) && userProgress.xp >= path.xpRequired;
      
      return {
        ...path,
        locked: !isUnlocked,
        progressPercent: userProgress.learningPaths[path.id]?.progressPercent || 0,
        completed: userProgress.learningPaths[path.id]?.completed || false
      };
    }));
  }, [userProgress]);

  const updateProgress = (progress: Partial<UserProgress>) => {
    setUserProgress(prev => ({ ...prev, ...progress }));
  };

  const completeRoom = (roomId: string) => {
    const room = ROOMS.find(r => r.id === roomId);
    if (!room || userProgress.completedRooms.includes(roomId)) return;

    const newXP = userProgress.xp + room.xp;
    const newLevel = Math.floor(newXP / 500) + 1;
    
    setUserProgress(prev => ({
      ...prev,
      xp: newXP,
      level: newLevel,
      completedRooms: [...prev.completedRooms, roomId],
      currentStreak: prev.currentStreak + 1,
      lastActivityDate: new Date().toISOString().split('T')[0]
    }));

    // Update learning path progress
    const pathWithRoom = learningPaths.find(path => path.rooms.includes(roomId));
    if (pathWithRoom) {
      updateLearningPath(pathWithRoom.id, 50); // 50% progress for completing a room
    }
  };

  const unlockBadge = (badgeId: string) => {
    const existingBadge = userProgress.badges.find(b => b.id === badgeId);
    if (existingBadge) return;

    const newBadge: Badge = {
      id: badgeId,
      name: badgeId,
      description: `Earned badge: ${badgeId}`,
      icon: '🏆',
      unlocked: true,
      dateEarned: new Date().toISOString()
    };

    setUserProgress(prev => ({
      ...prev,
      badges: [...prev.badges, newBadge]
    }));
  };

  const submitFlag = async (roomId: string, flag: string): Promise<boolean> => {
    // Flag validation logic
    const correctFlags: { [key: string]: string } = {
      'bank-attack': 'GAMIFY{secure_vault_master_2024}',
      'soc-analyst-intro': 'GAMIFY{threat_contained_systems_secured}',
      'linux-fundamentals': 'GAMIFY{linux_master_explorer}',
      'network-basics': 'GAMIFY{network_navigator_pro}'
    };

    const isCorrect = correctFlags[roomId] === flag;
    
    if (isCorrect) {
      completeRoom(roomId);
      const room = ROOMS.find(r => r.id === roomId);
      if (room?.badge) {
        unlockBadge(room.badge);
      }
    }
    
    return isCorrect;
  };

  const updateLearningPath = (pathId: string, progressPercent: number) => {
    const completed = progressPercent >= 100;
    
    setUserProgress(prev => ({
      ...prev,
      learningPaths: {
        ...prev.learningPaths,
        [pathId]: { progressPercent, completed }
      }
    }));

    if (completed) {
      const path = learningPaths.find(p => p.id === pathId);
      if (path?.badge) {
        unlockBadge(path.badge);
      }
    }
  };

  const selectCareerTrack = (track: 'analyst' | 'pentester' | 'engineer') => {
    setUserProgress(prev => ({ ...prev, selectedCareerTrack: track }));
  };

  const getAvailableRooms = (): Room[] => {
    return ROOMS.map(room => ({
      ...room,
      locked: room.premium && userProgress.xp < 500
    }));
  };

  const getPathProgress = (pathId: string): number => {
    return userProgress.learningPaths[pathId]?.progressPercent || 0;
  };

  return (
    <GameContext.Provider value={{
      userProgress,
      learningPaths,
      rooms: getAvailableRooms(),
      updateProgress,
      completeRoom,
      unlockBadge,
      submitFlag,
      updateLearningPath,
      selectCareerTrack,
      getAvailableRooms,
      getPathProgress
    }}>
      {children}
    </GameContext.Provider>
  );
};

export const useGame = () => {
  const context = useContext(GameContext);
  if (context === undefined) {
    throw new Error('useGame must be used within a GameProvider');
  }
  return context;
};