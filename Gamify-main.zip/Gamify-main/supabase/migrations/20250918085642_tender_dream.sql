/*
  # Complete Bank Attack CTF System

  1. Tables
    - `flags` - Store canonical flags for each room
    - `user_flags` - Track user flag submissions
    - `xp_history` - Track XP transactions
    - `profiles` - Enhanced user profiles (if not exists)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users

  3. Functions
    - `add_xp_to_profile` - Function to safely add XP to profiles
*/

-- Create flags table
CREATE TABLE IF NOT EXISTS flags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id text UNIQUE NOT NULL,
  flag_text text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create user_flags table
CREATE TABLE IF NOT EXISTS user_flags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL,
  room_id text NOT NULL,
  flag text NOT NULL,
  is_correct boolean DEFAULT false,
  submitted_at timestamptz DEFAULT now(),
  UNIQUE(profile_id, room_id)
);

-- Create xp_history table
CREATE TABLE IF NOT EXISTS xp_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL,
  room_id text,
  xp_amount integer NOT NULL,
  reason text,
  created_at timestamptz DEFAULT now()
);

-- Create profiles table if it doesn't exist
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  name text NOT NULL DEFAULT 'New Profile',
  avatar text DEFAULT '',
  xp integer DEFAULT 0,
  level integer DEFAULT 1,
  streak integer DEFAULT 0,
  rooms_completed integer DEFAULT 0,
  badges jsonb DEFAULT '[]',
  current_path text DEFAULT 'beginner',
  unlocked_rooms text[] DEFAULT ARRAY['bank-attack', 'soc-defense', 'network-recon'],
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE flags ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_flags ENABLE ROW LEVEL SECURITY;
ALTER TABLE xp_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- RLS Policies for flags (readable by authenticated users)
CREATE POLICY "Authenticated users can read flags"
  ON flags
  FOR SELECT
  TO authenticated
  USING (true);

-- RLS Policies for user_flags
CREATE POLICY "Users can insert own flag submissions"
  ON user_flags
  FOR INSERT
  TO authenticated
  WITH CHECK (profile_id IN (
    SELECT id FROM profiles WHERE user_id = auth.uid()
  ));

CREATE POLICY "Users can read own flag submissions"
  ON user_flags
  FOR SELECT
  TO authenticated
  USING (profile_id IN (
    SELECT id FROM profiles WHERE user_id = auth.uid()
  ));

-- RLS Policies for xp_history
CREATE POLICY "Users can insert own XP history"
  ON xp_history
  FOR INSERT
  TO authenticated
  WITH CHECK (profile_id IN (
    SELECT id FROM profiles WHERE user_id = auth.uid()
  ));

CREATE POLICY "Users can read own XP history"
  ON xp_history
  FOR SELECT
  TO authenticated
  USING (profile_id IN (
    SELECT id FROM profiles WHERE user_id = auth.uid()
  ));

-- RLS Policies for profiles
CREATE POLICY "Users can view their own profiles"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can create their own profiles"
  ON profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update their own profiles"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can delete their own profiles"
  ON profiles
  FOR DELETE
  TO authenticated
  USING (user_id = auth.uid());

-- Function to safely add XP to profile
CREATE OR REPLACE FUNCTION add_xp_to_profile(profile_id_param uuid, xp_to_add integer)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE profiles 
  SET 
    xp = xp + xp_to_add,
    level = GREATEST(1, FLOOR((xp + xp_to_add) / 250) + 1),
    updated_at = now()
  WHERE id = profile_id_param;
END;
$$;

-- Insert Bank Attack flag
INSERT INTO flags (room_id, flag_text) 
VALUES ('bank_attack', 'GAMIFY{BANK_HACKED}')
ON CONFLICT (room_id) DO UPDATE SET flag_text = EXCLUDED.flag_text;

-- Insert other room flags for completeness
INSERT INTO flags (room_id, flag_text) VALUES 
  ('soc_defense', 'GAMIFY{SOC_DEFENDER}'),
  ('network_recon', 'GAMIFY{NETWORK_MAPPED}'),
  ('web_exploit', 'GAMIFY{WEB_HACKED}'),
  ('forensics_investigation', 'GAMIFY{EVIDENCE_FOUND}'),
  ('premium_vault', 'GAMIFY{VAULT_CRACKED}')
ON CONFLICT (room_id) DO UPDATE SET flag_text = EXCLUDED.flag_text;