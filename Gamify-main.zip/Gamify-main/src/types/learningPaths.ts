// Learning Path System Types
export interface LearningPath {
  id: string;
  title: string;
  description: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  category: 'foundations' | 'analyst' | 'pentester' | 'engineer';
  xpRequired: number;
  xpReward: number;
  estimatedHours: number;
  prerequisites: string[];
  unlocks: string[];
  rooms: string[];
  quizzes: string[];
  isCompleted: boolean;
  progressPercent: number;
  position: {
    x: number;
    y: number;
  };
  icon: string;
  color: string;
}

export interface CareerTrack {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  paths: string[];
  totalXP: number;
  completionBadge: {
    id: string;
    name: string;
    description: string;
    icon: string;
  };
}

export interface UserProgress {
  userId: string;
  pathId: string;
  progressPercent: number;
  completed: boolean;
  startedAt: string;
  completedAt?: string;
  currentRoom?: string;
  roomsCompleted: string[];
  quizzesCompleted: string[];
}

export interface PathNode {
  path: LearningPath;
  isUnlocked: boolean;
  isActive: boolean;
  connections: string[];
}