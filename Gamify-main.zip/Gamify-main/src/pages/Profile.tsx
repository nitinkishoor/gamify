import React from 'react';
import { Calendar, Award, Target, TrendingUp, BookOpen, Zap, Star, Clock } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useGame } from '../contexts/GameContext';

const Profile: React.FC = () => {
  const { user } = useAuth();
  const { stats } = useGame();

  const recentActivity = [
    {
      id: 1,
      type: 'room_completed',
      title: 'Completed "Linux Fundamentals"',
      xp: 100,
      timestamp: '2 hours ago',
      icon: BookOpen
    },
    {
      id: 2,
      type: 'badge_earned',
      title: 'Earned "Week Warrior" badge',
      xp: 50,
      timestamp: '1 day ago',
      icon: Award
    },
    {
      id: 3,
      type: 'level_up',
      title: 'Reached Level 5',
      xp: 0,
      timestamp: '2 days ago',
      icon: Star
    },
    {
      id: 4,
      type: 'room_completed',
      title: 'Completed "Network Basics"',
      xp: 150,
      timestamp: '3 days ago',
      icon: BookOpen
    }
  ];

  const skillProgress = [
    { name: 'Linux Administration', level: 8, maxLevel: 10, color: 'bg-green-400' },
    { name: 'Network Security', level: 6, maxLevel: 10, color: 'bg-blue-400' },
    { name: 'Web Application Security', level: 4, maxLevel: 10, color: 'bg-purple-400' },
    { name: 'Cryptography', level: 3, maxLevel: 10, color: 'bg-yellow-400' },
    { name: 'Digital Forensics', level: 2, maxLevel: 10, color: 'bg-red-400' }
  ];

  if (!user) return null;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Profile Header */}
      <div className="bg-gradient-to-r from-gray-800 to-gray-700 rounded-xl p-8 mb-8 border border-gray-600">
        <div className="flex flex-col lg:flex-row items-center lg:items-start space-y-6 lg:space-y-0 lg:space-x-8">
          <div className="relative">
            <img
              src={user.avatar}
              alt={user.name}
              className="w-24 h-24 rounded-full border-4 border-green-400"
            />
            <div className="absolute -bottom-2 -right-2 bg-green-500 text-white text-sm font-bold px-2 py-1 rounded-full">
              Lv.{stats.level}
            </div>
          </div>
          
          <div className="flex-1 text-center lg:text-left">
            <h1 className="text-3xl font-bold text-white mb-2">{user.name}</h1>
            <p className="text-gray-400 mb-4">{user.email}</p>
            
            <div className="flex flex-wrap justify-center lg:justify-start gap-4 mb-6">
              <div className="bg-gray-700 px-4 py-2 rounded-lg">
                <div className="text-green-400 font-bold text-lg">{stats.xp}</div>
                <div className="text-gray-400 text-sm">Total XP</div>
              </div>
              <div className="bg-gray-700 px-4 py-2 rounded-lg">
                <div className="text-blue-400 font-bold text-lg">{stats.level}</div>
                <div className="text-gray-400 text-sm">Level</div>
              </div>
              <div className="bg-gray-700 px-4 py-2 rounded-lg">
                <div className="text-orange-400 font-bold text-lg">{stats.streak}</div>
                <div className="text-gray-400 text-sm">Day Streak</div>
              </div>
              <div className="bg-gray-700 px-4 py-2 rounded-lg">
                <div className="text-purple-400 font-bold text-lg">{stats.roomsCompleted}</div>
                <div className="text-gray-400 text-sm">Rooms</div>
              </div>
            </div>

            <div className="flex items-center justify-center lg:justify-start text-gray-400 text-sm">
              <Calendar className="h-4 w-4 mr-2" />
              Joined {new Date(user.joinedAt).toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column */}
        <div className="lg:col-span-2 space-y-8">
          {/* XP Progress */}
          <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
            <h2 className="text-xl font-bold text-white mb-4 flex items-center">
              <TrendingUp className="h-5 w-5 text-green-400 mr-2" />
              Level Progress
            </h2>
            
            <div className="flex items-center justify-between mb-2">
              <span className="text-white font-medium">Level {stats.level}</span>
              <span className="text-gray-400 text-sm">
                {stats.xp % 250} / 250 XP to Level {stats.level + 1}
              </span>
            </div>
            
            <div className="w-full bg-gray-700 rounded-full h-4 mb-4">
              <div 
                className="bg-gradient-to-r from-green-400 to-blue-500 h-4 rounded-full transition-all duration-300"
                style={{ width: `${(stats.xp % 250) / 250 * 100}%` }}
              ></div>
            </div>
            
            <p className="text-gray-400 text-sm">
              You need {250 - (stats.xp % 250)} more XP to reach the next level!
            </p>
          </div>

          {/* Skills Progress */}
          <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
            <h2 className="text-xl font-bold text-white mb-6 flex items-center">
              <Target className="h-5 w-5 text-blue-400 mr-2" />
              Skill Progress
            </h2>
            
            <div className="space-y-4">
              {skillProgress.map((skill, index) => (
                <div key={index}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-white font-medium">{skill.name}</span>
                    <span className="text-gray-400 text-sm">
                      {skill.level} / {skill.maxLevel}
                    </span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div 
                      className={`${skill.color} h-2 rounded-full transition-all duration-300`}
                      style={{ width: `${(skill.level / skill.maxLevel) * 100}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
            <h2 className="text-xl font-bold text-white mb-6 flex items-center">
              <Clock className="h-5 w-5 text-purple-400 mr-2" />
              Recent Activity
            </h2>
            
            <div className="space-y-4">
              {recentActivity.map((activity) => {
                const IconComponent = activity.icon;
                return (
                  <div key={activity.id} className="flex items-center space-x-4 p-4 bg-gray-700 rounded-lg">
                    <div className="bg-gray-600 p-2 rounded-lg">
                      <IconComponent className="h-5 w-5 text-green-400" />
                    </div>
                    <div className="flex-1">
                      <p className="text-white font-medium">{activity.title}</p>
                      <p className="text-gray-400 text-sm">{activity.timestamp}</p>
                    </div>
                    {activity.xp > 0 && (
                      <div className="bg-green-500/20 text-green-400 px-2 py-1 rounded text-sm font-semibold">
                        +{activity.xp} XP
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column */}
        <div className="space-y-8">
          {/* Badges */}
          <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
            <h2 className="text-xl font-bold text-white mb-6 flex items-center">
              <Award className="h-5 w-5 text-yellow-400 mr-2" />
              Badges ({stats.badges.length})
            </h2>
            
            <div className="grid grid-cols-2 gap-4">
              {stats.badges.map((badge) => (
                <div key={badge.id} className="bg-gray-700 p-4 rounded-lg text-center hover:bg-gray-600 transition-colors">
                  <div className="text-3xl mb-2">{badge.icon}</div>
                  <h3 className="text-white font-semibold text-sm">{badge.name}</h3>
                  <p className="text-gray-400 text-xs mt-1">{badge.description}</p>
                  {badge.unlockedAt && (
                    <p className="text-green-400 text-xs mt-2">
                      {new Date(badge.unlockedAt).toLocaleDateString()}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Stats Overview */}
          <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
            <h2 className="text-xl font-bold text-white mb-6 flex items-center">
              <TrendingUp className="h-5 w-5 text-green-400 mr-2" />
              Quick Stats
            </h2>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Zap className="h-4 w-4 text-orange-400 mr-2" />
                  <span className="text-gray-400">Current Streak</span>
                </div>
                <span className="text-orange-400 font-bold">{stats.streak} days</span>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <BookOpen className="h-4 w-4 text-blue-400 mr-2" />
                  <span className="text-gray-400">Rooms Completed</span>
                </div>
                <span className="text-blue-400 font-bold">{stats.roomsCompleted}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Award className="h-4 w-4 text-yellow-400 mr-2" />
                  <span className="text-gray-400">Badges Earned</span>
                </div>
                <span className="text-yellow-400 font-bold">{stats.badges.length}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Target className="h-4 w-4 text-purple-400 mr-2" />
                  <span className="text-gray-400">Current Level</span>
                </div>
                <span className="text-purple-400 font-bold">{stats.level}</span>
              </div>
            </div>
          </div>

          {/* Learning Path */}
          <div className="bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded-xl p-6 border border-green-500/30">
            <h3 className="text-lg font-bold text-white mb-4">Current Path</h3>
            <div className="flex items-center mb-3">
              <div className="bg-blue-500/20 p-2 rounded-lg mr-3">
                <Target className="h-6 w-6 text-blue-400" />
              </div>
              <div>
                <p className="text-white font-semibold">Intermediate Path</p>
                <p className="text-gray-300 text-sm">60% Complete</p>
              </div>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2 mb-4">
              <div className="bg-blue-400 h-2 rounded-full" style={{ width: '60%' }}></div>
            </div>
            <p className="text-gray-300 text-sm">
              Continue learning to unlock advanced cybersecurity techniques!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;