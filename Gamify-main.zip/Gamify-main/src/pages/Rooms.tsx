import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Filter, Clock, Users, Award, BookOpen, Terminal, Shield, Network, Monitor, Eye, Lock, Globe } from 'lucide-react';

interface Room {
  id: string;
  name: string;
  description: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  category: string;
  xp: number;
  estimatedTime: string;
  completedBy: number;
  tags: string[];
  isCompleted?: boolean;
  icon: React.ComponentType<{ className?: string }>;
}

const Rooms: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('All');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const rooms: Room[] = [
    {
      id: 'bank-attack',
      name: 'Bank Attack Mission',
      description: 'Infiltrate SecureBank Corp through web exploitation. Find hidden admin pages and execute unauthorized transfers.',
      difficulty: 'Easy',
      category: 'Offensive Security',
      xp: 250,
      estimatedTime: '30-45 minutes',
      completedBy: 8420,
      tags: ['web exploitation', 'admin bypass', 'unauthorized access'],
      isCompleted: false,
      icon: Globe
    },
    {
      id: 'soc-defense',
      name: 'SOC Analyst Defense',
      description: 'Detect and respond to live cyber attacks using SOC monitoring tools. Analyze logs and secure compromised systems.',
      difficulty: 'Medium',
      category: 'Defensive Security',
      xp: 300,
      estimatedTime: '45-60 minutes',
      completedBy: 5240,
      tags: ['log analysis', 'network monitoring', 'incident response', 'SOC'],
      isCompleted: false,
      icon: Shield
    },
    {
      id: 'premium-vault',
      name: 'Corporate Vault Heist',
      description: 'Advanced multi-stage attack on a corporate network. Requires completion of previous rooms to unlock.',
      difficulty: 'Hard',
      category: 'Premium Challenge',
      xp: 500,
      estimatedTime: '90-120 minutes',
      completedBy: 1240,
      tags: ['advanced', 'multi-stage', 'steganography'],
      isCompleted: false,
      icon: Lock
    },
    {
      id: 'network-recon',
      name: 'Network Reconnaissance',
      description: 'Master network scanning and enumeration using Kali GUI tools to map target infrastructure.',
      difficulty: 'Easy',
      category: 'Reconnaissance',
      xp: 200,
      estimatedTime: '30-45 minutes',
      completedBy: 12340,
      tags: ['nmap', 'network scanning', 'enumeration'],
      isCompleted: true,
      icon: Shield
    },
    {
      id: 'web-exploit',
      name: 'Web Application Exploit',
      description: 'Use Kali GUI tools to identify and exploit web vulnerabilities in a simulated banking application.',
      difficulty: 'Medium',
      category: 'Web Security',
      xp: 275,
      estimatedTime: '50-65 minutes',
      completedBy: 7850,
      tags: ['burp suite', 'sql injection', 'web shells'],
      icon: Network
    },
    {
      id: 'forensics-investigation',
      name: 'Digital Crime Scene',
      description: 'Investigate a cyber crime using Kali forensics tools. Analyze disk images and recover deleted evidence.',
      difficulty: 'Hard',
      category: 'Digital Forensics',
      xp: 350,
      estimatedTime: '75-90 minutes',
      completedBy: 3420,
      tags: ['autopsy', 'disk analysis', 'evidence recovery'],
      icon: BookOpen
    }
  ];

  const categories = ['All', ...Array.from(new Set(rooms.map(room => room.category)))];
  const difficulties = ['All', 'Easy', 'Medium', 'Hard'];

  const filteredRooms = rooms.filter(room => {
    const matchesSearch = room.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         room.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         room.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesDifficulty = selectedDifficulty === 'All' || room.difficulty === selectedDifficulty;
    const matchesCategory = selectedCategory === 'All' || room.category === selectedCategory;
    
    return matchesSearch && matchesDifficulty && matchesCategory;
  });

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'text-green-400 bg-green-500/20';
      case 'Medium': return 'text-yellow-400 bg-yellow-500/20';
      case 'Hard': return 'text-red-400 bg-red-500/20';
      default: return 'text-gray-400 bg-gray-500/20';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">Cybersecurity Rooms</h1>
        <p className="text-gray-400">
          Hands-on labs to build your cybersecurity skills step by step
        </p>
      </div>

      {/* Search and Filters */}
      <div className="mb-8 flex flex-col lg:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search rooms, descriptions, or tags..."
            className="w-full pl-10 pr-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-transparent"
          />
        </div>
        
        <div className="flex gap-4">
          <select
            value={selectedDifficulty}
            onChange={(e) => setSelectedDifficulty(e.target.value)}
            className="px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-green-400"
          >
            {difficulties.map(difficulty => (
              <option key={difficulty} value={difficulty}>{difficulty}</option>
            ))}
          </select>
          
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-green-400"
          >
            {categories.map(category => (
              <option key={category} value={category}>{category}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Results Count */}
      <div className="mb-6">
        <p className="text-gray-400">
          Showing {filteredRooms.length} of {rooms.length} rooms
        </p>
      </div>

      {/* Rooms Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredRooms.map((room) => {
          const IconComponent = room.icon;
          return (
            <div key={room.id} className="bg-gray-800 rounded-xl border border-gray-700 hover:border-gray-600 transition-all group">
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="bg-green-500/20 p-2 rounded-lg">
                      <IconComponent className="h-6 w-6 text-green-400" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white group-hover:text-green-400 transition-colors">
                        {room.name}
                      </h3>
                      <p className="text-sm text-gray-400">{room.category}</p>
                    </div>
                  </div>
                  {room.isCompleted && (
                    <div className="bg-green-500/20 p-1 rounded-full">
                      <Award className="h-4 w-4 text-green-400" />
                    </div>
                  )}
                </div>

                <p className="text-gray-400 text-sm mb-4 line-clamp-3">
                  {room.description}
                </p>

                <div className="flex items-center justify-between mb-4">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${getDifficultyColor(room.difficulty)}`}>
                    {room.difficulty}
                  </span>
                  <span className="text-green-400 font-semibold">+{room.xp} XP</span>
                </div>

                <div className="flex items-center justify-between text-sm text-gray-400 mb-4">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    {room.estimatedTime}
                  </div>
                  <div className="flex items-center">
                    <Users className="h-4 w-4 mr-1" />
                    {room.completedBy.toLocaleString()}
                  </div>
                </div>

                <div className="flex flex-wrap gap-1 mb-4">
                  {room.tags.map((tag) => (
                    <span key={tag} className="px-2 py-1 bg-gray-700 text-gray-400 rounded text-xs">
                      {tag}
                    </span>
                  ))}
                </div>

                <Link
                  to={`/room/${room.id}`}
                  className={`block w-full text-center py-2 px-4 rounded-lg transition-all ${
                    room.category === 'Premium Challenge' && !room.isCompleted
                      ? 'bg-gray-600 text-gray-400 cursor-not-allowed'
                      : 'btn-green-glow'
                  }`}
                >
                  {room.category === 'Premium Challenge' && !room.isCompleted
                    ? '🔒 Complete other rooms to unlock'
                    : room.isCompleted 
                    ? 'Replay Mission' 
                    : 'Start Mission'}
                </Link>
              </div>
            </div>
          );
        })}
      </div>

      {filteredRooms.length === 0 && (
        <div className="text-center py-12">
          <BookOpen className="h-16 w-16 text-gray-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">No rooms found</h3>
          <p className="text-gray-400">Try adjusting your search or filter criteria</p>
        </div>
      )}
    </div>
  );
};

export default Rooms;