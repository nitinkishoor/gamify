import React, { useState } from 'react'
import { ArrowLeft, Play, RotateCcw, Flag, ExternalLink, Terminal, Search } from 'lucide-react'
import { Link } from 'react-router-dom'

const BankAttack: React.FC = () => {
  const [labUrl, setLabUrl] = useState<string>('')
  const [isStarting, setIsStarting] = useState(false)
  const [isResetting, setIsResetting] = useState(false)
  const [flag, setFlag] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showSuccessModal, setShowSuccessModal] = useState(false)
  const [submissionResult, setSubmissionResult] = useState<any>(null)

  const startMachine = async () => {
    setIsStarting(true)
    try {
      const response = await fetch('/api/labControl', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ room_id: 'bank_attack', action: 'start' })
      })
      
      const data = await response.json()
      if (data.success) {
        setLabUrl(data.labUrl)
      } else {
        alert('Failed to start lab: ' + data.message)
      }
    } catch (error) {
      console.error('Error starting lab:', error)
      alert('Failed to start lab')
    } finally {
      setIsStarting(false)
    }
  }

  const resetMachine = async () => {
    setIsResetting(true)
    try {
      const response = await fetch('/api/labControl', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'reset' })
      })
      
      const data = await response.json()
      if (data.success) {
        // Refresh the iframe if lab is running
        if (labUrl) {
          const iframe = document.getElementById('lab-iframe') as HTMLIFrameElement
          if (iframe) {
            iframe.src = iframe.src
          }
        }
      } else {
        alert('Failed to reset lab: ' + data.message)
      }
    } catch (error) {
      console.error('Error resetting lab:', error)
      alert('Failed to reset lab')
    } finally {
      setIsResetting(false)
    }
  }

  const submitFlag = async () => {
    if (!flag.trim()) {
      alert('Please enter a flag')
      return
    }

    setIsSubmitting(true)
    try {
      // In a real Vite app, we'd need to proxy API calls or use a different approach
      // For now, simulate the API call
      const mockResponse = {
        success: flag.trim() === 'GAMIFY{BANK_HACKED}',
        message: flag.trim() === 'GAMIFY{BANK_HACKED}' 
          ? '🎉 Correct flag! Mission accomplished!' 
          : '❌ Incorrect flag. Keep investigating and try again!',
        xp: flag.trim() === 'GAMIFY{BANK_HACKED}' ? 50 : 0,
        badge: flag.trim() === 'GAMIFY{BANK_HACKED}' ? 'Bank Raider' : null
      }
      
      /* Real API call would be:
      const response = await fetch('/api/submitFlag', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          profile_id: 'demo_profile', // In real app, get from auth context
          room_id: 'bank_attack',
          flag: flag.trim()
        })
      })
      
      const data = await response.json()
      */
      
      const data = mockResponse
      setSubmissionResult(data)
      
      if (data.success) {
        setShowSuccessModal(true)
        setFlag('')
      } else {
        alert(data.message)
      }
    } catch (error) {
      console.error('Error submitting flag:', error)
      alert('Failed to submit flag')
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <div className="bg-gray-800 border-b border-gray-700 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link to="/" className="text-gray-400 hover:text-white">
              <ArrowLeft className="h-6 w-6" />
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-white">Bank Attack CTF</h1>
              <p className="text-gray-400">Exploit the vulnerable banking application</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <button
              onClick={startMachine}
              disabled={isStarting}
              className="flex items-center space-x-2 bg-green-600 hover:bg-green-700 px-4 py-2 rounded-lg transition-colors disabled:opacity-50"
            >
              <Play className="h-4 w-4" />
              <span>{isStarting ? 'Starting...' : 'Start Machine'}</span>
            </button>
            
            <button
              onClick={resetMachine}
              disabled={isResetting}
              className="flex items-center space-x-2 bg-yellow-600 hover:bg-yellow-700 px-4 py-2 rounded-lg transition-colors disabled:opacity-50"
            >
              <RotateCcw className="h-4 w-4" />
              <span>{isResetting ? 'Resetting...' : 'Reset Machine'}</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-[calc(100vh-200px)]">
          {/* Instructions Panel */}
          <div className="bg-gray-800 rounded-xl p-6 border border-gray-700 overflow-y-auto">
            <h2 className="text-xl font-bold mb-4 flex items-center">
              <Terminal className="h-5 w-5 mr-2 text-green-400" />
              Mission Instructions
            </h2>
            
            <div className="space-y-4 text-gray-300">
              <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
                <h3 className="font-semibold text-blue-400 mb-2">🎯 Objective</h3>
                <p>Exploit the FakeBank application to gain unauthorized access and extract the hidden flag.</p>
              </div>

              <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-4">
                <h3 className="font-semibold text-yellow-400 mb-2">🔍 Reconnaissance</h3>
                <ol className="list-decimal list-inside space-y-1 text-sm">
                  <li>Start the machine and access the banking application</li>
                  <li>Try logging in with account number: <code className="bg-gray-700 px-2 py-1 rounded">8881</code></li>
                  <li>Explore the application and note any interesting features</li>
                </ol>
              </div>

              <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
                <h3 className="font-semibold text-red-400 mb-2">⚔️ Exploitation</h3>
                <ol className="list-decimal list-inside space-y-1 text-sm">
                  <li>Use directory enumeration tools like <code className="bg-gray-700 px-2 py-1 rounded">dirb</code></li>
                  <li>Look for hidden endpoints or admin pages</li>
                  <li>Find ways to manipulate account balances</li>
                  <li>Trigger the flag when balance reaches $2000+</li>
                </ol>
              </div>

              <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4">
                <h3 className="font-semibold text-green-400 mb-2">💡 Hints</h3>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Banking applications often have admin functions</li>
                  <li>Look for POST endpoints that modify data</li>
                  <li>The flag format is: <code className="bg-gray-700 px-2 py-1 rounded">GAMIFY{'{...}'}</code></li>
                </ul>
              </div>

              <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4">
                <h3 className="font-semibold text-purple-400 mb-2">🛠️ Tools</h3>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li><code className="bg-gray-700 px-2 py-1 rounded">dirb http://target/</code> - Directory enumeration</li>
                  <li><code className="bg-gray-700 px-2 py-1 rounded">curl -X POST</code> - Manual HTTP requests</li>
                  <li>Browser Developer Tools - Inspect network traffic</li>
                </ul>
              </div>
            </div>

            {/* Flag Submission */}
            <div className="mt-6 pt-6 border-t border-gray-700">
              <h3 className="text-lg font-semibold mb-4 flex items-center">
                <Flag className="h-5 w-5 mr-2 text-green-400" />
                Submit Flag
              </h3>
              
              <div className="flex space-x-3">
                <input
                  type="text"
                  value={flag}
                  onChange={(e) => setFlag(e.target.value)}
                  placeholder="Enter flag (e.g., GAMIFY{...})"
                  className="flex-1 bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-400"
                />
                <button
                  onClick={submitFlag}
                  disabled={isSubmitting}
                  className="bg-green-600 hover:bg-green-700 px-6 py-2 rounded-lg transition-colors disabled:opacity-50 flex items-center space-x-2"
                >
                  <Flag className="h-4 w-4" />
                  <span>{isSubmitting ? 'Submitting...' : 'Submit'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Lab Panel */}
          <div className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden">
            <div className="bg-gray-700 px-4 py-3 border-b border-gray-600">
              <h2 className="text-lg font-semibold flex items-center">
                <ExternalLink className="h-5 w-5 mr-2 text-blue-400" />
                Lab Environment
              </h2>
            </div>
            
            <div className="h-full">
              {labUrl ? (
                <iframe
                  id="lab-iframe"
                  src={labUrl}
                  className="w-full h-full border-0"
                  title="Bank Attack Lab"
                />
              ) : (
                <div className="flex items-center justify-center h-full text-gray-400">
                  <div className="text-center">
                    <Search className="h-16 w-16 mx-auto mb-4 opacity-50" />
                    <p className="text-lg mb-2">Lab Environment</p>
                    <p className="text-sm">Click "Start Machine" to begin the challenge</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Success Modal */}
      {showSuccessModal && submissionResult && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-xl p-6 max-w-md w-full border border-green-500/30">
            <div className="text-center">
              <div className="bg-green-500/20 rounded-full p-4 w-16 h-16 mx-auto mb-4">
                <Flag className="h-8 w-8 text-green-400 mx-auto" />
              </div>
              
              <h3 className="text-xl font-bold text-white mb-2">🎉 Mission Complete!</h3>
              <p className="text-gray-300 mb-4">{submissionResult.message}</p>
              
              <div className="bg-gray-700 rounded-lg p-4 mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-gray-400">XP Earned:</span>
                  <span className="text-green-400 font-bold">+{submissionResult.xp}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Badge Unlocked:</span>
                  <span className="text-yellow-400 font-bold">{submissionResult.badge}</span>
                </div>
              </div>
              
              <button
                onClick={() => setShowSuccessModal(false)}
                className="bg-green-600 hover:bg-green-700 px-6 py-2 rounded-lg transition-colors"
              >
                Continue
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default BankAttack