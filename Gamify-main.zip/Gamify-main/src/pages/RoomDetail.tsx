import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Play, Clock, Users, Award, Flag, CheckCircle, Target } from 'lucide-react';
import { getRoomData, completeTask } from '../api/rooms';
import { useGame } from '../contexts/GameContext';

interface RoomData {
  id: string;
  name: string;
  description: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  category: string;
  xp: number;
  estimatedTime: string;
  completedBy: number;
  tags: string[];
  isCompleted?: boolean;
  story: string;
  tasks: Array<{
    id: string;
    title: string;
    description: string;
    completed: boolean;
    xpReward: number;
  }>;
}

const RoomDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { completeTask: gameCompleteTask } = useGame();
  const [room, setRoom] = useState<RoomData | null>(null);
  const [loading, setLoading] = useState(true);
  const [flag, setFlag] = useState('');

  useEffect(() => {
    if (id) {
      loadRoomData(id);
    }
  }, [id]);

  const loadRoomData = async (roomId: string) => {
    try {
      const data = await getRoomData(roomId);
      setRoom(data);
    } catch (error) {
      console.error('Failed to load room data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCompleteTask = async (taskId: string, xpReward: number) => {
    if (!room) return;

    try {
      const result = await completeTask(room.id, taskId);
      if (result.success) {
        gameCompleteTask(room.id, taskId, xpReward);
        
        // Update local state
        setRoom(prev => prev ? {
          ...prev,
          tasks: prev.tasks.map(task => 
            task.id === taskId ? { ...task, completed: true } : task
          )
        } : null);
      }
    } catch (error) {
      console.error('Failed to complete task:', error);
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'text-green-400 bg-green-500/20';
      case 'Medium': return 'text-yellow-400 bg-yellow-500/20';
      case 'Hard': return 'text-red-400 bg-red-500/20';
      default: return 'text-gray-400 bg-gray-500/20';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-green-400"></div>
      </div>
    );
  }

  if (!room) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-4">Room Not Found</h1>
          <Link to="/rooms" className="text-green-400 hover:text-green-300">
            ← Back to Rooms
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <div className="bg-gray-800 border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link 
                to="/rooms" 
                className="text-gray-400 hover:text-white transition-colors"
              >
                <ArrowLeft className="h-6 w-6" />
              </Link>
              <div>
                <h1 className="text-3xl font-bold text-white">{room.name}</h1>
                <p className="text-gray-400 mt-1">{room.description}</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${getDifficultyColor(room.difficulty)}`}>
                {room.difficulty}
              </span>
              <span className="text-green-400 font-bold text-lg">+{room.xp} XP</span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Story */}
            <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
              <h2 className="text-xl font-bold text-white mb-4">Mission Briefing</h2>
              <div className="prose prose-invert max-w-none">
                <div className="text-gray-300 whitespace-pre-line">
                  {room.story}
                </div>
              </div>
            </div>

            {/* Tasks */}
            <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
              <h2 className="text-xl font-bold text-white mb-6 flex items-center">
                <Target className="h-5 w-5 text-blue-400 mr-2" />
                Mission Tasks
              </h2>
              
              <div className="space-y-4">
                {room.tasks.map((task, index) => (
                  <div 
                    key={task.id}
                    className={`p-4 rounded-lg border transition-all ${
                      task.completed 
                        ? 'bg-green-500/10 border-green-500/30' 
                        : 'bg-gray-700 border-gray-600 hover:border-gray-500'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          task.completed 
                            ? 'bg-green-500 text-white' 
                            : 'bg-gray-600 text-gray-300'
                        }`}>
                          {task.completed ? (
                            <CheckCircle className="h-4 w-4" />
                          ) : (
                            <span className="text-sm font-bold">{index + 1}</span>
                          )}
                        </div>
                        <div>
                          <h3 className="text-white font-semibold">{task.title}</h3>
                          <p className="text-gray-400 text-sm">{task.description}</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-3">
                        <span className="text-green-400 font-semibold">+{task.xpReward} XP</span>
                        {!task.completed && (
                          <button
                            onClick={() => handleCompleteTask(task.id, task.xpReward)}
                            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm transition-colors"
                          >
                            Complete
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Start Mission Button */}
            <div className="text-center">
              <Link
                to={`/rooms/${room.id}`}
                className="inline-flex items-center space-x-2 btn-green-glow px-8 py-4 rounded-lg text-lg font-semibold"
              >
                <Play className="h-5 w-5" />
                <span>Start Mission</span>
              </Link>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Room Stats */}
            <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
              <h3 className="text-lg font-semibold text-white mb-4">Room Stats</h3>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 text-blue-400 mr-2" />
                    <span className="text-gray-400">Estimated Time</span>
                  </div>
                  <span className="text-white font-medium">{room.estimatedTime}</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Users className="h-4 w-4 text-purple-400 mr-2" />
                    <span className="text-gray-400">Completed By</span>
                  </div>
                  <span className="text-white font-medium">{room.completedBy.toLocaleString()}</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Award className="h-4 w-4 text-yellow-400 mr-2" />
                    <span className="text-gray-400">XP Reward</span>
                  </div>
                  <span className="text-green-400 font-bold">+{room.xp}</span>
                </div>
              </div>
            </div>

            {/* Tags */}
            <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
              <h3 className="text-lg font-semibold text-white mb-4">Skills</h3>
              <div className="flex flex-wrap gap-2">
                {room.tags.map((tag) => (
                  <span 
                    key={tag}
                    className="px-3 py-1 bg-blue-500/20 text-blue-400 rounded-full text-sm"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Flag Submission */}
            <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
                <Flag className="h-5 w-5 text-green-400 mr-2" />
                Submit Flag
              </h3>
              
              <div className="space-y-3">
                <input
                  type="text"
                  value={flag}
                  onChange={(e) => setFlag(e.target.value)}
                  placeholder="Enter flag (e.g., GAMIFY{...})"
                  className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-400"
                />
                <button
                  className="w-full btn-green-glow py-2 px-4 rounded-lg font-medium"
                >
                  Submit Flag
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RoomDetail;