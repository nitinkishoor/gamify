import { NextApiRequest, NextApiResponse } from 'next'
import { supabaseAdmin } from '../../lib/supabase'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  try {
    const { profile_id, room_id, flag } = req.body

    if (!profile_id || !room_id || !flag) {
      return res.status(400).json({ 
        success: false, 
        message: 'Missing required fields: profile_id, room_id, flag' 
      })
    }

    // Get the correct flag for this room
    const { data: flagData, error: flagError } = await supabaseAdmin
      .from('flags')
      .select('flag_text')
      .eq('room_id', room_id)
      .single()

    if (flagError || !flagData) {
      console.error('Flag lookup error:', flagError)
      return res.status(500).json({ 
        success: false, 
        message: 'Room not found or flag not configured' 
      })
    }

    const correctFlag = flagData.flag_text.trim()
    const submittedFlag = flag.trim()

    if (submittedFlag !== correctFlag) {
      return res.status(200).json({ 
        success: false, 
        message: '❌ Incorrect flag. Keep investigating and try again!' 
      })
    }

    // Check if flag already submitted
    const { data: existingSubmission } = await supabaseAdmin
      .from('user_flags')
      .select('id')
      .eq('profile_id', profile_id)
      .eq('room_id', room_id)
      .single()

    if (existingSubmission) {
      return res.status(200).json({ 
        success: false, 
        message: 'Flag already submitted for this room' 
      })
    }

    // Record flag submission
    const { error: submissionError } = await supabaseAdmin
      .from('user_flags')
      .insert({
        profile_id,
        room_id,
        flag: submittedFlag,
        is_correct: true,
        submitted_at: new Date().toISOString()
      })

    if (submissionError) {
      console.error('Submission error:', submissionError)
      return res.status(500).json({ 
        success: false, 
        message: 'Failed to record submission' 
      })
    }

    // Award XP
    const xpAmount = room_id === 'bank_attack' ? 50 : 100
    const { error: xpError } = await supabaseAdmin
      .from('xp_history')
      .insert({
        profile_id,
        room_id,
        xp_amount: xpAmount,
        reason: `Completed room: ${room_id}`,
        created_at: new Date().toISOString()
      })

    if (xpError) {
      console.error('XP award error:', xpError)
    }

    // Update profile XP
    const { error: profileError } = await supabaseAdmin
      .rpc('add_xp_to_profile', {
        profile_id_param: profile_id,
        xp_to_add: xpAmount
      })

    if (profileError) {
      console.error('Profile XP update error:', profileError)
    }

    return res.status(200).json({
      success: true,
      message: '🎉 Correct flag! Mission accomplished!',
      xp: xpAmount,
      badge: room_id === 'bank_attack' ? 'Bank Raider' : 'CTF Solver'
    })

  } catch (error) {
    console.error('Submit flag error:', error)
    return res.status(500).json({ 
      success: false, 
      message: 'Internal server error' 
    })
  }
}