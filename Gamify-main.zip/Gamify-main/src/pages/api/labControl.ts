import { NextApiRequest, NextApiResponse } from 'next'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  try {
    const { room_id, action } = req.body

    if (!action) {
      return res.status(400).json({ error: 'Action is required' })
    }

    // For demo purposes, return fallback URL or simulate container management
    const fallbackUrl = process.env.LAB_FALLBACK_URL || 'http://localhost:3001'
    
    switch (action) {
      case 'start':
        if (!room_id) {
          return res.status(400).json({ error: 'room_id is required for start action' })
        }
        
        // In production, this would start a container
        // For now, return the fallback URL
        console.log(`Starting lab for room: ${room_id}`)
        
        return res.status(200).json({
          success: true,
          labUrl: fallbackUrl,
          message: `Lab started for ${room_id}`,
          containerId: `demo-${room_id}-${Date.now()}`
        })

      case 'reset':
        console.log('Resetting lab environment')
        return res.status(200).json({
          success: true,
          message: 'Lab environment reset successfully'
        })

      case 'stop':
        console.log('Stopping lab environment')
        return res.status(200).json({
          success: true,
          message: 'Lab environment stopped successfully'
        })

      default:
        return res.status(400).json({ error: 'Invalid action. Use: start, reset, or stop' })
    }

  } catch (error) {
    console.error('Lab control error:', error)
    return res.status(500).json({ error: 'Internal server error' })
  }
}