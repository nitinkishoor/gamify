import React, { useState } from 'react';
import { Trophy, Medal, Award, TrendingUp, Calendar } from 'lucide-react';

interface LeaderboardEntry {
  id: string;
  rank: number;
  name: string;
  avatar: string;
  xp: number;
  level: number;
  roomsCompleted: number;
  streak: number;
  country: string;
}

const Leaderboard: React.FC = () => {
  const [timeframe, setTimeframe] = useState<'all' | 'monthly' | 'weekly'>('all');

  const leaderboardData: LeaderboardEntry[] = [
    {
      id: '1',
      rank: 1,
      name: 'CyberNinja',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=user1',
      xp: 15420,
      level: 62,
      roomsCompleted: 187,
      streak: 45,
      country: '🇮🇳'
    },
    {
      id: '2',
      rank: 2,
      name: 'SecurityMaster',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=user2',
      xp: 14850,
      level: 60,
      roomsCompleted: 175,
      streak: 32,
      country: '🇮🇳'
    },
    {
      id: '3',
      rank: 3,
      name: 'HackWizard',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=user3',
      xp: 13200,
      level: 53,
      roomsCompleted: 156,
      streak: 28,
      country: '🇮🇳'
    },
    {
      id: '4',
      rank: 4,
      name: 'CryptoSleuth',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=user4',
      xp: 11780,
      level: 48,
      roomsCompleted: 142,
      streak: 21,
      country: '🇮🇳'
    },
    {
      id: '5',
      rank: 5,
      name: 'Cyber Warrior',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=google-user',
      xp: 10250,
      level: 41,
      roomsCompleted: 128,
      streak: 15,
      country: '🇮🇳'
    },
    {
      id: '6',
      rank: 6,
      name: 'PentestPro',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=user6',
      xp: 9850,
      level: 40,
      roomsCompleted: 118,
      streak: 19,
      country: '🇮🇳'
    },
    {
      id: '7',
      rank: 7,
      name: 'ForensicsExpert',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=user7',
      xp: 8900,
      level: 36,
      roomsCompleted: 102,
      streak: 12,
      country: '🇮🇳'
    },
    {
      id: '8',
      rank: 8,
      name: 'NetworkGuard',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=user8',
      xp: 7650,
      level: 31,
      roomsCompleted: 89,
      streak: 8,
      country: '🇮🇳'
    }
  ];

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="h-6 w-6 text-yellow-400" />;
      case 2:
        return <Medal className="h-6 w-6 text-gray-400" />;
      case 3:
        return <Award className="h-6 w-6 text-amber-600" />;
      default:
        return <span className="text-lg font-bold text-gray-400">#{rank}</span>;
    }
  };

  const getRankBackground = (rank: number) => {
    switch (rank) {
      case 1:
        return 'bg-gradient-to-r from-yellow-500/20 to-yellow-600/20 border-yellow-500/30';
      case 2:
        return 'bg-gradient-to-r from-gray-400/20 to-gray-500/20 border-gray-400/30';
      case 3:
        return 'bg-gradient-to-r from-amber-600/20 to-amber-700/20 border-amber-600/30';
      default:
        return 'bg-gray-800 border-gray-700 hover:border-gray-600';
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2 flex items-center">
          <Trophy className="h-8 w-8 text-yellow-400 mr-3" />
          Leaderboard
        </h1>
        <p className="text-gray-400">
          Compete with the best cybersecurity learners across India
        </p>
      </div>

      {/* Timeframe Selector */}
      <div className="flex justify-center mb-8">
        <div className="bg-gray-800 rounded-lg p-1 border border-gray-700">
          <button
            onClick={() => setTimeframe('all')}
            className={`px-6 py-2 rounded-md text-sm font-medium transition-colors ${
              timeframe === 'all'
                ? 'btn-green-glow text-white'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            All Time
          </button>
          <button
            onClick={() => setTimeframe('monthly')}
            className={`px-6 py-2 rounded-md text-sm font-medium transition-colors ${
              timeframe === 'monthly'
                ? 'btn-green-glow text-white'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            This Month
          </button>
          <button
            onClick={() => setTimeframe('weekly')}
            className={`px-6 py-2 rounded-md text-sm font-medium transition-colors ${
              timeframe === 'weekly'
                ? 'btn-green-glow text-white'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            This Week
          </button>
        </div>
      </div>

      {/* Top 3 Podium */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {leaderboardData.slice(0, 3).map((entry, index) => (
          <div
            key={entry.id}
            className={`${getRankBackground(entry.rank)} rounded-xl p-6 border transition-all ${
              index === 0 ? 'md:order-2 transform md:scale-105' : 
              index === 1 ? 'md:order-1' : 'md:order-3'
            }`}
          >
            <div className="text-center">
              <div className="flex justify-center mb-4">
                {getRankIcon(entry.rank)}
              </div>
              
              <img
                src={entry.avatar}
                alt={entry.name}
                className="w-16 h-16 rounded-full mx-auto mb-4 border-2 border-gray-600"
              />
              
              <h3 className="text-lg font-bold text-white mb-1">{entry.name}</h3>
              <p className="text-gray-400 text-sm mb-3">{entry.country}</p>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-gray-400 text-sm">XP</span>
                  <span className="text-green-400 font-bold">{entry.xp.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-400 text-sm">Level</span>
                  <span className="text-blue-400 font-bold">{entry.level}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-400 text-sm">Streak</span>
                  <span className="text-orange-400 font-bold">{entry.streak} days</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Full Leaderboard Table */}
      <div className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden">
        <div className="p-6 border-b border-gray-700">
          <h2 className="text-xl font-bold text-white flex items-center">
            <TrendingUp className="h-5 w-5 text-green-400 mr-2" />
            Full Rankings
          </h2>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Rank
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  User
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Level
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  XP
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Rooms
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Streak
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-700">
              {leaderboardData.map((entry) => (
                <tr key={entry.id} className={`hover:bg-gray-700 transition-colors ${
                  entry.name === 'Cyber Warrior' ? 'bg-green-500/10' : ''
                }`}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      {getRankIcon(entry.rank)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <img
                        src={entry.avatar}
                        alt={entry.name}
                        className="w-10 h-10 rounded-full mr-3"
                      />
                      <div>
                        <div className="text-white font-medium flex items-center">
                          {entry.name}
                          {entry.name === 'Cyber Warrior' && (
                            <span className="ml-2 px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded">
                              You
                            </span>
                          )}
                        </div>
                        <div className="text-gray-400 text-sm">{entry.country}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-blue-400 font-bold">{entry.level}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-green-400 font-bold">
                      {entry.xp.toLocaleString()}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-white">{entry.roomsCompleted}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 text-orange-400 mr-1" />
                      <span className="text-orange-400 font-medium">{entry.streak}</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        <div className="p-4 bg-gray-700 text-center">
          <p className="text-gray-400 text-sm">
            Want to climb the ranks? Complete more rooms and maintain your daily streak! 🚀
          </p>
        </div>
      </div>
    </div>
  );
};

export default Leaderboard;