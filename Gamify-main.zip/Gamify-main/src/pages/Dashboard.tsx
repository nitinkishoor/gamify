import React from 'react';
import { Link } from 'react-router-dom';
import { TrendingUp, Target, BookOpen, Users, Award, Zap, Calendar, ChevronRight, Map } from 'lucide-react';
import { useGame } from '../contexts/GameContext';
import LearningRoadmap from '../components/LearningRoadmap';

const Dashboard: React.FC = () => {
  const { stats } = useGame();
  const [activeTab, setActiveTab] = React.useState<'overview' | 'roadmap'>('overview');

  const learningPaths = [
    {
      id: 'beginner',
      name: 'Offensive Security Path',
      description: 'Learn ethical hacking and penetration testing',
      progress: 60,
      rooms: 4,
      xp: 750,
      color: 'bg-green-500',
      textColor: 'text-green-400'
    },
    {
      id: 'intermediate',
      name: 'Defensive Security Path',
      description: 'Master SOC analysis and incident response',
      progress: 40,
      rooms: 3,
      xp: 600,
      color: 'bg-blue-500',
      textColor: 'text-blue-400'
    },
    {
      id: 'advanced',
      name: 'Premium Challenges',
      description: 'Elite-level CTF challenges',
      progress: 20,
      rooms: 2,
      xp: 1000,
      color: 'bg-purple-500',
      textColor: 'text-purple-400'
    }
  ];

  const recentRooms = [
    { id: 'bank-attack', name: 'Bank Attack Mission', difficulty: 'Easy', xp: 250 },
    { id: 'soc-defense', name: 'SOC Analyst Defense', difficulty: 'Medium', xp: 300 },
    { id: 'network-recon', name: 'Network Reconnaissance', difficulty: 'Easy', xp: 200 }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">
              Welcome back, Cyber Warrior! 👋
            </h1>
            <p className="text-gray-400">
              Ready to level up your cybersecurity skills today?
            </p>
          </div>
          
          {/* Tab Navigation */}
          <div className="bg-gray-800 rounded-lg p-1 border border-gray-700">
            <button
              onClick={() => setActiveTab('overview')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                activeTab === 'overview'
                  ? 'btn-green-glow text-white'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Target className="h-4 w-4 inline mr-2" />
              Overview
            </button>
            <button
              onClick={() => setActiveTab('roadmap')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                activeTab === 'roadmap'
                  ? 'btn-green-glow text-white'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Map className="h-4 w-4 inline mr-2" />
              Learning Roadmap
            </button>
          </div>
        </div>
      </div>

      {/* Tab Content */}
      {activeTab === 'roadmap' ? (
        <LearningRoadmap />
      ) : (
        <>
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">Total XP</p>
              <p className="text-2xl font-bold text-green-400">{stats.xp}</p>
            </div>
            <div className="bg-green-500/20 p-3 rounded-lg">
              <TrendingUp className="h-6 w-6 text-green-400" />
            </div>
          </div>
        </div>

        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">Level</p>
              <p className="text-2xl font-bold text-blue-400">{stats.level}</p>
            </div>
            <div className="bg-blue-500/20 p-3 rounded-lg">
              <Target className="h-6 w-6 text-blue-400" />
            </div>
          </div>
        </div>

        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">Daily Streak</p>
              <p className="text-2xl font-bold text-orange-400">{stats.streak}</p>
            </div>
            <div className="bg-orange-500/20 p-3 rounded-lg">
              <Zap className="h-6 w-6 text-orange-400" />
            </div>
          </div>
        </div>

        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">Rooms Completed</p>
              <p className="text-2xl font-bold text-purple-400">{stats.roomsCompleted}</p>
            </div>
            <div className="bg-purple-500/20 p-3 rounded-lg">
              <BookOpen className="h-6 w-6 text-purple-400" />
            </div>
          </div>
        </div>
      </div>

      {/* XP Progress Bar */}
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700 mb-8">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-white">Level Progress</h3>
          <span className="text-sm text-gray-400">
            {stats.xp % 250} / 250 XP to next level
          </span>
        </div>
        <div className="w-full bg-gray-700 rounded-full h-3">
          <div 
            className="bg-gradient-to-r from-green-400 to-blue-500 h-3 rounded-full transition-all duration-300"
            style={{ width: `${(stats.xp % 250) / 250 * 100}%` }}
          ></div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Learning Paths */}
        <div className="lg:col-span-2">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-white">Learning Paths</h2>
            <Link 
              to="/rooms" 
              className="text-green-400 hover:text-green-300 text-sm flex items-center"
            >
              View all rooms <ChevronRight className="h-4 w-4 ml-1" />
            </Link>
          </div>
          
          <div className="space-y-4">
            {learningPaths.map((path) => (
              <div key={path.id} className="bg-gray-800 rounded-xl p-6 border border-gray-700 hover:border-gray-600 transition-all">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-white">{path.name}</h3>
                    <p className="text-gray-400 text-sm">{path.description}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-400">{path.rooms} rooms</p>
                    <p className={`text-sm font-semibold ${path.textColor}`}>+{path.xp} XP</p>
                  </div>
                </div>
                
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm text-gray-400">Progress</span>
                  <span className="text-sm font-semibold text-white">{path.progress}%</span>
                </div>
                
                <div className="w-full bg-gray-700 rounded-full h-2 mb-4">
                  <div 
                    className={`${path.color} h-2 rounded-full transition-all duration-300`}
                    style={{ width: `${path.progress}%` }}
                  ></div>
                </div>
                
                <Link 
                  to="/rooms"
                  className="inline-flex items-center text-sm text-green-400 hover:text-green-300 font-medium transition-all duration-300 hover:drop-shadow-[0_0_8px_rgba(34,197,94,0.6)]"
                >
                  Continue Learning <ChevronRight className="h-4 w-4 ml-1" />
                </Link>
              </div>
            ))}
            
            {/* Bank Attack CTF Card */}
            <div className="bg-gradient-to-r from-red-500/20 to-orange-500/20 rounded-xl p-6 border border-red-500/30 hover:border-red-500/50 transition-all">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-white">🏦 Bank Attack CTF</h3>
                  <p className="text-gray-400 text-sm">Exploit a vulnerable banking application</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-400">1 room</p>
                  <p className="text-sm font-semibold text-red-400">+250 XP</p>
                </div>
              </div>
              
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm text-gray-400">Difficulty</span>
                <span className="px-2 py-1 bg-green-500/20 text-green-400 rounded text-xs font-medium">Easy</span>
              </div>
              
              <Link 
                to="/rooms/bank-attack"
                className="inline-flex items-center text-sm text-red-400 hover:text-red-300 font-medium transition-all duration-300 hover:drop-shadow-[0_0_8px_rgba(239,68,68,0.6)]"
              >
                Start Challenge <ChevronRight className="h-4 w-4 ml-1" />
              </Link>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Recent Badges */}
          <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
              <Award className="h-5 w-5 text-yellow-400 mr-2" />
              Recent Badges
            </h3>
            <div className="space-y-3">
              {stats.badges.slice(0, 3).map((badge) => (
                <div key={badge.id} className="flex items-center space-x-3">
                  <span className="text-2xl">{badge.icon}</span>
                  <div>
                    <p className="text-white text-sm font-medium">{badge.name}</p>
                    <p className="text-gray-400 text-xs">{badge.description}</p>
                  </div>
                </div>
              ))}
            </div>
            <Link 
              to="/profile" 
              className="block mt-4 text-center text-green-400 hover:text-green-300 text-sm"
            >
              View all badges
            </Link>
          </div>

          {/* Quick Start Rooms */}
          <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
              <BookOpen className="h-5 w-5 text-blue-400 mr-2" />
              Quick Start
            </h3>
            <div className="space-y-3">
              {recentRooms.map((room) => (
                <div key={room.id} className="group">
                  <Link 
                    to={`/room/${room.id}`}
                    className="block p-3 rounded-lg bg-gray-700 hover:bg-gray-600 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-white text-sm font-medium group-hover:text-green-400 transition-colors">
                          {room.name}
                        </p>
                        <p className="text-gray-400 text-xs">{room.difficulty}</p>
                      </div>
                      <span className="text-green-400 text-sm font-semibold">
                        +{room.xp} XP
                      </span>
                    </div>
                  </Link>
                </div>
              ))}
            </div>
          </div>

          {/* Daily Challenge */}
          <div className="bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded-xl p-6 border border-green-500/30">
            <div className="flex items-center mb-3">
              <Calendar className="h-5 w-5 text-green-400 mr-2" />
              <h3 className="text-lg font-semibold text-white">Daily Challenge</h3>
            </div>
            <p className="text-gray-300 text-sm mb-4">
              Complete today's challenge to maintain your streak and earn bonus XP!
            </p>
            <button className="w-full bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-lg text-sm font-medium transition-colors">
              Start Challenge (+50 XP)
            </button>
          </div>
        </div>
      </div>
        </>
      )}
    </div>
  );
};

export default Dashboard;