import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Trophy, 
  Lock, 
  Play, 
  CheckCircle, 
  Clock, 
  Star,
  Zap,
  Target,
  ChevronRight,
  Award
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useGame } from '../contexts/GameContext';
import { 
  getCareerTracks, 
  getPathNodes, 
  startPath,
  getLearningPaths 
} from '../api/learningPaths';
import { CareerTrack, PathNode, LearningPath } from '../types/learningPaths';

const LearningRoadmap: React.FC = () => {
  const { user } = useAuth();
  const { stats } = useGame();
  const [careerTracks, setCareerTracks] = useState<CareerTrack[]>([]);
  const [selectedTrack, setSelectedTrack] = useState<string>('foundations');
  const [pathNodes, setPathNodes] = useState<PathNode[]>([]);
  const [selectedPath, setSelectedPath] = useState<LearningPath | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, [user, stats.xp]);

  const loadData = async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      const [tracks, nodes] = await Promise.all([
        getCareerTracks(),
        getPathNodes(user.id, stats.xp)
      ]);
      
      setCareerTracks(tracks);
      setPathNodes(nodes);
    } catch (error) {
      console.error('Failed to load learning roadmap:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleStartPath = async (pathId: string) => {
    if (!user) return;
    
    try {
      await startPath(user.id, pathId);
      await loadData(); // Refresh data
    } catch (error) {
      console.error('Failed to start path:', error);
    }
  };

  const getTrackProgress = (track: CareerTrack) => {
    const trackPaths = pathNodes.filter(node => 
      track.paths.includes(node.path.id)
    );
    
    if (trackPaths.length === 0) return 0;
    
    const totalProgress = trackPaths.reduce((sum, node) => 
      sum + node.path.progressPercent, 0
    );
    
    return Math.round(totalProgress / trackPaths.length);
  };

  const getTrackCompletedPaths = (track: CareerTrack) => {
    return pathNodes.filter(node => 
      track.paths.includes(node.path.id) && node.path.isCompleted
    ).length;
  };

  const selectedTrackData = careerTracks.find(t => t.id === selectedTrack);
  const selectedTrackPaths = pathNodes.filter(node => 
    selectedTrackData?.paths.includes(node.path.id)
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-400"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-white mb-2">Learning Roadmap</h1>
        <p className="text-gray-400">
          Choose your cybersecurity career path and progress through structured learning
        </p>
      </div>

      {/* Career Track Selection */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {careerTracks.map((track) => {
          const progress = getTrackProgress(track);
          const completedPaths = getTrackCompletedPaths(track);
          const isSelected = selectedTrack === track.id;
          
          return (
            <button
              key={track.id}
              onClick={() => setSelectedTrack(track.id)}
              className={`p-6 rounded-xl border transition-all text-left ${
                isSelected
                  ? 'border-green-400 bg-green-500/10'
                  : 'border-gray-700 bg-gray-800 hover:border-gray-600'
              }`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg ${track.color}/20`}>
                  <span className="text-2xl">{track.icon}</span>
                </div>
                {progress === 100 && (
                  <Trophy className="h-6 w-6 text-yellow-400" />
                )}
              </div>
              
              <h3 className="text-lg font-semibold text-white mb-2">
                {track.name}
              </h3>
              <p className="text-gray-400 text-sm mb-4">
                {track.description}
              </p>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-400">Progress</span>
                  <span className="text-white font-medium">{progress}%</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full transition-all duration-300 ${track.color}`}
                    style={{ width: `${progress}%` }}
                  ></div>
                </div>
                <div className="flex items-center justify-between text-xs text-gray-400">
                  <span>{completedPaths}/{track.paths.length} paths</span>
                  <span>+{track.totalXP} XP</span>
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected Track Details */}
      {selectedTrackData && (
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <div className={`p-4 rounded-xl ${selectedTrackData.color}/20`}>
                <span className="text-3xl">{selectedTrackData.icon}</span>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white">
                  {selectedTrackData.name}
                </h2>
                <p className="text-gray-400">{selectedTrackData.description}</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-green-400">
                {getTrackProgress(selectedTrackData)}%
              </div>
              <div className="text-sm text-gray-400">Complete</div>
            </div>
          </div>

          {/* Learning Path Flowchart */}
          <div className="relative">
            <h3 className="text-lg font-semibold text-white mb-6 flex items-center">
              <Target className="h-5 w-5 text-blue-400 mr-2" />
              Learning Path
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {selectedTrackPaths.map((node, index) => {
                const { path, isUnlocked, isActive } = node;
                
                return (
                  <div key={path.id} className="relative">
                    {/* Connection Line */}
                    {index < selectedTrackPaths.length - 1 && (
                      <div className="hidden lg:block absolute top-1/2 -right-3 w-6 h-0.5 bg-gray-600 z-0"></div>
                    )}
                    
                    {/* Path Node */}
                    <div
                      className={`relative z-10 p-6 rounded-xl border transition-all cursor-pointer ${
                        path.isCompleted
                          ? 'border-green-400 bg-green-500/10'
                          : isActive
                          ? 'border-blue-400 bg-blue-500/10'
                          : isUnlocked
                          ? 'border-gray-600 bg-gray-800 hover:border-gray-500'
                          : 'border-gray-700 bg-gray-900 opacity-60'
                      }`}
                      onClick={() => isUnlocked ? setSelectedPath(path) : null}
                    >
                      <div className="flex items-center justify-between mb-4">
                        <div className={`p-2 rounded-lg ${path.color}/20`}>
                          <span className="text-xl">{path.icon}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          {path.isCompleted ? (
                            <CheckCircle className="h-5 w-5 text-green-400" />
                          ) : isActive ? (
                            <Play className="h-5 w-5 text-blue-400" />
                          ) : !isUnlocked ? (
                            <Lock className="h-5 w-5 text-gray-500" />
                          ) : null}
                        </div>
                      </div>
                      
                      <h4 className="text-lg font-semibold text-white mb-2">
                        {path.title}
                      </h4>
                      <p className="text-gray-400 text-sm mb-4 line-clamp-2">
                        {path.description}
                      </p>
                      
                      <div className="space-y-3">
                        <div className="flex items-center justify-between text-sm">
                          <span className={`px-2 py-1 rounded text-xs font-medium ${
                            path.difficulty === 'Easy' ? 'bg-green-500/20 text-green-400' :
                            path.difficulty === 'Medium' ? 'bg-yellow-500/20 text-yellow-400' :
                            'bg-red-500/20 text-red-400'
                          }`}>
                            {path.difficulty}
                          </span>
                          <span className="text-green-400 font-semibold">
                            +{path.xpReward} XP
                          </span>
                        </div>
                        
                        <div className="flex items-center justify-between text-xs text-gray-400">
                          <div className="flex items-center">
                            <Clock className="h-3 w-3 mr-1" />
                            {path.estimatedHours}h
                          </div>
                          <div className="flex items-center">
                            <Star className="h-3 w-3 mr-1" />
                            {path.rooms.length} rooms
                          </div>
                        </div>
                        
                        {(isActive || path.isCompleted) && (
                          <div className="space-y-1">
                            <div className="flex items-center justify-between text-xs">
                              <span className="text-gray-400">Progress</span>
                              <span className="text-white">{path.progressPercent}%</span>
                            </div>
                            <div className="w-full bg-gray-700 rounded-full h-1.5">
                              <div 
                                className="bg-gradient-to-r from-green-400 to-blue-500 h-1.5 rounded-full transition-all duration-300"
                                style={{ width: `${path.progressPercent}%` }}
                              ></div>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Path Detail Modal */}
      {selectedPath && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-xl p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto border border-gray-700">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-4">
                <div className={`p-3 rounded-lg ${selectedPath.color}/20`}>
                  <span className="text-2xl">{selectedPath.icon}</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">
                    {selectedPath.title}
                  </h3>
                  <p className="text-gray-400">{selectedPath.description}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedPath(null)}
                className="text-gray-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-gray-700 p-4 rounded-lg">
                <div className="text-green-400 font-bold text-lg">
                  +{selectedPath.xpReward} XP
                </div>
                <div className="text-gray-400 text-sm">XP Reward</div>
              </div>
              <div className="bg-gray-700 p-4 rounded-lg">
                <div className="text-blue-400 font-bold text-lg">
                  {selectedPath.estimatedHours}h
                </div>
                <div className="text-gray-400 text-sm">Estimated Time</div>
              </div>
            </div>

            <div className="space-y-4 mb-6">
              <div>
                <h4 className="text-white font-semibold mb-2">Included Rooms:</h4>
                <div className="space-y-2">
                  {selectedPath.rooms.map((roomId) => (
                    <Link
                      key={roomId}
                      to={`/room/${roomId}`}
                      className="flex items-center justify-between p-3 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors"
                    >
                      <span className="text-white">{roomId.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}</span>
                      <ChevronRight className="h-4 w-4 text-gray-400" />
                    </Link>
                  ))}
                </div>
              </div>

              {selectedPath.prerequisites.length > 0 && (
                <div>
                  <h4 className="text-white font-semibold mb-2">Prerequisites:</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedPath.prerequisites.map((prereq) => (
                      <span
                        key={prereq}
                        className="px-3 py-1 bg-yellow-500/20 text-yellow-400 rounded-full text-sm"
                      >
                        {prereq.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="flex space-x-4">
              {selectedPath.isCompleted ? (
                <div className="flex-1 bg-green-500/20 text-green-400 py-3 px-6 rounded-lg text-center font-medium">
                  ✓ Completed
                </div>
              ) : selectedPath.progressPercent > 0 ? (
                <Link
                  to={`/room/${selectedPath.rooms[0]}`}
                  className="flex-1 btn-green-glow py-3 px-6 rounded-lg text-center font-medium"
                >
                  Continue Learning
                </Link>
              ) : stats.xp >= selectedPath.xpRequired ? (
                <button
                  onClick={() => {
                    handleStartPath(selectedPath.id);
                    setSelectedPath(null);
                  }}
                  className="flex-1 btn-green-glow py-3 px-6 rounded-lg font-medium"
                >
                  Start Path
                </button>
              ) : (
                <div className="flex-1 bg-gray-600 text-gray-400 py-3 px-6 rounded-lg text-center font-medium cursor-not-allowed">
                  Requires {selectedPath.xpRequired} XP
                </div>
              )}
              
              <button
                onClick={() => setSelectedPath(null)}
                className="px-6 py-3 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LearningRoadmap;