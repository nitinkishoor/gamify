import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { updateLeaderboardRealTime } from '../api/leaderboard';
import { submitFlag } from '../api/flags';
import { updatePathProgress, completePath } from '../api/learningPaths';
import { useAuth } from './AuthContext';

interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlockedAt?: string;
}

interface GameStats {
  xp: number;
  level: number;
  streak: number;
  roomsCompleted: number;
  badges: Badge[];
  currentPath: 'beginner' | 'intermediate' | 'advanced';
  unlockedRooms: string[];
}

interface GameContextType {
  stats: GameStats;
  addXP: (amount: number) => void;
  completeRoom: (roomId: string) => void;
  updateStreak: () => void;
  submitRoomFlag: (roomId: string, flag: string) => Promise<{
    success: boolean;
    message: string;
    xpAwarded?: number;
    badgeUnlocked?: Badge;
  }>;
  completeTask: (roomId: string, taskId: string, xpReward: number) => void;
  updateLearningPathProgress: (pathId: string, progressPercent: number, roomCompleted?: string) => Promise<void>;
}

const GameContext = createContext<GameContextType | undefined>(undefined);

export const useGame = () => {
  const context = useContext(GameContext);
  if (context === undefined) {
    throw new Error('useGame must be used within a GameProvider');
  }
  return context;
};

interface GameProviderProps {
  children: ReactNode;
}

export const GameProvider: React.FC<GameProviderProps> = ({ children }) => {
  const { user } = useAuth();
  const [stats, setStats] = useState<GameStats>({
    xp: 850,
    level: 4,
    streak: 7,
    roomsCompleted: 3,
    badges: [
      {
        id: '1',
        name: 'First Hack',
        description: 'Completed your first CTF room',
        icon: '🎯',
        unlockedAt: '2024-01-15'
      },
      {
        id: '2',
        name: 'Network Scout',
        description: 'Mastered network reconnaissance',
        icon: '🔍',
        unlockedAt: '2024-01-18'
      },
      {
        id: '3',
        name: 'Streak Master',
        description: '7-day learning streak',
        icon: '🔥',
        unlockedAt: '2024-01-20'
      },
      {
        id: '4',
        name: 'Bank Infiltrator',
        description: 'Successfully infiltrated SecureBank through web exploitation',
        icon: '🏦',
        unlockedAt: null
      },
      {
        id: '5',
        name: 'SOC Defender',
        description: 'Successfully detected and neutralized cyber threats',
        icon: '🛡️',
        unlockedAt: null
      },
      {
        id: '6',
        name: 'Desktop Master',
        description: 'Mastered GUI-based cybersecurity tools',
        icon: '🖥️',
        unlockedAt: null
      },
      {
        id: '7',
        name: 'Mission Commander',
        description: 'Completed multiple cybersecurity missions',
        icon: '⭐',
        unlockedAt: null
      }
    ],
    currentPath: 'intermediate',
    unlockedRooms: ['bank-attack', 'soc-defense', 'network-recon']
  });

  useEffect(() => {
    // Load game stats from localStorage
    const savedStats = localStorage.getItem('gamify_stats');
    if (savedStats) {
      setStats(JSON.parse(savedStats));
    }
  }, []);

  useEffect(() => {
    // Save stats to localStorage whenever they change
    localStorage.setItem('gamify_stats', JSON.stringify(stats));
  }, [stats]);

  const addXP = (amount: number) => {
    setStats(prev => {
      const newXP = prev.xp + amount;
      const newLevel = Math.floor(newXP / 250) + 1;
      
      // Update leaderboard in background
      updateLeaderboardRealTime('5', amount).catch(console.error);
      
      return {
        ...prev,
        xp: newXP,
        level: newLevel
      };
    });
  };

  const completeRoom = (roomId: string) => {
    setStats(prev => ({
      ...prev,
      roomsCompleted: prev.roomsCompleted + 1,
      unlockedRooms: roomId === 'bank-attack' && prev.roomsCompleted >= 1 ? 
        [...prev.unlockedRooms, 'premium-vault'] : prev.unlockedRooms
    }));
    
    // Update learning path progress based on room completion
    updateLearningPathProgressForRoom(roomId);
    
    // Award specific badges based on room completion
    if (roomId === 'bank-attack') {
      setStats(prev => ({
        ...prev,
        badges: prev.badges.map(badge => 
          badge.id === '4' ? { ...badge, unlockedAt: new Date().toISOString().split('T')[0] } : badge
        )
      }));
    } else if (roomId === 'soc-defense') {
      setStats(prev => ({
        ...prev,
        badges: prev.badges.map(badge => 
          badge.id === '5' ? { ...badge, unlockedAt: new Date().toISOString().split('T')[0] } : badge
        )
      }));
    }
  };

  const updateStreak = () => {
    setStats(prev => ({
      ...prev,
      streak: prev.streak + 1
    }));
  };

  const submitRoomFlag = async (roomId: string, flag: string) => {
    try {
      const result = await submitFlag(roomId, flag);
      
      if (result.isCorrect && result.xpAwarded) {
        // Add XP and complete room
        addXP(result.xpAwarded);
        completeRoom(roomId);
        
        // Unlock badge if provided
        if (result.badgeUnlocked) {
          setStats(prev => ({
            ...prev,
            badges: prev.badges.map(badge => 
              badge.id === result.badgeUnlocked?.id ? 
                { ...badge, unlockedAt: new Date().toISOString().split('T')[0] } : 
                badge
            )
          }));
        }
        
        return {
          success: true,
          message: result.message,
          xpAwarded: result.xpAwarded,
          badgeUnlocked: result.badgeUnlocked
        };
      }
      
      return {
        success: false,
        message: result.message
      };
    } catch (error) {
      return {
        success: false,
        message: 'Flag submission failed. Please try again.'
      };
    }
  };

  const completeTask = (roomId: string, taskId: string, xpReward: number) => {
    // Award XP for task completion
    addXP(xpReward);
    
    // Update task completion status in localStorage
    const taskKey = `task_${roomId}_${taskId}`;
    localStorage.setItem(taskKey, 'completed');
  };

  const updateLearningPathProgress = async (pathId: string, progressPercent: number, roomCompleted?: string) => {
    if (!user) return;
    
    try {
      await updatePathProgress(user.id, pathId, progressPercent, roomCompleted);
      
      // Check if path is completed
      if (progressPercent >= 100) {
        const result = await completePath(user.id, pathId);
        if (result.success) {
          addXP(result.xpAwarded);
          
          if (result.badgeUnlocked) {
            setStats(prev => ({
              ...prev,
              badges: [...prev.badges, {
                id: result.badgeUnlocked.id,
                name: result.badgeUnlocked.name,
                description: result.badgeUnlocked.description,
                icon: result.badgeUnlocked.icon,
                unlockedAt: new Date().toISOString().split('T')[0]
              }]
            }));
          }
        }
      }
    } catch (error) {
      console.error('Failed to update learning path progress:', error);
    }
  };

  const updateLearningPathProgressForRoom = async (roomId: string) => {
    if (!user) return;
    
    // Map rooms to learning paths and update progress
    const roomToPathMapping: Record<string, { pathId: string, progressIncrease: number }> = {
      'bank-attack': { pathId: 'jr-pentester', progressIncrease: 50 },
      'soc-defense': { pathId: 'soc-level-1', progressIncrease: 50 },
      'network-recon': { pathId: 'network-basics', progressIncrease: 40 },
      'web-exploit': { pathId: 'web-app-security', progressIncrease: 50 },
      'forensics-investigation': { pathId: 'incident-response', progressIncrease: 50 },
      'premium-vault': { pathId: 'advanced-exploitation', progressIncrease: 60 }
    };
    
    const mapping = roomToPathMapping[roomId];
    if (mapping) {
      await updateLearningPathProgress(mapping.pathId, mapping.progressIncrease, roomId);
    }
  };

  const value: GameContextType = {
    stats,
    addXP,
    completeRoom,
    updateStreak,
    submitRoomFlag,
    completeTask,
    updateLearningPathProgress
  };

  return <GameContext.Provider value={value}>{children}</GameContext.Provider>;
};