// Backend API for room data and operations
export interface RoomData {
  id: string;
  name: string;
  description: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  category: string;
  xp: number;
  estimatedTime: string;
  completedBy: number;
  tags: string[];
  isCompleted?: boolean;
  story: string;
  tasks: Array<{
    id: string;
    title: string;
    description: string;
    completed: boolean;
    xpReward: number;
  }>;
}

// Mock database for rooms
const roomsDatabase: Record<string, RoomData> = {
  'bank-attack': {
    id: 'bank-attack',
    name: 'Bank Attack Mission',
    description: 'Infiltrate SecureBank Corp through web exploitation. Find hidden admin pages and execute unauthorized transfers.',
    difficulty: 'Easy',
    category: 'Offensive Security',
    xp: 250,
    estimatedTime: '30-45 minutes',
    completedBy: 8420,
    tags: ['web exploitation', 'admin bypass', 'unauthorized access'],
    isCompleted: false,
    story: `🏦 **MISSION BRIEFING: OPERATION BANK INFILTRATION**

**Agent Codename**: Cyber
**Target**: SecureBank Corp
**Objective**: Penetration test to identify security vulnerabilities

**Intelligence Report**:
SecureBank Corp has hired you to conduct a penetration test on their systems. Your mission is to infiltrate their network, navigate through their file system, and locate the hidden vault passkey that contains sensitive financial data.

**Mission Parameters**:
- Access Level: Authorized Penetration Test
- Time Limit: 45 minutes
- Stealth Level: High (avoid detection)
- Success Criteria: Retrieve vault passkey

**Warning**: This is a controlled environment. All activities are monitored and authorized.

**Your Mission**: Use Kali Linux tools to explore the bank's file system, find hidden directories, and extract the secret passkey from the vault files.

Good luck, Agent. The bank's security depends on finding these vulnerabilities before real attackers do.`,
    tasks: [
      {
        id: 'launch-desktop',
        title: 'Launch Kali Desktop',
        description: 'Initialize your penetration testing workstation',
        completed: false,
        xpReward: 50
      },
      {
        id: 'navigate-directories',
        title: 'Navigate File System',
        description: 'Explore the bank\'s directory structure',
        completed: false,
        xpReward: 50
      },
      {
        id: 'find-hidden-files',
        title: 'Discover Hidden Files',
        description: 'Locate concealed vault directories',
        completed: false,
        xpReward: 75
      },
      {
        id: 'extract-passkey',
        title: 'Extract Vault Passkey',
        description: 'Retrieve the secret passkey from vault files',
        completed: false,
        xpReward: 75
      }
    ]
  },
  'network-recon': {
    id: 'network-recon',
    name: 'Network Reconnaissance',
    description: 'Master network scanning and enumeration using Kali GUI tools to map target infrastructure.',
    difficulty: 'Easy',
    category: 'Reconnaissance',
    xp: 200,
    estimatedTime: '30-45 minutes',
    completedBy: 12340,
    tags: ['nmap', 'network scanning', 'enumeration'],
    isCompleted: true,
    story: `🔍 **RECONNAISSANCE MISSION: NETWORK MAPPING**

**Objective**: Map and enumerate target network infrastructure
**Tools**: Kali Linux reconnaissance suite
**Mission**: Discover live hosts, open ports, and running services`,
    tasks: [
      {
        id: 'network-scan',
        title: 'Network Discovery',
        description: 'Scan for live hosts on the network',
        completed: true,
        xpReward: 50
      },
      {
        id: 'port-scan',
        title: 'Port Enumeration',
        description: 'Identify open ports and services',
        completed: true,
        xpReward: 75
      },
      {
        id: 'service-detection',
        title: 'Service Detection',
        description: 'Determine running services and versions',
        completed: true,
        xpReward: 75
      }
    ]
  },
  'web-exploit': {
    id: 'web-exploit',
    name: 'Web Application Exploit',
    description: 'Use Kali GUI tools to identify and exploit web vulnerabilities in a simulated banking application.',
    difficulty: 'Medium',
    category: 'Web Security',
    xp: 275,
    estimatedTime: '50-65 minutes',
    completedBy: 7850,
    tags: ['burp suite', 'sql injection', 'web shells'],
    isCompleted: false,
    story: `🌐 **WEB APPLICATION PENETRATION TEST**

**Target**: Banking Web Application
**Objective**: Identify and exploit web vulnerabilities
**Tools**: Burp Suite, OWASP ZAP, Custom payloads`,
    tasks: [
      {
        id: 'web-recon',
        title: 'Web Reconnaissance',
        description: 'Map the web application structure',
        completed: false,
        xpReward: 60
      },
      {
        id: 'vulnerability-scan',
        title: 'Vulnerability Assessment',
        description: 'Identify potential security flaws',
        completed: false,
        xpReward: 70
      },
      {
        id: 'exploit-execution',
        title: 'Exploit Execution',
        description: 'Execute successful attack vectors',
        completed: false,
        xpReward: 85
      },
      {
        id: 'privilege-escalation',
        title: 'Privilege Escalation',
        description: 'Gain administrative access',
        completed: false,
        xpReward: 60
      }
    ]
  },
  'forensics-investigation': {
    id: 'forensics-investigation',
    name: 'Digital Crime Scene',
    description: 'Investigate a cyber crime using Kali forensics tools. Analyze disk images and recover deleted evidence.',
    difficulty: 'Hard',
    category: 'Digital Forensics',
    xp: 350,
    estimatedTime: '75-90 minutes',
    completedBy: 3420,
    tags: ['autopsy', 'disk analysis', 'evidence recovery'],
    isCompleted: false,
    story: `🔬 **DIGITAL FORENSICS INVESTIGATION**

**Case**: Corporate Data Breach Investigation
**Objective**: Recover deleted evidence and identify the perpetrator
**Tools**: Autopsy, Volatility, Forensic imaging tools`,
    tasks: [
      {
        id: 'image-acquisition',
        title: 'Disk Image Acquisition',
        description: 'Create forensic copies of evidence',
        completed: false,
        xpReward: 70
      },
      {
        id: 'file-recovery',
        title: 'Deleted File Recovery',
        description: 'Recover deleted files and artifacts',
        completed: false,
        xpReward: 80
      },
      {
        id: 'timeline-analysis',
        title: 'Timeline Analysis',
        description: 'Reconstruct the sequence of events',
        completed: false,
        xpReward: 90
      },
      {
        id: 'evidence-correlation',
        title: 'Evidence Correlation',
        description: 'Link evidence to identify the attacker',
        completed: false,
        xpReward: 110
      }
    ]
  },
  'soc-defense': {
    id: 'soc-defense',
    name: 'SOC Analyst Defense',
    description: 'Detect and respond to live cyber attacks using SOC monitoring tools. Analyze logs and secure compromised systems.',
    difficulty: 'Medium',
    category: 'Defensive Security',
    xp: 300,
    estimatedTime: '45-60 minutes',
    completedBy: 5240,
    tags: ['log analysis', 'network monitoring', 'incident response', 'SOC'],
    isCompleted: false,
    story: `🛡️ **INCIDENT RESPONSE: ACTIVE CYBER ATTACK DETECTED**

**SOC Analyst**: Senior Defender
**Alert Level**: CRITICAL
**Incident ID**: INC-2024-0892

**SITUATION REPORT**:
Our Security Operations Center has detected suspicious activity across multiple network segments. Automated systems have flagged potential unauthorized access attempts, and we need immediate analysis and response.

**Current Threat Indicators**:
- Multiple failed authentication attempts
- Unusual network traffic patterns
- Suspicious file access logs
- Potential data exfiltration attempts

**Your Mission as SOC Analyst**:
1. Analyze authentication logs for attack patterns
2. Monitor network connections for malicious traffic
3. Identify the attacker's IP address and methods
4. Implement containment measures to secure the system

**Tools Available**:
- Kali Linux SOC workstation
- Wireshark for network analysis
- Log analysis tools
- Network monitoring dashboards

**Time is Critical**: The attacker may still be active in our systems. Quick analysis and response are essential to prevent data breach.

Defend our network, Analyst. The organization's security is in your hands.`,
    tasks: [
      {
        id: 'launch-soc-workstation',
        title: 'Launch SOC Workstation',
        description: 'Initialize your security operations center',
        completed: false,
        xpReward: 50
      },
      {
        id: 'analyze-auth-logs',
        title: 'Analyze Authentication Logs',
        description: 'Review login attempts and identify suspicious patterns',
        completed: false,
        xpReward: 60
      },
      {
        id: 'monitor-network-traffic',
        title: 'Monitor Network Traffic',
        description: 'Use Wireshark to analyze network connections',
        completed: false,
        xpReward: 70
      },
      {
        id: 'identify-attacker-ip',
        title: 'Identify Attacker IP',
        description: 'Trace the source of malicious activities',
        completed: false,
        xpReward: 60
      },
      {
        id: 'secure-system',
        title: 'Secure System',
        description: 'Implement containment and blocking measures',
        completed: false,
        xpReward: 60
      }
    ]
  },
  'premium-vault': {
    id: 'premium-vault',
    name: 'Corporate Vault Heist',
    description: 'Advanced multi-stage attack on a corporate network. Requires completion of previous rooms to unlock.',
    difficulty: 'Hard',
    category: 'Premium Challenge',
    xp: 500,
    estimatedTime: '90-120 minutes',
    completedBy: 1240,
    tags: ['advanced', 'multi-stage', 'steganography'],
    isCompleted: false,
    story: `👑 **PREMIUM CHALLENGE: CORPORATE VAULT HEIST**

**Classification**: TOP SECRET
**Objective**: Multi-stage corporate network infiltration
**Difficulty**: Elite Level
**Prerequisites**: Complete basic offensive and defensive rooms`,
    tasks: [
      {
        id: 'initial-foothold',
        title: 'Initial Network Access',
        description: 'Gain initial foothold in corporate network',
        completed: false,
        xpReward: 100
      },
      {
        id: 'lateral-movement',
        title: 'Lateral Movement',
        description: 'Move through the network undetected',
        completed: false,
        xpReward: 120
      },
      {
        id: 'privilege-escalation-advanced',
        title: 'Advanced Privilege Escalation',
        description: 'Escalate to domain administrator',
        completed: false,
        xpReward: 140
      },
      {
        id: 'vault-access',
        title: 'Vault Access',
        description: 'Access the corporate data vault',
        completed: false,
        xpReward: 140
      }
    ]
  }
};

// API Functions
export const getRoomData = async (roomId: string): Promise<RoomData | null> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 100));
  
  return roomsDatabase[roomId] || null;
};

export const getAllRooms = async (): Promise<RoomData[]> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 100));
  
  return Object.values(roomsDatabase);
};

export const updateRoomProgress = async (roomId: string, taskId: string): Promise<boolean> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 100));
  
  const room = roomsDatabase[roomId];
  if (!room) return false;
  
  const task = room.tasks.find(t => t.id === taskId);
  if (!task) return false;
  
  task.completed = true;
  return true;
};

// Backend API endpoint for task completion
export const completeTask = async (roomId: string, taskId: string): Promise<{
  success: boolean;
  xpAwarded: number;
  message: string;
}> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 200));
  
  const room = roomsDatabase[roomId];
  if (!room) {
    return {
      success: false,
      xpAwarded: 0,
      message: 'Room not found'
    };
  }
  
  const task = room.tasks.find(t => t.id === taskId);
  if (!task) {
    return {
      success: false,
      xpAwarded: 0,
      message: 'Task not found'
    };
  }
  
  if (task.completed) {
    return {
      success: false,
      xpAwarded: 0,
      message: 'Task already completed'
    };
  }
  
  // Mark task as completed
  task.completed = true;
  
  return {
    success: true,
    xpAwarded: task.xpReward,
    message: `Task completed! +${task.xpReward} XP awarded`
  };
};