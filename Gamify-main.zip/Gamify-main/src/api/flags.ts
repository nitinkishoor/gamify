// Backend API for flag submission and validation
export interface FlagSubmission {
  roomId: string;
  flag: string;
  timestamp: string;
}

export interface FlagValidationResult {
  isCorrect: boolean;
  message: string;
  xpAwarded?: number;
  badgeUnlocked?: {
    id: string;
    name: string;
    description: string;
    icon: string;
  };
}

// Correct flags for each room
const correctFlags: Record<string, string> = {
  'bank-attack': 'GAMIFY{secure_vault_master_2024}',
  'soc-defense': 'GAMIFY{threat_contained_systems_secured}',
  'network-recon': 'GAMIFY{network_mapped_vulnerabilities_found}',
  'web-exploit': 'GAMIFY{web_shell_deployed_successfully}',
  'forensics-investigation': 'GAMIFY{evidence_recovered_case_solved}',
  'premium-vault': 'GAMIFY{corporate_vault_infiltrated_elite}'
};

// Flag submission history (in real app, this would be in database)
const submissionHistory: FlagSubmission[] = [];

// Room completion status tracking
const roomCompletionStatus: Record<string, boolean> = {
  'network-recon': true, // Pre-completed for demo
  'bank-attack': false,
  'soc-defense': false,
  'web-exploit': false,
  'forensics-investigation': false,
  'premium-vault': false
};

// API Functions
export const submitFlag = async (roomId: string, flag: string): Promise<FlagValidationResult> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Record submission
  submissionHistory.push({
    roomId,
    flag,
    timestamp: new Date().toISOString()
  });
  
  const correctFlag = correctFlags[roomId];
  
  if (!correctFlag) {
    return {
      isCorrect: false,
      message: 'Invalid room ID'
    };
  }
  
  if (flag.trim() === correctFlag) {
    // Mark room as completed
    roomCompletionStatus[roomId] = true;
    
    // Determine XP and badge based on room
    let xpAwarded = 0;
    let badgeUnlocked = undefined;
    
    switch (roomId) {
      case 'bank-attack':
        xpAwarded = 250;
        badgeUnlocked = {
          id: 'bank-infiltrator',
          name: 'Bank Infiltrator',
          description: 'Successfully infiltrated SecureBank through web exploitation',
          icon: '🏦'
        };
        break;
      case 'soc-defense':
        xpAwarded = 300;
        badgeUnlocked = {
          id: 'soc-defender',
          name: 'SOC Defender',
          description: 'Successfully detected and neutralized cyber threats',
          icon: '🛡️'
        };
        break;
      case 'network-recon':
        xpAwarded = 200;
        badgeUnlocked = {
          id: 'network-scout',
          name: 'Network Scout',
          description: 'Mastered network reconnaissance techniques',
          icon: '🔍'
        };
        break;
      case 'web-exploit':
        xpAwarded = 275;
        badgeUnlocked = {
          id: 'web-hacker',
          name: 'Web Application Hacker',
          description: 'Successfully exploited web vulnerabilities',
          icon: '🌐'
        };
        break;
      case 'forensics-investigation':
        xpAwarded = 350;
        badgeUnlocked = {
          id: 'digital-detective',
          name: 'Digital Detective',
          description: 'Solved complex digital forensics cases',
          icon: '🔬'
        };
        break;
      case 'premium-vault':
        xpAwarded = 500;
        badgeUnlocked = {
          id: 'vault-master',
          name: 'Vault Master',
          description: 'Conquered the ultimate corporate vault challenge',
          icon: '👑'
        };
        break;
    }
    
    return {
      isCorrect: true,
      message: '🎉 Correct flag! Mission accomplished!',
      xpAwarded,
      badgeUnlocked
    };
  } else {
    return {
      isCorrect: false,
      message: '❌ Incorrect flag. Keep investigating and try again!'
    };
  }
};

export const getSubmissionHistory = async (roomId?: string): Promise<FlagSubmission[]> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 100));
  
  if (roomId) {
    return submissionHistory.filter(sub => sub.roomId === roomId);
  }
  
  return submissionHistory;
};

export const validateFlagFormat = (flag: string): boolean => {
  // Check if flag follows GAMIFY{...} format
  const flagPattern = /^GAMIFY\{[^}]+\}$/;
  return flagPattern.test(flag);
};

// Backend API to check room completion status
export const isRoomCompleted = async (roomId: string): Promise<boolean> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 50));
  
  return roomCompletionStatus[roomId] || false;
};

// Backend API to get all completed rooms
export const getCompletedRooms = async (): Promise<string[]> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 50));
  
  return Object.entries(roomCompletionStatus)
    .filter(([_, completed]) => completed)
    .map(([roomId, _]) => roomId);
};