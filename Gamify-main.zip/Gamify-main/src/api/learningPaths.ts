// Backend API for Learning Paths System
import { LearningPath, CareerTrack, UserProgress, PathNode } from '../types/learningPaths';

// Career Tracks Database
const careerTracks: Record<string, CareerTrack> = {
  'foundations': {
    id: 'foundations',
    name: 'Cyber Security Foundations',
    description: 'Essential cybersecurity knowledge for beginners',
    icon: '🛡️',
    color: 'bg-blue-500',
    paths: ['pre-security', 'cyber-fundamentals', 'network-basics'],
    totalXP: 1500,
    completionBadge: {
      id: 'foundations-master',
      name: 'Security Foundations Master',
      description: 'Mastered cybersecurity fundamentals',
      icon: '🎓'
    }
  },
  'analyst': {
    id: 'analyst',
    name: 'SOC Analyst Track',
    description: 'Defensive security and incident response specialist',
    icon: '🔍',
    color: 'bg-green-500',
    paths: ['soc-level-1', 'soc-level-2', 'incident-response', 'threat-hunting'],
    totalXP: 3000,
    completionBadge: {
      id: 'soc-expert',
      name: 'SOC Expert',
      description: 'Elite SOC analyst and threat hunter',
      icon: '🛡️'
    }
  },
  'pentester': {
    id: 'pentester',
    name: 'Penetration Tester Track',
    description: 'Offensive security and ethical hacking specialist',
    icon: '⚔️',
    color: 'bg-red-500',
    paths: ['jr-pentester', 'web-app-security', 'network-pentesting', 'advanced-exploitation'],
    totalXP: 3500,
    completionBadge: {
      id: 'pentest-master',
      name: 'Penetration Testing Master',
      description: 'Elite ethical hacker and security researcher',
      icon: '👑'
    }
  },
  'engineer': {
    id: 'engineer',
    name: 'Security Engineer Track',
    description: 'Security architecture and engineering specialist',
    icon: '⚙️',
    color: 'bg-purple-500',
    paths: ['secure-coding', 'cloud-security', 'devsecops', 'security-architecture'],
    totalXP: 4000,
    completionBadge: {
      id: 'security-architect',
      name: 'Security Architect',
      description: 'Master of security engineering and architecture',
      icon: '🏗️'
    }
  }
};

// Learning Paths Database
const learningPaths: Record<string, LearningPath> = {
  // Foundations Track
  'pre-security': {
    id: 'pre-security',
    title: 'Pre Security',
    description: 'Introduction to cybersecurity concepts and terminology',
    difficulty: 'Easy',
    category: 'foundations',
    xpRequired: 0,
    xpReward: 300,
    estimatedHours: 8,
    prerequisites: [],
    unlocks: ['cyber-fundamentals'],
    rooms: ['intro-to-security', 'basic-networking'],
    quizzes: ['security-basics-quiz'],
    isCompleted: false,
    progressPercent: 0,
    position: { x: 100, y: 100 },
    icon: '🔰',
    color: 'bg-blue-400'
  },
  'cyber-fundamentals': {
    id: 'cyber-fundamentals',
    title: 'Cyber Security Fundamentals',
    description: 'Core cybersecurity principles and practices',
    difficulty: 'Easy',
    category: 'foundations',
    xpRequired: 300,
    xpReward: 500,
    estimatedHours: 12,
    prerequisites: ['pre-security'],
    unlocks: ['network-basics', 'soc-level-1', 'jr-pentester'],
    rooms: ['security-principles', 'risk-management'],
    quizzes: ['fundamentals-quiz'],
    isCompleted: false,
    progressPercent: 0,
    position: { x: 300, y: 100 },
    icon: '🛡️',
    color: 'bg-blue-500'
  },
  'network-basics': {
    id: 'network-basics',
    title: 'Network Security Basics',
    description: 'Understanding network protocols and security',
    difficulty: 'Medium',
    category: 'foundations',
    xpRequired: 800,
    xpReward: 700,
    estimatedHours: 15,
    prerequisites: ['cyber-fundamentals'],
    unlocks: ['soc-level-2', 'network-pentesting'],
    rooms: ['network-recon', 'firewall-basics'],
    quizzes: ['networking-quiz'],
    isCompleted: false,
    progressPercent: 0,
    position: { x: 500, y: 100 },
    icon: '🌐',
    color: 'bg-blue-600'
  },

  // SOC Analyst Track
  'soc-level-1': {
    id: 'soc-level-1',
    title: 'SOC Analyst Level 1',
    description: 'Entry-level SOC operations and monitoring',
    difficulty: 'Medium',
    category: 'analyst',
    xpRequired: 800,
    xpReward: 600,
    estimatedHours: 20,
    prerequisites: ['cyber-fundamentals'],
    unlocks: ['soc-level-2'],
    rooms: ['soc-defense', 'log-analysis-basics'],
    quizzes: ['soc-l1-quiz'],
    isCompleted: false,
    progressPercent: 0,
    position: { x: 200, y: 300 },
    icon: '👁️',
    color: 'bg-green-400'
  },
  'soc-level-2': {
    id: 'soc-level-2',
    title: 'SOC Analyst Level 2',
    description: 'Advanced threat detection and analysis',
    difficulty: 'Hard',
    category: 'analyst',
    xpRequired: 1400,
    xpReward: 800,
    estimatedHours: 25,
    prerequisites: ['soc-level-1', 'network-basics'],
    unlocks: ['incident-response'],
    rooms: ['advanced-siem', 'malware-analysis'],
    quizzes: ['soc-l2-quiz'],
    isCompleted: false,
    progressPercent: 0,
    position: { x: 400, y: 300 },
    icon: '🔍',
    color: 'bg-green-500'
  },
  'incident-response': {
    id: 'incident-response',
    title: 'Incident Response',
    description: 'Handling and responding to security incidents',
    difficulty: 'Hard',
    category: 'analyst',
    xpRequired: 2200,
    xpReward: 900,
    estimatedHours: 30,
    prerequisites: ['soc-level-2'],
    unlocks: ['threat-hunting'],
    rooms: ['forensics-investigation', 'incident-handling'],
    quizzes: ['incident-response-quiz'],
    isCompleted: false,
    progressPercent: 0,
    position: { x: 600, y: 300 },
    icon: '🚨',
    color: 'bg-green-600'
  },
  'threat-hunting': {
    id: 'threat-hunting',
    title: 'Threat Hunting',
    description: 'Proactive threat detection and hunting',
    difficulty: 'Hard',
    category: 'analyst',
    xpRequired: 3100,
    xpReward: 1000,
    estimatedHours: 35,
    prerequisites: ['incident-response'],
    unlocks: [],
    rooms: ['advanced-hunting', 'threat-intelligence'],
    quizzes: ['threat-hunting-quiz'],
    isCompleted: false,
    progressPercent: 0,
    position: { x: 800, y: 300 },
    icon: '🎯',
    color: 'bg-green-700'
  },

  // Penetration Tester Track
  'jr-pentester': {
    id: 'jr-pentester',
    title: 'Junior Penetration Tester',
    description: 'Introduction to ethical hacking and penetration testing',
    difficulty: 'Medium',
    category: 'pentester',
    xpRequired: 800,
    xpReward: 700,
    estimatedHours: 25,
    prerequisites: ['cyber-fundamentals'],
    unlocks: ['web-app-security'],
    rooms: ['bank-attack', 'basic-exploitation'],
    quizzes: ['pentesting-basics-quiz'],
    isCompleted: false,
    progressPercent: 0,
    position: { x: 200, y: 500 },
    icon: '🗡️',
    color: 'bg-red-400'
  },
  'web-app-security': {
    id: 'web-app-security',
    title: 'Web Application Security',
    description: 'Web application vulnerabilities and exploitation',
    difficulty: 'Hard',
    category: 'pentester',
    xpRequired: 1500,
    xpReward: 900,
    estimatedHours: 30,
    prerequisites: ['jr-pentester'],
    unlocks: ['network-pentesting'],
    rooms: ['web-exploit', 'owasp-top-10'],
    quizzes: ['web-security-quiz'],
    isCompleted: false,
    progressPercent: 0,
    position: { x: 400, y: 500 },
    icon: '🌐',
    color: 'bg-red-500'
  },
  'network-pentesting': {
    id: 'network-pentesting',
    title: 'Network Penetration Testing',
    description: 'Network infrastructure testing and exploitation',
    difficulty: 'Hard',
    category: 'pentester',
    xpRequired: 2400,
    xpReward: 1000,
    estimatedHours: 35,
    prerequisites: ['web-app-security', 'network-basics'],
    unlocks: ['advanced-exploitation'],
    rooms: ['network-exploitation', 'privilege-escalation'],
    quizzes: ['network-pentest-quiz'],
    isCompleted: false,
    progressPercent: 0,
    position: { x: 600, y: 500 },
    icon: '🔗',
    color: 'bg-red-600'
  },
  'advanced-exploitation': {
    id: 'advanced-exploitation',
    title: 'Advanced Exploitation',
    description: 'Advanced attack techniques and methodologies',
    difficulty: 'Hard',
    category: 'pentester',
    xpRequired: 3400,
    xpReward: 1200,
    estimatedHours: 40,
    prerequisites: ['network-pentesting'],
    unlocks: [],
    rooms: ['premium-vault', 'advanced-persistence'],
    quizzes: ['advanced-exploitation-quiz'],
    isCompleted: false,
    progressPercent: 0,
    position: { x: 800, y: 500 },
    icon: '💀',
    color: 'bg-red-700'
  },

  // Security Engineer Track
  'secure-coding': {
    id: 'secure-coding',
    title: 'Secure Coding Practices',
    description: 'Writing secure code and preventing vulnerabilities',
    difficulty: 'Medium',
    category: 'engineer',
    xpRequired: 800,
    xpReward: 800,
    estimatedHours: 30,
    prerequisites: ['cyber-fundamentals'],
    unlocks: ['cloud-security'],
    rooms: ['code-review', 'secure-development'],
    quizzes: ['secure-coding-quiz'],
    isCompleted: false,
    progressPercent: 0,
    position: { x: 200, y: 700 },
    icon: '💻',
    color: 'bg-purple-400'
  },
  'cloud-security': {
    id: 'cloud-security',
    title: 'Cloud Security',
    description: 'Securing cloud infrastructure and services',
    difficulty: 'Hard',
    category: 'engineer',
    xpRequired: 1600,
    xpReward: 1000,
    estimatedHours: 35,
    prerequisites: ['secure-coding'],
    unlocks: ['devsecops'],
    rooms: ['aws-security', 'cloud-pentesting'],
    quizzes: ['cloud-security-quiz'],
    isCompleted: false,
    progressPercent: 0,
    position: { x: 400, y: 700 },
    icon: '☁️',
    color: 'bg-purple-500'
  },
  'devsecops': {
    id: 'devsecops',
    title: 'DevSecOps',
    description: 'Integrating security into development pipelines',
    difficulty: 'Hard',
    category: 'engineer',
    xpRequired: 2600,
    xpReward: 1100,
    estimatedHours: 40,
    prerequisites: ['cloud-security'],
    unlocks: ['security-architecture'],
    rooms: ['ci-cd-security', 'container-security'],
    quizzes: ['devsecops-quiz'],
    isCompleted: false,
    progressPercent: 0,
    position: { x: 600, y: 700 },
    icon: '🔄',
    color: 'bg-purple-600'
  },
  'security-architecture': {
    id: 'security-architecture',
    title: 'Security Architecture',
    description: 'Designing secure systems and architectures',
    difficulty: 'Hard',
    category: 'engineer',
    xpRequired: 3700,
    xpReward: 1300,
    estimatedHours: 45,
    prerequisites: ['devsecops'],
    unlocks: [],
    rooms: ['architecture-design', 'security-patterns'],
    quizzes: ['architecture-quiz'],
    isCompleted: false,
    progressPercent: 0,
    position: { x: 800, y: 700 },
    icon: '🏗️',
    color: 'bg-purple-700'
  }
};

// User Progress Storage (in real app, this would be in database)
let userProgressData: Record<string, UserProgress[]> = {};

// API Functions
export const getCareerTracks = async (): Promise<CareerTrack[]> => {
  await new Promise(resolve => setTimeout(resolve, 100));
  return Object.values(careerTracks);
};

export const getLearningPaths = async (trackId?: string): Promise<LearningPath[]> => {
  await new Promise(resolve => setTimeout(resolve, 100));
  
  if (trackId) {
    const track = careerTracks[trackId];
    if (!track) return [];
    return track.paths.map(pathId => learningPaths[pathId]).filter(Boolean);
  }
  
  return Object.values(learningPaths);
};

export const getUserProgress = async (userId: string): Promise<UserProgress[]> => {
  await new Promise(resolve => setTimeout(resolve, 100));
  return userProgressData[userId] || [];
};

export const updatePathProgress = async (
  userId: string, 
  pathId: string, 
  progressPercent: number,
  roomCompleted?: string
): Promise<UserProgress> => {
  await new Promise(resolve => setTimeout(resolve, 200));
  
  if (!userProgressData[userId]) {
    userProgressData[userId] = [];
  }
  
  let progress = userProgressData[userId].find(p => p.pathId === pathId);
  
  if (!progress) {
    progress = {
      userId,
      pathId,
      progressPercent: 0,
      completed: false,
      startedAt: new Date().toISOString(),
      roomsCompleted: [],
      quizzesCompleted: []
    };
    userProgressData[userId].push(progress);
  }
  
  progress.progressPercent = Math.max(progress.progressPercent, progressPercent);
  progress.completed = progress.progressPercent >= 100;
  
  if (roomCompleted && !progress.roomsCompleted.includes(roomCompleted)) {
    progress.roomsCompleted.push(roomCompleted);
  }
  
  if (progress.completed && !progress.completedAt) {
    progress.completedAt = new Date().toISOString();
  }
  
  return progress;
};

export const getPathNodes = async (userId: string, userXP: number): Promise<PathNode[]> => {
  await new Promise(resolve => setTimeout(resolve, 150));
  
  const userProgress = await getUserProgress(userId);
  const progressMap = new Map(userProgress.map(p => [p.pathId, p]));
  
  return Object.values(learningPaths).map(path => {
    const progress = progressMap.get(path.id);
    const isUnlocked = path.prerequisites.length === 0 || 
      path.prerequisites.every(prereq => {
        const prereqProgress = progressMap.get(prereq);
        return prereqProgress?.completed || false;
      }) || userXP >= path.xpRequired;
    
    return {
      path: {
        ...path,
        isCompleted: progress?.completed || false,
        progressPercent: progress?.progressPercent || 0
      },
      isUnlocked,
      isActive: progress?.progressPercent > 0 && !progress?.completed,
      connections: path.unlocks
    };
  });
};

export const startPath = async (userId: string, pathId: string): Promise<boolean> => {
  await new Promise(resolve => setTimeout(resolve, 200));
  
  const path = learningPaths[pathId];
  if (!path) return false;
  
  await updatePathProgress(userId, pathId, 5); // 5% for starting
  return true;
};

export const completePath = async (userId: string, pathId: string): Promise<{
  success: boolean;
  xpAwarded: number;
  badgeUnlocked?: any;
  pathsUnlocked: string[];
}> => {
  await new Promise(resolve => setTimeout(resolve, 300));
  
  const path = learningPaths[pathId];
  if (!path) return { success: false, xpAwarded: 0, pathsUnlocked: [] };
  
  await updatePathProgress(userId, pathId, 100);
  
  // Check if track is completed
  const track = Object.values(careerTracks).find(t => t.paths.includes(pathId));
  let badgeUnlocked = undefined;
  
  if (track) {
    const userProgress = await getUserProgress(userId);
    const trackCompleted = track.paths.every(pId => {
      const progress = userProgress.find(p => p.pathId === pId);
      return progress?.completed;
    });
    
    if (trackCompleted) {
      badgeUnlocked = track.completionBadge;
    }
  }
  
  return {
    success: true,
    xpAwarded: path.xpReward,
    badgeUnlocked,
    pathsUnlocked: path.unlocks
  };
};