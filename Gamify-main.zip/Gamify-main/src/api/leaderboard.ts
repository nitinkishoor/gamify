// Backend API for leaderboard and scoring
export interface LeaderboardEntry {
  id: string;
  rank: number;
  name: string;
  avatar: string;
  xp: number;
  level: number;
  roomsCompleted: number;
  streak: number;
  country: string;
  lastActive: string;
}

export interface ScoreUpdate {
  userId: string;
  xpGained: number;
  roomCompleted?: string;
  badgeEarned?: string;
  newLevel?: number;
}

// Mock leaderboard data
let leaderboardData: LeaderboardEntry[] = [
  {
    id: '1',
    rank: 1,
    name: 'CyberNinja',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=user1',
    xp: 15420,
    level: 62,
    roomsCompleted: 187,
    streak: 45,
    country: '🇮🇳',
    lastActive: '2024-01-20T14:30:00Z'
  },
  {
    id: '2',
    rank: 2,
    name: 'SecurityMaster',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=user2',
    xp: 14850,
    level: 60,
    roomsCompleted: 175,
    streak: 32,
    country: '🇮🇳',
    lastActive: '2024-01-20T13:45:00Z'
  },
  {
    id: '3',
    rank: 3,
    name: 'HackWizard',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=user3',
    xp: 13200,
    level: 53,
    roomsCompleted: 156,
    streak: 28,
    country: '🇮🇳',
    lastActive: '2024-01-20T12:20:00Z'
  },
  {
    id: '4',
    rank: 4,
    name: 'CryptoSleuth',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=user4',
    xp: 11780,
    level: 48,
    roomsCompleted: 142,
    streak: 21,
    country: '🇮🇳',
    lastActive: '2024-01-20T11:15:00Z'
  },
  {
    id: '5',
    rank: 5,
    name: 'Cyber Warrior',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=google-user',
    xp: 10250,
    level: 41,
    roomsCompleted: 128,
    streak: 15,
    country: '🇮🇳',
    lastActive: '2024-01-20T14:25:00Z'
  },
  {
    id: '6',
    rank: 6,
    name: 'PentestPro',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=user6',
    xp: 9850,
    level: 40,
    roomsCompleted: 118,
    streak: 19,
    country: '🇮🇳',
    lastActive: '2024-01-20T10:30:00Z'
  },
  {
    id: '7',
    rank: 7,
    name: 'ForensicsExpert',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=user7',
    xp: 8900,
    level: 36,
    roomsCompleted: 102,
    streak: 12,
    country: '🇮🇳',
    lastActive: '2024-01-20T09:45:00Z'
  },
  {
    id: '8',
    rank: 8,
    name: 'NetworkGuard',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=user8',
    xp: 7650,
    level: 31,
    roomsCompleted: 89,
    streak: 8,
    country: '🇮🇳',
    lastActive: '2024-01-20T08:20:00Z'
  }
];

// API Functions
export const getLeaderboard = async (timeframe: 'all' | 'monthly' | 'weekly' = 'all'): Promise<LeaderboardEntry[]> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 200));
  
  // In a real implementation, this would filter by timeframe
  // For now, return the same data but could be filtered by lastActive date
  
  return [...leaderboardData].sort((a, b) => b.xp - a.xp).map((entry, index) => ({
    ...entry,
    rank: index + 1
  }));
};

export const updateUserScore = async (scoreUpdate: ScoreUpdate): Promise<LeaderboardEntry | null> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 300));
  
  const userIndex = leaderboardData.findIndex(entry => entry.id === scoreUpdate.userId);
  
  if (userIndex === -1) {
    return null;
  }
  
  const user = leaderboardData[userIndex];
  
  // Update user stats
  user.xp += scoreUpdate.xpGained;
  user.level = scoreUpdate.newLevel || Math.floor(user.xp / 250) + 1;
  user.lastActive = new Date().toISOString();
  
  if (scoreUpdate.roomCompleted) {
    user.roomsCompleted += 1;
  }
  
  // Re-sort leaderboard
  leaderboardData.sort((a, b) => b.xp - a.xp);
  
  // Update ranks
  leaderboardData.forEach((entry, index) => {
    entry.rank = index + 1;
  });
  
  return user;
};

export const getUserRank = async (userId: string): Promise<number | null> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 100));
  
  const user = leaderboardData.find(entry => entry.id === userId);
  return user ? user.rank : null;
};

// Backend API for real-time leaderboard updates
export const updateLeaderboardRealTime = async (userId: string, xpGained: number): Promise<{
  newRank: number;
  oldRank: number;
  totalXP: number;
  newLevel: number;
}> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 200));
  
  const userIndex = leaderboardData.findIndex(entry => entry.id === userId);
  
  if (userIndex === -1) {
    throw new Error('User not found');
  }
  
  const user = leaderboardData[userIndex];
  const oldRank = user.rank;
  
  // Update user stats
  user.xp += xpGained;
  user.level = Math.floor(user.xp / 250) + 1;
  user.lastActive = new Date().toISOString();
  
  // Re-sort leaderboard
  leaderboardData.sort((a, b) => b.xp - a.xp);
  
  // Update ranks
  leaderboardData.forEach((entry, index) => {
    entry.rank = index + 1;
  });
  
  return {
    newRank: user.rank,
    oldRank,
    totalXP: user.xp,
    newLevel: user.level
  };
};