// Backend API for SOC log analysis
export interface LogEntry {
  id: string;
  timestamp: string;
  level: 'INFO' | 'WARNING' | 'ERROR' | 'CRITICAL';
  source: string;
  message: string;
  ip?: string;
  user?: string;
  action?: string;
}

export interface NetworkConnection {
  id: string;
  timestamp: string;
  sourceIP: string;
  destIP: string;
  port: number;
  protocol: string;
  status: 'ESTABLISHED' | 'CLOSED' | 'LISTENING' | 'SUSPICIOUS';
  bytes: number;
}

// Additional interfaces for SOC analysis
export interface ThreatAnalysis {
  suspiciousIPs: string[];
  attackPatterns: Array<{
    type: string;
    severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
    description: string;
    affectedSystems: string[];
  }>;
  recommendations: string[];
}

export interface SystemStatus {
  compromised: boolean;
  threatsDetected: number;
  systemsAffected: number;
  lastUpdate: string;
}

// Mock log data for SOC analysis
const authenticationLogs: LogEntry[] = [
  {
    id: 'log_001',
    timestamp: '2024-01-20 14:23:15',
    level: 'INFO',
    source: 'AUTH_SERVICE',
    message: 'Successful login',
    ip: '192.168.1.100',
    user: 'john.doe',
    action: 'LOGIN_SUCCESS'
  },
  {
    id: 'log_002',
    timestamp: '2024-01-20 14:25:32',
    level: 'WARNING',
    source: 'AUTH_SERVICE',
    message: 'Failed login attempt',
    ip: '203.0.113.45',
    user: 'admin',
    action: 'LOGIN_FAILED'
  },
  {
    id: 'log_003',
    timestamp: '2024-01-20 14:25:45',
    level: 'WARNING',
    source: 'AUTH_SERVICE',
    message: 'Failed login attempt',
    ip: '203.0.113.45',
    user: 'administrator',
    action: 'LOGIN_FAILED'
  },
  {
    id: 'log_004',
    timestamp: '2024-01-20 14:26:01',
    level: 'WARNING',
    source: 'AUTH_SERVICE',
    message: 'Failed login attempt',
    ip: '203.0.113.45',
    user: 'root',
    action: 'LOGIN_FAILED'
  },
  {
    id: 'log_005',
    timestamp: '2024-01-20 14:26:15',
    level: 'CRITICAL',
    source: 'AUTH_SERVICE',
    message: 'Multiple failed login attempts detected',
    ip: '203.0.113.45',
    user: 'various',
    action: 'BRUTE_FORCE_DETECTED'
  },
  {
    id: 'log_006',
    timestamp: '2024-01-20 14:27:30',
    level: 'ERROR',
    source: 'FILE_ACCESS',
    message: 'Unauthorized file access attempt',
    ip: '203.0.113.45',
    user: 'unknown',
    action: 'FILE_ACCESS_DENIED'
  },
  {
    id: 'log_007',
    timestamp: '2024-01-20 14:28:45',
    level: 'CRITICAL',
    source: 'NETWORK_MONITOR',
    message: 'Suspicious data exfiltration detected',
    ip: '203.0.113.45',
    user: 'system',
    action: 'DATA_EXFILTRATION_ATTEMPT'
  },
  {
    id: 'log_008',
    timestamp: '2024-01-20 14:29:12',
    level: 'ERROR',
    source: 'FIREWALL',
    message: 'Port scanning activity detected',
    ip: '203.0.113.45',
    user: 'system',
    action: 'PORT_SCAN_DETECTED'
  }
];

const networkConnections: NetworkConnection[] = [
  {
    id: 'conn_001',
    timestamp: '2024-01-20 14:23:00',
    sourceIP: '192.168.1.100',
    destIP: '10.0.0.50',
    port: 443,
    protocol: 'HTTPS',
    status: 'ESTABLISHED',
    bytes: 2048
  },
  {
    id: 'conn_002',
    timestamp: '2024-01-20 14:25:30',
    sourceIP: '203.0.113.45',
    destIP: '10.0.0.50',
    port: 22,
    protocol: 'SSH',
    status: 'SUSPICIOUS',
    bytes: 512
  },
  {
    id: 'conn_003',
    timestamp: '2024-01-20 14:25:45',
    sourceIP: '203.0.113.45',
    destIP: '10.0.0.50',
    port: 80,
    protocol: 'HTTP',
    status: 'SUSPICIOUS',
    bytes: 1024
  },
  {
    id: 'conn_004',
    timestamp: '2024-01-20 14:26:00',
    sourceIP: '203.0.113.45',
    destIP: '10.0.0.50',
    port: 3389,
    protocol: 'RDP',
    status: 'SUSPICIOUS',
    bytes: 256
  },
  {
    id: 'conn_005',
    timestamp: '2024-01-20 14:27:15',
    sourceIP: '203.0.113.45',
    destIP: '198.51.100.10',
    port: 443,
    protocol: 'HTTPS',
    status: 'SUSPICIOUS',
    bytes: 4096
  },
  {
    id: 'conn_006',
    timestamp: '2024-01-20 14:28:30',
    sourceIP: '203.0.113.45',
    destIP: '198.51.100.10',
    port: 9999,
    protocol: 'TCP',
    status: 'SUSPICIOUS',
    bytes: 8192
  },
  {
    id: 'conn_007',
    timestamp: '2024-01-20 14:29:00',
    sourceIP: '10.0.0.50',
    destIP: '203.0.113.45',
    port: 4444,
    protocol: 'TCP',
    status: 'SUSPICIOUS',
    bytes: 16384
  }
];

// API Functions
export const getAuthenticationLogs = async (): Promise<LogEntry[]> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 200));
  return authenticationLogs;
};

export const getNetworkConnections = async (): Promise<NetworkConnection[]> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 200));
  return networkConnections;
};

export const analyzeLogPattern = async (ip: string): Promise<{
  suspiciousActivity: boolean;
  attackType: string;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  recommendations: string[];
}> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 300));
  
  if (ip === '203.0.113.45') {
    return {
      suspiciousActivity: true,
      attackType: 'Brute Force Attack',
      riskLevel: 'CRITICAL',
      recommendations: [
        'Block IP address immediately',
        'Reset passwords for targeted accounts',
        'Enable account lockout policies',
        'Monitor for lateral movement'
      ]
    };
  }
  
  return {
    suspiciousActivity: false,
    attackType: 'None',
    riskLevel: 'LOW',
    recommendations: ['Continue monitoring']
  };
};

// Backend API for comprehensive threat analysis
export const performThreatAnalysis = async (): Promise<ThreatAnalysis> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 400));
  
  return {
    suspiciousIPs: ['203.0.113.45', '198.51.100.10'],
    attackPatterns: [
      {
        type: 'Brute Force Attack',
        severity: 'CRITICAL',
        description: 'Multiple failed authentication attempts from single IP',
        affectedSystems: ['AUTH_SERVICE', 'WEB_SERVER']
      },
      {
        type: 'Data Exfiltration',
        severity: 'HIGH',
        description: 'Suspicious outbound data transfers detected',
        affectedSystems: ['FILE_SERVER', 'DATABASE']
      },
      {
        type: 'Port Scanning',
        severity: 'MEDIUM',
        description: 'Network reconnaissance activity detected',
        affectedSystems: ['FIREWALL', 'NETWORK_INFRASTRUCTURE']
      }
    ],
    recommendations: [
      'Immediately block suspicious IP addresses',
      'Reset all potentially compromised user accounts',
      'Enable enhanced monitoring on affected systems',
      'Conduct full security audit of network infrastructure',
      'Implement additional access controls and monitoring'
    ]
  };
};

// Backend API for system status monitoring
export const getSystemStatus = async (): Promise<SystemStatus> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 150));
  
  return {
    compromised: true,
    threatsDetected: 3,
    systemsAffected: 6,
    lastUpdate: new Date().toISOString()
  };
};

// Backend API for blocking suspicious IPs
export const blockSuspiciousIP = async (ip: string): Promise<{
  success: boolean;
  message: string;
  blockedIP: string;
}> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 300));
  
  if (ip === '203.0.113.45') {
    return {
      success: true,
      message: 'IP address successfully blocked and threat contained',
      blockedIP: ip
    };
  }
  
  return {
    success: false,
    message: 'Failed to block IP address',
    blockedIP: ip
  };
};