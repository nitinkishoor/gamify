import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Terminal, Play, CheckCircle, HelpCircle, Flag, Bot, Send, Monitor, Maximize2, RefreshCw, Globe, Shield, Eye, Lock, AlertTriangle, Search } from 'lucide-react';
import { useGame } from '../contexts/GameContext';

const RoomDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { addXP, completeRoom } = useGame();
  
  const [currentTask, setCurrentTask] = useState(0);
  const [flagInput, setFlagInput] = useState('');
  const [isHintOpen, setIsHintOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<Array<{text: string, isBot: boolean}>>([
    { text: "Hi! I'm your mission support AI. I can guide you through every step of this challenge. What would you like to know?", isBot: true }
  ]);
  const [chatInput, setChatInput] = useState('');
  const [environmentLaunched, setEnvironmentLaunched] = useState(false);
  
  // Bank Attack specific states
  const [bankUrl, setBankUrl] = useState('https://securebank.local');
  const [currentPage, setCurrentPage] = useState('login');
  const [loginData, setLoginData] = useState({ username: '', password: '' });
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [accountBalance, setAccountBalance] = useState(50000);
  const [transferAmount, setTransferAmount] = useState('');
  const [transferTo, setTransferTo] = useState('');
  const [adminAccess, setAdminAccess] = useState(false);
  
  // SOC Analyst specific states
  const [logEntries, setLogEntries] = useState<Array<{timestamp: string, level: string, message: string, source: string}>>([]);
  const [networkConnections, setNetworkConnections] = useState<Array<{local: string, remote: string, state: string, process: string}>>([]);
  const [suspiciousIP, setSuspiciousIP] = useState('');
  const [isBlocked, setIsBlocked] = useState(false);
  const [activeTab, setActiveTab] = useState('logs');

  // Room data based on ID
  const getRoomData = (roomId: string) => {
    switch (roomId) {
      case 'bank-attack':
        return {
          id: roomId,
          name: 'Bank Attack Mission',
          description: 'Infiltrate SecureBank Corp through web exploitation',
          difficulty: 'Easy',
          xp: 250,
          story: `🏦 **MISSION BRIEFING - OPERATION VAULT BREACH**

**CLIENT:** SecureBank Corp (Authorized Penetration Test)
**MISSION TYPE:** Web Application Security Assessment
**CLEARANCE LEVEL:** Confidential

You are Agent Cyber, hired to test SecureBank's online banking security. Intelligence suggests their web application has hidden administrative functions that could be exploited.

**SITUATION:**
- SecureBank believes their online banking is secure
- They've challenged you to find vulnerabilities in their web application
- You have access to their banking website through a controlled environment
- Your goal is to gain unauthorized access and demonstrate the security flaw

**YOUR MISSION:**
1. Access the SecureBank online banking website
2. Discover hidden administrative pages or functions
3. Exploit authentication weaknesses to gain admin access
4. Perform unauthorized account operations
5. Extract the proof-of-concept flag

**RULES OF ENGAGEMENT:**
- Use only web-based attack techniques
- Document your attack vector
- Extract the flag format: GAMIFY{...}

**WARNING:** This is a controlled environment for educational purposes only.

*Good luck, Agent. Show them their vulnerabilities.*`,
          tasks: [
            {
              id: 1,
              title: 'Launch Banking Environment',
              description: 'Access the SecureBank online banking website and explore the interface',
              flag: 'GAMIFY{banking_site_accessed}',
              completed: false,
              hint: 'Click "Launch Banking Environment" to access the SecureBank website. Look for login forms and navigation elements.'
            },
            {
              id: 2,
              title: 'Discover Hidden Admin Page',
              description: 'Find the hidden administrative interface by exploring URL paths and directory structures',
              flag: 'GAMIFY{admin_page_discovered}',
              completed: false,
              hint: 'Try common admin paths like /admin, /administrator, or look for hidden links in the page source. Check the browser address bar.'
            },
            {
              id: 3,
              title: 'Bypass Authentication',
              description: 'Gain unauthorized access to the administrative panel using common web vulnerabilities',
              flag: 'GAMIFY{admin_access_gained}',
              completed: false,
              hint: 'Try common admin credentials like admin/admin, admin/password, or look for SQL injection opportunities in login forms.'
            },
            {
              id: 4,
              title: 'Execute Unauthorized Transfer',
              description: 'Use your admin access to perform an unauthorized bank transfer and extract the final flag',
              flag: 'GAMIFY{bank_hacked}',
              completed: false,
              hint: 'Access the admin transfer function and move funds between accounts. The system will reveal the final flag upon successful exploitation.'
            }
          ]
        };
      case 'soc-defense':
        return {
          id: roomId,
          name: 'SOC Analyst Defense',
          description: 'Detect and respond to a live cyber attack',
          difficulty: 'Medium',
          xp: 300,
          story: `🚨 **SECURITY ALERT - CODE RED INCIDENT**

**ORGANIZATION:** CyberDefense Inc.
**POSITION:** SOC Analyst Level 2
**INCIDENT ID:** INC-2024-0157
**PRIORITY:** CRITICAL

**SITUATION REPORT:**
At 14:30 hours, our SIEM systems detected suspicious activity across multiple network segments. You are the on-duty SOC analyst responsible for incident response.

**INITIAL INDICATORS:**
- Multiple failed authentication attempts from external IPs
- Unusual outbound network traffic patterns
- Potential data exfiltration in progress
- System performance degradation on critical servers

**THREAT INTELLIGENCE:**
- Attack appears to be coordinated and sophisticated
- Possible APT (Advanced Persistent Threat) involvement
- Attackers may have established persistence mechanisms
- Customer data potentially at risk

**YOUR MISSION AS SOC ANALYST:**
1. Launch the SOC monitoring environment
2. Analyze system logs for suspicious activities
3. Investigate network connections and traffic patterns
4. Identify the attack source and methods
5. Implement containment measures
6. Secure the compromised systems

**AVAILABLE TOOLS:**
- Log analysis dashboard
- Network connection monitor
- Traffic analysis tools
- Firewall management interface

**CRITICAL:** The attack is ongoing. Every second counts. Document your findings and take immediate action.

*Remember: Stay calm, follow SOC procedures, and protect our infrastructure.*`,
          tasks: [
            {
              id: 1,
              title: 'Activate SOC Environment',
              description: 'Launch the SOC monitoring dashboard and access security analysis tools',
              flag: 'GAMIFY{soc_environment_active}',
              completed: false,
              hint: 'Click "Launch SOC Environment" to access the security monitoring dashboard with logs and network analysis tools.'
            },
            {
              id: 2,
              title: 'Analyze Security Logs',
              description: 'Examine system logs to identify suspicious authentication attempts and security events',
              flag: 'GAMIFY{suspicious_activity_detected}',
              completed: false,
              hint: 'Check the "System Logs" tab for failed login attempts, unusual access patterns, and security alerts. Look for repeated failures from the same IP.'
            },
            {
              id: 3,
              title: 'Investigate Network Connections',
              description: 'Monitor active network connections to identify unauthorized access and data exfiltration',
              flag: 'GAMIFY{malicious_connections_found}',
              completed: false,
              hint: 'Switch to "Network Connections" tab to see active connections. Look for suspicious external IPs and unusual traffic patterns.'
            },
            {
              id: 4,
              title: 'Identify Attack Source',
              description: 'Trace the attack back to its source IP address and document the attack vector',
              flag: 'GAMIFY{attacker_ip_identified}',
              completed: false,
              hint: 'Correlate the log entries with network connections to identify the primary attacker IP. Look for the most frequent malicious IP address.'
            },
            {
              id: 5,
              title: 'Secure and Block Threat',
              description: 'Block the malicious IP address and secure the compromised systems',
              flag: 'GAMIFY{threat_neutralized}',
              completed: false,
              hint: 'Use the firewall controls to block the identified malicious IP address. Click "Block IP" to neutralize the threat.'
            }
          ]
        };
      default:
        return {
          id: roomId,
          name: 'Room Not Found',
          description: 'This room is under development',
          difficulty: 'Easy',
          xp: 0,
          story: 'Room content is being prepared...',
          tasks: []
        };
    }
  };

  const room = getRoomData(id || '');

  // Initialize room-specific data
  useEffect(() => {
    if (room.id === 'soc-defense') {
      // Generate realistic log entries
      const logs = [
        { timestamp: '14:30:15', level: 'WARNING', message: 'Failed SSH login attempt for user "admin"', source: '192.168.100.50' },
        { timestamp: '14:30:18', level: 'WARNING', message: 'Failed SSH login attempt for user "root"', source: '192.168.100.50' },
        { timestamp: '14:30:21', level: 'ERROR', message: 'Multiple authentication failures detected', source: '192.168.100.50' },
        { timestamp: '14:30:25', level: 'ALERT', message: 'Brute force attack detected from external IP', source: '192.168.100.50' },
        { timestamp: '14:30:30', level: 'WARNING', message: 'Unusual outbound traffic detected', source: '10.0.0.100' },
        { timestamp: '14:30:35', level: 'ERROR', message: 'Potential data exfiltration attempt', source: '10.0.0.100' },
        { timestamp: '14:30:40', level: 'CRITICAL', message: 'Unauthorized access to sensitive directory', source: '192.168.100.50' }
      ];
      setLogEntries(logs);

      // Generate network connections
      const connections = [
        { local: '10.0.0.100:22', remote: '192.168.100.50:45678', state: 'ESTABLISHED', process: 'sshd' },
        { local: '10.0.0.100:80', remote: '192.168.100.50:45679', state: 'ESTABLISHED', process: 'apache2' },
        { local: '10.0.0.100:443', remote: '203.0.113.25:54321', state: 'ESTABLISHED', process: 'nginx' },
        { local: '10.0.0.100:3306', remote: '192.168.100.50:45680', state: 'ESTABLISHED', process: 'mysqld' },
        { local: '10.0.0.100:21', remote: '192.168.100.50:45681', state: 'TIME_WAIT', process: 'vsftpd' }
      ];
      setNetworkConnections(connections);
    }
  }, [room.id]);

  const handleFlagSubmit = (taskIndex: number) => {
    const task = room.tasks[taskIndex];
    if (flagInput.trim() === task.flag) {
      addXP(50);
      task.completed = true;
      if (taskIndex < room.tasks.length - 1) {
        setCurrentTask(taskIndex + 1);
      } else {
        completeRoom(room.id!);
        addXP(room.xp);
      }
      setFlagInput('');
    } else {
      alert('Incorrect flag! Try again.');
    }
  };

  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    const userMessage = { text: chatInput, isBot: false };
    const botResponse = {
      text: generateBotResponse(chatInput),
      isBot: true
    };

    setChatMessages(prev => [...prev, userMessage, botResponse]);
    setChatInput('');
  };

  const generateBotResponse = (input: string): string => {
    const lowerInput = input.toLowerCase();
    
    // Bank Attack Mission (Offensive Security) - Detailed Step-by-Step Guidance
    if (room.id === 'bank-attack') {
      if (currentTask === 0) {
        if (lowerInput.includes('step') || lowerInput.includes('how') || lowerInput.includes('start')) {
          return "**STEP 1 - Launch Banking Environment:**\n1. Click the 'Launch Banking Environment' button below\n2. This opens the SecureBank website in a simulated browser\n3. You'll see the bank's login page with username/password fields\n4. Explore the website interface and navigation\n5. Look for any unusual elements or hidden features\n6. This completes Task 1 and unlocks the next phase!";
        }
        return "Ready to start your bank infiltration mission? Ask me 'how to start' or 'next step' for detailed guidance!";
      } else if (currentTask === 1) {
        if (lowerInput.includes('step') || lowerInput.includes('how') || lowerInput.includes('admin') || lowerInput.includes('hidden')) {
          return "**STEP 2 - Discover Hidden Admin Page:**\n1. In the browser address bar, try common admin paths:\n   - /admin\n   - /administrator\n   - /admin.php\n   - /admin/login\n2. Look for hidden links in the page source (right-click → View Source)\n3. Check for commented-out admin links\n4. Try directory traversal techniques\n5. The admin page will have different styling and admin login form\n6. Task 2 completes when you find the admin interface!";
        }
        return "Time to find the hidden admin interface! Ask me 'how to find admin page' or 'next step' for detailed discovery techniques.";
      } else if (currentTask === 2) {
        if (lowerInput.includes('step') || lowerInput.includes('how') || lowerInput.includes('bypass') || lowerInput.includes('login')) {
          return "**STEP 3 - Bypass Authentication:**\n1. Try common admin credentials:\n   - admin / admin\n   - admin / password\n   - administrator / admin\n2. Test for SQL injection in login form:\n   - Username: admin' OR '1'='1' --\n   - Password: anything\n3. Look for default credentials in page comments\n4. Try weak password combinations\n5. The system will grant admin access with correct credentials\n6. Task 3 completes when you gain admin panel access!";
        }
        return "Now to bypass the admin authentication! Ask me 'how to bypass login' or 'next step' for authentication bypass techniques.";
      } else if (currentTask === 3) {
        if (lowerInput.includes('step') || lowerInput.includes('how') || lowerInput.includes('transfer') || lowerInput.includes('hack')) {
          return "**STEP 4 - Execute Unauthorized Transfer:**\n1. Access the admin transfer function in the admin panel\n2. Look for 'Transfer Funds' or 'Account Management' section\n3. Select source account (high-balance account)\n4. Enter destination account number\n5. Set transfer amount (try large amounts)\n6. Execute the transfer - system will show success message\n7. The final flag GAMIFY{bank_hacked} will be revealed\n8. Submit this flag to complete the mission!";
        }
        return "Final step - execute the unauthorized transfer! Ask me 'how to transfer funds' or 'next step' for the final exploitation steps.";
      }
    }
    
    // SOC Analyst Defense (Defensive Security) - Detailed Step-by-Step Guidance
    else if (room.id === 'soc-defense') {
      if (currentTask === 0) {
        if (lowerInput.includes('step') || lowerInput.includes('how') || lowerInput.includes('start') || lowerInput.includes('launch')) {
          return "**STEP 1 - Activate SOC Environment:**\n1. Click 'Launch SOC Environment' to start monitoring dashboard\n2. Wait for the SOC interface to load completely\n3. You'll see tabs for 'System Logs' and 'Network Connections'\n4. The dashboard shows real-time security monitoring data\n5. Familiarize yourself with the interface layout\n6. Task 1 completes when environment is fully loaded!";
        }
        return "SOC Alert! Cyber attack in progress. Ask me 'how to start' or 'next step' to activate your security workstation immediately!";
      } else if (currentTask === 1) {
        if (lowerInput.includes('step') || lowerInput.includes('how') || lowerInput.includes('logs') || lowerInput.includes('analyze')) {
          return "**STEP 2 - Analyze Security Logs:**\n1. Click on the 'System Logs' tab in the SOC dashboard\n2. Examine each log entry carefully\n3. Look for 'WARNING' and 'ERROR' level messages\n4. Identify repeated failed login attempts\n5. Note the source IP addresses in the logs\n6. Count multiple authentication failures from same IP\n7. Look for 'Brute force attack detected' alerts\n8. Task 2 completes when you identify the suspicious pattern!";
        }
        return "Time to analyze the security logs for threats! Ask me 'how to analyze logs' or 'next step' for detailed log analysis instructions.";
      } else if (currentTask === 2) {
        if (lowerInput.includes('step') || lowerInput.includes('how') || lowerInput.includes('network') || lowerInput.includes('connections')) {
          return "**STEP 3 - Investigate Network Connections:**\n1. Switch to the 'Network Connections' tab\n2. Review all active network connections\n3. Look for connections from external IP addresses\n4. Identify suspicious remote connections to sensitive ports (22, 3306)\n5. Note connections in 'ESTABLISHED' state from external IPs\n6. Cross-reference IPs with the log entries\n7. Look for the same IP appearing in both logs and connections\n8. Task 3 completes when you find malicious connections!";
        }
        return "Network analysis will reveal the attack vectors! Ask me 'how to check connections' or 'next step' for network investigation steps.";
      } else if (currentTask === 3) {
        if (lowerInput.includes('step') || lowerInput.includes('how') || lowerInput.includes('identify') || lowerInput.includes('source')) {
          return "**STEP 4 - Identify Attack Source:**\n1. Compare the log entries with network connections\n2. Find the IP address that appears most frequently\n3. Look for 192.168.100.50 in both logs and connections\n4. This IP shows multiple failed logins and active connections\n5. Note it's connected to SSH (port 22) and MySQL (port 3306)\n6. This is your primary threat - the attacker's IP\n7. Document this IP as the attack source\n8. Task 4 completes when you identify the malicious IP!";
        }
        return "Time to identify the attack source! Ask me 'how to find attacker IP' or 'next step' for IP identification procedures.";
      } else if (currentTask === 4) {
        if (lowerInput.includes('step') || lowerInput.includes('how') || lowerInput.includes('block') || lowerInput.includes('secure')) {
          return "**STEP 5 - Secure and Block Threat:**\n1. Look for the 'Block IP' or 'Firewall' controls in the dashboard\n2. Enter the malicious IP address: 192.168.100.50\n3. Click 'Block IP' to add firewall rule\n4. Verify the IP is successfully blocked\n5. Check that malicious connections are terminated\n6. Monitor logs for confirmation of blocked attempts\n7. The system will show 'Threat Neutralized' message\n8. Submit flag: GAMIFY{threat_neutralized} to complete mission!";
        }
        return "Final step - neutralize the threat! Ask me 'how to block attacker' or 'next step' for threat containment procedures.";
      }
    }
    
    // General responses for both rooms
    if (lowerInput.includes('hint') || lowerInput.includes('help')) {
      return room.tasks[currentTask]?.hint || "Excellent work! You've completed all mission objectives. Ready for the next challenge?";
    } else if (lowerInput.includes('stuck') || lowerInput.includes('confused')) {
      return "No worries! Ask me 'next step' or 'how to [specific action]' and I'll give you detailed step-by-step instructions for your current task.";
    } else {
      return "I'm your mission support AI! Ask me 'next step', 'how to start', or any specific question about your current task for detailed guidance.";
    }
  };

  const launchEnvironment = () => {
    setEnvironmentLaunched(true);
    // Auto-complete first task when environment is launched
    if (currentTask === 0 && !room.tasks[0].completed) {
      setTimeout(() => {
        room.tasks[0].completed = true;
        setCurrentTask(1);
        addXP(50);
      }, 2000);
    }
  };

  // Bank Attack Functions
  const navigateToAdmin = () => {
    setCurrentPage('admin');
    setBankUrl('https://securebank.local/admin');
    if (currentTask === 1 && !room.tasks[1].completed) {
      setTimeout(() => {
        room.tasks[1].completed = true;
        setCurrentTask(2);
        addXP(50);
      }, 1000);
    }
  };

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginData.username === 'admin' && loginData.password === 'admin') {
      setIsLoggedIn(true);
      setAdminAccess(true);
      if (currentTask === 2 && !room.tasks[2].completed) {
        setTimeout(() => {
          room.tasks[2].completed = true;
          setCurrentTask(3);
          addXP(50);
        }, 1000);
      }
    } else {
      alert('Invalid credentials! Try common admin credentials.');
    }
  };

  const executeTransfer = () => {
    if (transferAmount && transferTo && parseInt(transferAmount) > 0) {
      setAccountBalance(prev => prev - parseInt(transferAmount));
      alert(`Transfer successful! $${transferAmount} transferred to account ${transferTo}\n\nFLAG REVEALED: GAMIFY{bank_hacked}`);
      if (currentTask === 3 && !room.tasks[3].completed) {
        setTimeout(() => {
          room.tasks[3].completed = true;
          addXP(50);
          completeRoom(room.id!);
          addXP(room.xp);
        }, 1000);
      }
    }
  };

  // SOC Analyst Functions
  const analyzeLog = (logEntry: any) => {
    if (logEntry.source === '192.168.100.50' && currentTask === 1 && !room.tasks[1].completed) {
      setTimeout(() => {
        room.tasks[1].completed = true;
        setCurrentTask(2);
        addXP(50);
      }, 1000);
    }
  };

  const checkConnection = (connection: any) => {
    if (connection.remote.includes('192.168.100.50') && currentTask === 2 && !room.tasks[2].completed) {
      setTimeout(() => {
        room.tasks[2].completed = true;
        setCurrentTask(3);
        addXP(50);
      }, 1000);
    }
  };

  const identifyAttacker = (ip: string) => {
    if (ip === '192.168.100.50') {
      setSuspiciousIP(ip);
      if (currentTask === 3 && !room.tasks[3].completed) {
        setTimeout(() => {
          room.tasks[3].completed = true;
          setCurrentTask(4);
          addXP(50);
        }, 1000);
      }
    }
  };

  const blockIP = () => {
    if (suspiciousIP === '192.168.100.50') {
      setIsBlocked(true);
      alert('IP 192.168.100.50 has been blocked! Threat neutralized.\n\nFLAG REVEALED: GAMIFY{threat_neutralized}');
      if (currentTask === 4 && !room.tasks[4].completed) {
        setTimeout(() => {
          room.tasks[4].completed = true;
          addXP(50);
          completeRoom(room.id!);
          addXP(room.xp);
        }, 1000);
      }
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <Link to="/rooms" className="inline-flex items-center text-green-400 hover:text-green-300 mb-4">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Rooms
        </Link>
        
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">{room.name}</h1>
            <p className="text-gray-400">{room.description}</p>
          </div>
          <div className="text-right">
            <div className="bg-green-500/20 text-green-400 px-3 py-1 rounded-full text-sm font-semibold">
              +{room.xp} XP
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Story Introduction */}
          <div className="bg-gradient-to-r from-blue-900/50 to-purple-900/50 rounded-xl p-6 border border-blue-500/30">
            <h2 className="text-xl font-bold text-white mb-4 flex items-center">
              📖 Mission Briefing
            </h2>
            <div className="prose prose-invert max-w-none">
              <div className="text-gray-300 whitespace-pre-line text-sm leading-relaxed">
                {room.story}
              </div>
            </div>
          </div>

          {/* Interactive Environment */}
          <div className="bg-gray-800 rounded-xl border border-gray-700">
            <div className="flex items-center justify-between p-4 border-b border-gray-700">
              <div className="flex items-center">
                {room.id === 'bank-attack' ? (
                  <Globe className="h-5 w-5 text-green-400 mr-2" />
                ) : (
                  <Shield className="h-5 w-5 text-blue-400 mr-2" />
                )}
                <h2 className="text-lg font-bold text-white">
                  {room.id === 'bank-attack' ? 'SecureBank Web Browser' : 'SOC Monitoring Dashboard'}
                </h2>
              </div>
              <div className="flex space-x-2">
                <button 
                  onClick={() => setEnvironmentLaunched(false)}
                  className="bg-gray-700 hover:bg-gray-600 text-white p-2 rounded transition-colors"
                  title="Restart Environment"
                >
                  <RefreshCw className="h-4 w-4" />
                </button>
                <button className="bg-gray-700 hover:bg-gray-600 text-white p-2 rounded transition-colors">
                  <Maximize2 className="h-4 w-4" />
                </button>
                <div className="flex space-x-1">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                </div>
              </div>
            </div>
            
            <div className="relative bg-gradient-to-br from-gray-900 to-black rounded-b-xl overflow-hidden">
              {!environmentLaunched ? (
                /* Environment Launch Screen */
                <div className="h-96 bg-gradient-to-br from-gray-800 via-gray-900 to-black relative flex items-center justify-center">
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 to-purple-900/20"></div>
                  <div className="bg-gray-800 rounded-lg p-8 border border-gray-600 text-center z-10">
                    <div className="text-6xl mb-4">
                      {room.id === 'bank-attack' ? '🏦' : '🛡️'}
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">
                      {room.id === 'bank-attack' ? 'SecureBank Environment' : 'SOC Monitoring Environment'}
                    </h3>
                    <p className="text-gray-400 mb-6">
                      {room.id === 'bank-attack' 
                        ? 'Ready to launch banking website for penetration testing'
                        : 'Ready to launch security monitoring dashboard'
                      }
                    </p>
                    <button 
                      onClick={launchEnvironment}
                      className="btn-green-glow px-8 py-3 rounded-lg flex items-center space-x-2 mx-auto"
                    >
                      <Play className="h-5 w-5" />
                      <span>
                        {room.id === 'bank-attack' ? 'Launch Banking Environment' : 'Launch SOC Environment'}
                      </span>
                    </button>
                  </div>
                </div>
              ) : (
                /* Active Environment */
                <div className="h-96 bg-white relative">
                  {room.id === 'bank-attack' ? (
                    /* Bank Attack Interface */
                    <div className="h-full">
                      {/* Browser Address Bar */}
                      <div className="bg-gray-200 p-2 border-b flex items-center space-x-2">
                        <div className="flex space-x-1">
                          <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                          <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                          <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                        </div>
                        <div className="flex-1 bg-white rounded px-3 py-1 text-sm text-gray-700">
                          {bankUrl}
                        </div>
                        <button 
                          onClick={navigateToAdmin}
                          className="bg-gray-300 hover:bg-gray-400 px-3 py-1 rounded text-sm"
                        >
                          Try /admin
                        </button>
                      </div>

                      {/* Bank Website Content */}
                      <div className="p-6 h-full overflow-y-auto">
                        {currentPage === 'login' ? (
                          <div className="max-w-md mx-auto">
                            <div className="text-center mb-6">
                              <h1 className="text-2xl font-bold text-blue-600 mb-2">SecureBank Corp</h1>
                              <p className="text-gray-600">Online Banking Portal</p>
                            </div>
                            
                            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                              <h2 className="font-semibold text-blue-800 mb-2">Customer Login</h2>
                              <form className="space-y-3">
                                <input 
                                  type="text" 
                                  placeholder="Username"
                                  className="w-full p-2 border rounded"
                                />
                                <input 
                                  type="password" 
                                  placeholder="Password"
                                  className="w-full p-2 border rounded"
                                />
                                <button className="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700">
                                  Login
                                </button>
                              </form>
                            </div>
                            
                            <div className="text-center text-sm text-gray-500">
                              <p>Secure banking since 1995</p>
                              <p className="mt-2">
                                {/* Hidden admin link: /admin */}
                              </p>
                            </div>
                          </div>
                        ) : currentPage === 'admin' ? (
                          <div className="max-w-md mx-auto">
                            <div className="text-center mb-6">
                              <h1 className="text-2xl font-bold text-red-600 mb-2">Admin Panel</h1>
                              <p className="text-gray-600">Administrative Access</p>
                            </div>
                            
                            {!isLoggedIn ? (
                              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                                <h2 className="font-semibold text-red-800 mb-2">Administrator Login</h2>
                                <form onSubmit={handleAdminLogin} className="space-y-3">
                                  <input 
                                    type="text" 
                                    placeholder="Admin Username"
                                    value={loginData.username}
                                    onChange={(e) => setLoginData({...loginData, username: e.target.value})}
                                    className="w-full p-2 border rounded"
                                  />
                                  <input 
                                    type="password" 
                                    placeholder="Admin Password"
                                    value={loginData.password}
                                    onChange={(e) => setLoginData({...loginData, password: e.target.value})}
                                    className="w-full p-2 border rounded"
                                  />
                                  <button type="submit" className="w-full bg-red-600 text-white p-2 rounded hover:bg-red-700">
                                    Admin Login
                                  </button>
                                </form>
                                <p className="text-xs text-gray-500 mt-2">Hint: Try common admin credentials</p>
                              </div>
                            ) : (
                              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                                <h2 className="font-semibold text-green-800 mb-4">Admin Dashboard</h2>
                                <div className="space-y-4">
                                  <div className="bg-white p-3 rounded border">
                                    <h3 className="font-medium mb-2">Account Balance: ${accountBalance.toLocaleString()}</h3>
                                  </div>
                                  
                                  <div className="bg-white p-3 rounded border">
                                    <h3 className="font-medium mb-2">Transfer Funds</h3>
                                    <div className="space-y-2">
                                      <input 
                                        type="number" 
                                        placeholder="Amount"
                                        value={transferAmount}
                                        onChange={(e) => setTransferAmount(e.target.value)}
                                        className="w-full p-2 border rounded text-sm"
                                      />
                                      <input 
                                        type="text" 
                                        placeholder="To Account"
                                        value={transferTo}
                                        onChange={(e) => setTransferTo(e.target.value)}
                                        className="w-full p-2 border rounded text-sm"
                                      />
                                      <button 
                                        onClick={executeTransfer}
                                        className="w-full bg-green-600 text-white p-2 rounded hover:bg-green-700 text-sm"
                                      >
                                        Execute Transfer
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            )}
                          </div>
                        ) : null}
                      </div>
                    </div>
                  ) : (
                    /* SOC Analyst Interface */
                    <div className="h-full bg-gray-900 text-white">
                      {/* SOC Dashboard Header */}
                      <div className="bg-gray-800 p-3 border-b border-gray-700">
                        <div className="flex items-center justify-between">
                          <h2 className="text-lg font-bold">SOC Monitoring Dashboard</h2>
                          <div className="flex space-x-2">
                            <button
                              onClick={() => setActiveTab('logs')}
                              className={`px-3 py-1 rounded text-sm ${
                                activeTab === 'logs' ? 'bg-blue-600' : 'bg-gray-700 hover:bg-gray-600'
                              }`}
                            >
                              System Logs
                            </button>
                            <button
                              onClick={() => setActiveTab('connections')}
                              className={`px-3 py-1 rounded text-sm ${
                                activeTab === 'connections' ? 'bg-blue-600' : 'bg-gray-700 hover:bg-gray-600'
                              }`}
                            >
                              Network Connections
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* SOC Dashboard Content */}
                      <div className="p-4 h-full overflow-y-auto">
                        {activeTab === 'logs' ? (
                          <div className="space-y-2">
                            <h3 className="text-lg font-semibold mb-3 flex items-center">
                              <AlertTriangle className="h-5 w-5 text-yellow-400 mr-2" />
                              Security Log Analysis
                            </h3>
                            {logEntries.map((log, index) => (
                              <div 
                                key={index}
                                onClick={() => analyzeLog(log)}
                                className={`p-3 rounded border cursor-pointer hover:bg-gray-800 ${
                                  log.level === 'CRITICAL' ? 'border-red-500 bg-red-900/20' :
                                  log.level === 'ERROR' ? 'border-orange-500 bg-orange-900/20' :
                                  log.level === 'WARNING' ? 'border-yellow-500 bg-yellow-900/20' :
                                  'border-gray-600 bg-gray-800/50'
                                }`}
                              >
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center space-x-3">
                                    <span className="text-xs text-gray-400">{log.timestamp}</span>
                                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                                      log.level === 'CRITICAL' ? 'bg-red-600' :
                                      log.level === 'ERROR' ? 'bg-orange-600' :
                                      log.level === 'WARNING' ? 'bg-yellow-600' :
                                      'bg-blue-600'
                                    }`}>
                                      {log.level}
                                    </span>
                                  </div>
                                  <span className="text-xs text-gray-400">{log.source}</span>
                                </div>
                                <p className="text-sm mt-1">{log.message}</p>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="space-y-2">
                            <h3 className="text-lg font-semibold mb-3 flex items-center">
                              <Eye className="h-5 w-5 text-blue-400 mr-2" />
                              Active Network Connections
                            </h3>
                            {networkConnections.map((conn, index) => (
                              <div 
                                key={index}
                                onClick={() => checkConnection(conn)}
                                className={`p-3 rounded border cursor-pointer hover:bg-gray-800 ${
                                  conn.remote.includes('192.168.100.50') ? 'border-red-500 bg-red-900/20' :
                                  'border-gray-600 bg-gray-800/50'
                                }`}
                              >
                                <div className="flex items-center justify-between">
                                  <div className="space-y-1">
                                    <div className="text-sm">
                                      <span className="text-green-400">{conn.local}</span>
                                      <span className="text-gray-400 mx-2">→</span>
                                      <span className="text-red-400">{conn.remote}</span>
                                    </div>
                                    <div className="text-xs text-gray-400">
                                      Process: {conn.process} | State: {conn.state}
                                    </div>
                                  </div>
                                  {conn.remote.includes('192.168.100.50') && (
                                    <button
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        identifyAttacker('192.168.100.50');
                                      }}
                                      className="bg-red-600 hover:bg-red-700 px-2 py-1 rounded text-xs"
                                    >
                                      Suspicious
                                    </button>
                                  )}
                                </div>
                              </div>
                            ))}
                            
                            {suspiciousIP && (
                              <div className="mt-4 p-4 bg-red-900/30 border border-red-500 rounded">
                                <h4 className="font-semibold text-red-400 mb-2">Threat Identified</h4>
                                <p className="text-sm mb-3">Malicious IP: {suspiciousIP}</p>
                                <button
                                  onClick={blockIP}
                                  disabled={isBlocked}
                                  className={`px-4 py-2 rounded text-sm font-medium ${
                                    isBlocked 
                                      ? 'bg-green-600 text-white cursor-not-allowed' 
                                      : 'bg-red-600 hover:bg-red-700 text-white'
                                  }`}
                                >
                                  {isBlocked ? 'IP Blocked ✓' : 'Block IP'}
                                </button>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Tasks */}
          <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
            <h2 className="text-xl font-bold text-white mb-6 flex items-center">
              <CheckCircle className="h-5 w-5 text-green-400 mr-2" />
              Mission Tasks
            </h2>
            
            <div className="space-y-4">
              {room.tasks.map((task, index) => (
                <div key={task.id} className={`p-4 rounded-lg border ${
                  index === currentTask 
                    ? 'border-green-500 bg-green-500/10' 
                    : task.completed
                    ? 'border-gray-600 bg-gray-700/50'
                    : 'border-gray-600'
                }`}>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-lg font-semibold text-white">
                      {task.title}
                      {task.completed && <CheckCircle className="inline h-5 w-5 text-green-400 ml-2" />}
                    </h3>
                    <span className={`px-2 py-1 rounded text-xs ${
                      index === currentTask 
                        ? 'bg-green-500/20 text-green-400' 
                        : 'bg-gray-600 text-gray-300'
                    }`}>
                      Task {index + 1}
                    </span>
                  </div>
                  
                  <p className="text-gray-400 mb-4">{task.description}</p>
                  
                  {index === currentTask && !task.completed && (
                    <div className="flex gap-2">
                      <div className="flex-1">
                        <input
                          type="text"
                          value={flagInput}
                          onChange={(e) => setFlagInput(e.target.value)}
                          placeholder="Enter the flag here..."
                          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-400"
                        />
                      </div>
                      <button
                        onClick={() => handleFlagSubmit(index)}
                        className="btn-green-glow px-4 py-2 rounded-lg flex items-center"
                      >
                        <Flag className="h-4 w-4 mr-2" />
                        Submit
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* AI Assistant Chat */}
          <div className="bg-gray-800 rounded-xl border border-gray-700">
            <div className="p-4 border-b border-gray-700">
              <h3 className="text-lg font-semibold text-white flex items-center">
                <Bot className="h-5 w-5 text-blue-400 mr-2" />
                AI Mission Support
              </h3>
            </div>
            
            <div className="p-4">
              <div className="h-48 overflow-y-auto mb-4 space-y-3">
                {chatMessages.map((message, index) => (
                  <div key={index} className={`flex ${message.isBot ? 'justify-start' : 'justify-end'}`}>
                    <div className={`max-w-xs p-3 rounded-lg text-sm ${
                      message.isBot 
                        ? 'bg-blue-500/20 text-blue-100' 
                        : 'bg-green-500/20 text-green-100'
                    }`}>
                      <div className="whitespace-pre-line">{message.text}</div>
                    </div>
                  </div>
                ))}
              </div>
              
              <form onSubmit={handleChatSubmit} className="flex gap-2">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Ask for mission guidance..."
                  className="flex-1 px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm"
                />
                <button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-700 text-white p-2 rounded-lg transition-all duration-300 hover:shadow-[0_0_15px_rgba(59,130,246,0.5)]"
                >
                  <Send className="h-4 w-4" />
                </button>
              </form>
            </div>
          </div>

          {/* Mission Hint */}
          <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-white flex items-center">
                <HelpCircle className="h-5 w-5 text-yellow-400 mr-2" />
                Mission Hint
              </h3>
              <button
                onClick={() => setIsHintOpen(!isHintOpen)}
                className="text-yellow-400 hover:text-yellow-300 text-sm"
              >
                {isHintOpen ? 'Hide' : 'Show'}
              </button>
            </div>
            
            {isHintOpen && (
              <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-3">
                <p className="text-yellow-100 text-sm">
                  {room.tasks[currentTask]?.hint || "Excellent work! You've completed all mission objectives."}
                </p>
              </div>
            )}
          </div>

          {/* Mission Progress */}
          <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
            <h3 className="text-lg font-semibold text-white mb-4">Mission Progress</h3>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Tasks Completed</span>
                <span className="text-white font-semibold">
                  {room.tasks.filter(t => t.completed).length} / {room.tasks.length}
                </span>
              </div>
              
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div 
                  className="bg-green-400 h-2 rounded-full transition-all duration-300"
                  style={{ 
                    width: `${(room.tasks.filter(t => t.completed).length / room.tasks.length) * 100}%` 
                  }}
                ></div>
              </div>
              
              <div className="text-center">
                <span className="text-green-400 font-semibold">
                  +{room.tasks.filter(t => t.completed).length * 50} XP earned
                </span>
              </div>
              
              {room.tasks.filter(t => t.completed).length === room.tasks.length && (
                <div className="bg-green-500/20 border border-green-500/30 rounded-lg p-3 text-center">
                  <p className="text-green-400 font-semibold">🎉 Mission Complete!</p>
                  <p className="text-green-300 text-sm">+{room.xp} Bonus XP Awarded</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RoomDetail;